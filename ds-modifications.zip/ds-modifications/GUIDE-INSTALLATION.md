# 🚀 Guide d'installation rapide

## Installation en 3 étapes

### Étape 1 : Extraire le ZIP

```bash
# Décompresser le fichier ds-modifications.zip
unzip ds-modifications.zip

# Accéder au dossier
cd ds-modifications
```

### Étape 2 : Copier dans votre projet Design System

```bash
# Option A : Remplacer les fichiers dans le projet existant
cp -r * /chemin/vers/design-system-project/

# Option B : Appliquer manuellement fichier par fichier
# (recommandé si vous avez des modifications personnelles)
```

### Étape 3 : Installer et démarrer

```bash
# Installer les dépendances (inclut vite-plugin-handlebars)
npm install

# Démarrer le serveur de développement
npm run dev

# Accéder à l'application
# → http://localhost:3000
```

## 📋 Checklist des fichiers modifiés

### Fichiers de configuration

- ✅ `package.json` - Ajout de vite-plugin-handlebars
- ✅ `vite.config.js` - Configuration Handlebars

### Nouveaux partials Handlebars

- ✅ `src/partials/header.hbs` - En-tête
- ✅ `src/partials/nav.hbs` - Navigation avec accordéon
- ✅ `src/partials/footer.hbs` - Footer

### Fichiers principaux

- ✅ `src/index.html` - Page d'accueil avec partials
- ✅ `src/index.js` - Import ES Modules

### Composants (JavaScript → ES Modules)

- ✅ `src/components/atoms/button/button.js`
- ✅ `src/components/atoms/button/button.html`
- ✅ `src/components/organisms/accordion/accordion.js`
- ✅ `src/components/organisms/accordion/accordion.html`
- ✅ `src/components/organisms/tooltip/tooltip.js`
- ✅ `src/components/organisms/tooltip/tooltip.html`

## ⚡ Commandes principales

```bash
# Développement
npm run dev                    # Serveur dev (port 3000)
npm run build                  # Build de production
npm run preview                # Preview du build

# Storybook (inchangé)
npm run storybook              # Storybook dev (port 6006)
npm run build-storybook        # Build Storybook

# Tests (inchangés)
npm test                       # Lancer les tests
npm run test:coverage          # Tests avec couverture

# Tokens (inchangé)
npm run build-tokens           # Générer les design tokens
```

## 🎯 Changements clés

### 1. vite-plugin-handlebars

**Avant :** Template HTML dupliqué dans chaque page

**Après :** Partials réutilisables (`{{> header}}`, `{{> nav}}`, `{{> footer}}`)

### 2. Navigation avec Accordéon

**Avant :** Liste simple de liens

**Après :** Accordéon interactif avec catégories (Atoms, Organisms, etc.)

### 3. ES Modules

**Avant :**
```javascript
// Pas d'export ES Module
```

**Après :**
```javascript
export default ButtonRipple;
```

### 4. Pages de démonstration

**Avant :** Fichiers HTML basiques

**Après :** Pages complètes avec breadcrumb, démos, code snippets, liens

## 🔍 Vérification post-installation

```bash
# 1. Vérifier que vite-plugin-handlebars est installé
npm list vite-plugin-handlebars

# 2. Tester le build
npm run build

# 3. Vérifier la structure des fichiers
ls -la src/partials/

# 4. Démarrer le dev server et ouvrir http://localhost:3000
npm run dev
```

## 📚 Documentation complète

Consultez `README.md` pour :
- Structure détaillée des modifications
- Explications des nouveaux composants
- Guide de migration
- Dépannage

## 💡 Exemples d'utilisation

### Créer une nouvelle page avec les partials

```html
<!DOCTYPE html>
<html lang="fr">
<head>
  <meta charset="UTF-8">
  <title>Ma nouvelle page</title>
  <link rel="stylesheet" href="./assets/styles/main.scss">
</head>
<body>
  <div class="ds-layout">
    {{> header}}
    
    <div class="ds-layout__body">
      {{> nav}}
      
      <main class="ds-main">
        <!-- Votre contenu ici -->
      </main>
    </div>
    
    {{> footer}}
  </div>

  <script type="module" src="./index.js"></script>
</body>
</html>
```

### Importer un composant en ES Module

```javascript
// Dans votre fichier JS
import ButtonRipple from './components/atoms/button/button.js';

// Utilisation programmatique
const button = document.querySelector('.my-button');
const ripple = new ButtonRipple(button);

// Ou utilisation automatique via data-ripple
// <button data-ripple>Click me</button>
```

### Ajouter un composant à la navigation

Éditez `src/partials/nav.hbs` :

```html
<!-- Ajouter dans la catégorie appropriée -->
<li>
  <a href="/components/atoms/mon-composant/mon-composant.html" class="ds-nav__link">
    Mon Composant
  </a>
</li>
```

## ⚠️ Important

- **Partials** : Les fichiers `.hbs` sont dans `src/partials/`, pas dans `src/shared/`
- **Build multi-pages** : Ajoutez chaque nouvelle page HTML dans `vite.config.js` → `rollupOptions.input`
- **Compatibilité** : Les exports CommonJS sont maintenus pour les tests

## 🎉 Résultat attendu

Après installation, vous devriez avoir :

✅ Page d'accueil avec navigation accordéon  
✅ Pages de démo pour Button, Accordion, Tooltip  
✅ Header, Nav, Footer factorisés  
✅ Composants en ES Modules  
✅ Build fonctionnel  
✅ Storybook inchangé  
✅ Tests fonctionnels  

## 📞 Aide

En cas de problème :

1. Vérifiez la console pour les erreurs
2. Consultez `README.md` section "Dépannage"
3. Vérifiez que tous les fichiers sont au bon endroit
4. Testez avec `npm run build` pour voir les erreurs de build

---

**Design System © 2026 - Vite 7.2 & Storybook 10**
