# 📦 Design System - Package de modifications

> **Version** : 1.0.0  
> **Date** : Janvier 2026  
> **Taille** : 39 KB  

## 🎯 Objectif

Ce package contient **uniquement les modifications** pour :
- ✅ Intégrer `vite-plugin-handlebars` avec partials réutilisables
- ✅ Améliorer la navigation avec un accordéon par catégorie
- ✅ Convertir les composants JavaScript en ES Modules
- ✅ Créer des pages de démonstration complètes

## 📚 Documentation

| Fichier | Description | À lire en priorité |
|---------|-------------|-------------------|
| **GUIDE-INSTALLATION.md** | Guide d'installation rapide en 3 étapes | ⭐⭐⭐ |
| **README.md** | Documentation complète des modifications | ⭐⭐ |
| **README-MODIFICATIONS.md** | Récapitulatif détaillé des changements | ⭐ |

## 📁 Structure du package

```
ds-modifications/
│
├── 📘 GUIDE-INSTALLATION.md       # Installation rapide
├── 📘 README.md                   # Documentation complète
├── 📘 README-MODIFICATIONS.md     # Récapitulatif
├── 📘 INDEX.md                    # Ce fichier
│
├── ⚙️ package.json                # + vite-plugin-handlebars
├── ⚙️ vite.config.js              # Configuration Handlebars
│
└── src/
    │
    ├── 🎨 partials/               # ✨ NOUVEAUX partials Handlebars
    │   ├── header.hbs             # En-tête avec logo et badges
    │   ├── nav.hbs                # Navigation avec accordéon
    │   └── footer.hbs             # Footer avec copyright
    │
    ├── 📄 index.html              # ✏️ MODIFIÉ - Utilise les partials
    ├── 📜 index.js                # ✏️ MODIFIÉ - Import ES Modules
    │
    └── components/
        │
        ├── atoms/
        │   └── button/
        │       ├── button.html    # ✏️ Page de démo complète
        │       └── button.js      # ✏️ ES Module (export default)
        │
        └── organisms/
            ├── accordion/
            │   ├── accordion.html # ✏️ Page de démo complète
            │   └── accordion.js   # ✏️ ES Module (export default)
            │
            └── tooltip/
                ├── tooltip.html   # ✏️ Page de démo complète
                └── tooltip.js     # ✏️ ES Module (export default)
```

## 🚀 Installation rapide

```bash
# 1. Extraire le ZIP
unzip ds-modifications.zip
cd ds-modifications

# 2. Copier dans votre projet
cp -r * /chemin/vers/design-system-project/

# 3. Installer et démarrer
npm install
npm run dev
```

**Plus de détails :** Consultez `GUIDE-INSTALLATION.md`

## 📊 Résumé des modifications

- **13 fichiers** modifiés ou créés
- **3 partials Handlebars** pour factoriser le code
- **3 composants JS** convertis en ES Modules
- **3 pages HTML** de démonstration complètes
- **1 nouvelle dépendance** : vite-plugin-handlebars
- **~600 lignes** de code ajoutées

## 🎨 Fonctionnalités principales

### 1. Partials Handlebars

Réutilisez les éléments communs dans toutes vos pages :

```html
<div class="ds-layout">
  {{> header}}
  {{> nav}}
  <main><!-- Contenu --></main>
  {{> footer}}
</div>
```

### 2. Navigation avec Accordéon

Navigation interactive organisée par catégories :
- Atoms (Button, ...)
- Molecules (à venir)
- Organisms (Accordion, Tooltip)
- Templates (à venir)

### 3. ES Modules

Composants JavaScript modulaires :

```javascript
import ButtonRipple from './components/atoms/button/button.js';
const button = new ButtonRipple(element);
```

### 4. Pages de démonstration

Pages HTML complètes pour chaque composant avec :
- Breadcrumb de navigation
- Variantes et exemples
- Code snippets
- Documentation API

## 🎯 Compatibilité

- ✅ Vite 7.2.0
- ✅ Storybook 10.x (inchangé)
- ✅ Tests Vitest (inchangés)
- ✅ Build de production
- ✅ Exports CommonJS (maintenus pour les tests)

## ⚡ Commandes disponibles

```bash
npm run dev              # Serveur dev (port 3000)
npm run build            # Build de production
npm run preview          # Preview du build

npm run storybook        # Storybook (port 6006)
npm test                 # Tests unitaires
npm run build-tokens     # Générer les design tokens
```

## 📖 Guides détaillés

### Pour installer
→ Lisez **GUIDE-INSTALLATION.md**

### Pour comprendre les modifications
→ Lisez **README.md**

### Pour voir les statistiques
→ Lisez **README-MODIFICATIONS.md**

## 🔍 Fichiers par catégorie

### Configuration (2 fichiers)

- `package.json` - Dépendances
- `vite.config.js` - Configuration Vite + Handlebars

### Partials Handlebars (3 fichiers)

- `src/partials/header.hbs` - En-tête
- `src/partials/nav.hbs` - Navigation
- `src/partials/footer.hbs` - Footer

### Fichiers principaux (2 fichiers)

- `src/index.html` - Page d'accueil
- `src/index.js` - Point d'entrée

### Composants (6 fichiers)

- `src/components/atoms/button/button.html` + `.js`
- `src/components/organisms/accordion/accordion.html` + `.js`
- `src/components/organisms/tooltip/tooltip.html` + `.js`

## 💡 Points clés

1. **vite-plugin-handlebars** remplace le système `template-loader.js` précédent
2. Les **partials** sont dans `src/partials/`, pas `src/shared/`
3. Tous les composants JS ont maintenant **`export default`**
4. La **navigation** utilise le composant Accordion existant
5. Les **pages de démo** sont complètes et prêtes à l'emploi

## ⚠️ Important

- Les fichiers **écrasent** les versions précédentes
- Faites une **sauvegarde** avant d'appliquer les modifications
- Testez avec `npm run build` après installation
- Consultez la section "Dépannage" de `README.md` en cas de problème

## 📞 Support

En cas de problème :

1. Consultez la section "Dépannage" dans `README.md`
2. Vérifiez la console du navigateur pour les erreurs
3. Testez le build avec `npm run build`
4. Vérifiez que tous les fichiers sont au bon endroit

## ✅ Checklist post-installation

- [ ] `npm install` réussi
- [ ] `vite-plugin-handlebars` installé
- [ ] `npm run dev` fonctionne
- [ ] http://localhost:3000 accessible
- [ ] Navigation accordéon fonctionnelle
- [ ] Pages de composants accessibles
- [ ] `npm run build` réussi
- [ ] Tests passent (`npm test`)

## 🎉 Résultat attendu

Après installation réussie :

- ✅ Header, Nav, Footer factorisés avec Handlebars
- ✅ Navigation interactive avec accordéon
- ✅ Pages de démo complètes pour chaque composant
- ✅ Composants JavaScript en ES Modules
- ✅ Build multi-pages fonctionnel
- ✅ Storybook et tests inchangés

## 🚀 Prochaines étapes

1. **Installer** le package (voir GUIDE-INSTALLATION.md)
2. **Tester** l'application (`npm run dev`)
3. **Explorer** les pages de composants
4. **Ajouter** vos propres composants à la navigation
5. **Personnaliser** les partials selon vos besoins

---

**Design System © 2026**  
**Vite 7.2 • Storybook 10 • Handlebars**  

**Bon développement ! 🎨✨**
