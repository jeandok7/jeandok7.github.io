/**
 * Button Ripple Component
 * Ajoute un effet ripple (Material Design) aux boutons
 * 
 * @class ButtonRipple
 */
class ButtonRipple {
  /**
   * @param {HTMLElement} element - L'élément bouton
   * @param {Object} options - Options de configuration
   */
  constructor(element, options = {}) {
    if (!element) {
      console.warn('ButtonRipple: element est requis');
      return;
    }

    this.element = element;
    this.options = {
      duration: options.duration || 600,
      color: options.color || 'rgba(255, 255, 255, 0.5)',
      ...options
    };

    this.init();
  }

  /**
   * Initialise le composant
   */
  init() {
    // Ajouter la classe de style
    this.element.classList.add('ds-button--ripple');
    
    // Position relative pour le ripple
    if (getComputedStyle(this.element).position === 'static') {
      this.element.style.position = 'relative';
    }
    
    // Overflow hidden pour contenir le ripple
    this.element.style.overflow = 'hidden';

    // Attacher l'événement
    this.element.addEventListener('click', this.handleClick.bind(this));
  }

  /**
   * Gère le clic sur le bouton
   * @param {Event} event - L'événement de clic
   */
  handleClick(event) {
    // Ne pas créer de ripple si le bouton est désactivé
    if (this.element.disabled || this.element.classList.contains('ds-button--disabled')) {
      return;
    }

    // Créer l'élément ripple
    const ripple = document.createElement('span');
    ripple.classList.add('ds-button__ripple');
    
    // Calculer la position et la taille
    const rect = this.element.getBoundingClientRect();
    const size = Math.max(rect.width, rect.height);
    const x = event.clientX - rect.left - size / 2;
    const y = event.clientY - rect.top - size / 2;

    // Appliquer les styles
    ripple.style.width = ripple.style.height = `${size}px`;
    ripple.style.left = `${x}px`;
    ripple.style.top = `${y}px`;
    ripple.style.background = this.options.color;

    // Ajouter au bouton
    this.element.appendChild(ripple);

    // Retirer après l'animation
    setTimeout(() => {
      ripple.remove();
    }, this.options.duration);
  }

  /**
   * Détruit le composant
   */
  destroy() {
    this.element.removeEventListener('click', this.handleClick);
    this.element.classList.remove('ds-button--ripple');
  }
}

// Auto-initialisation pour les éléments avec data-ripple
if (typeof document !== 'undefined') {
  const autoInit = () => {
    document.querySelectorAll('[data-ripple]').forEach(element => {
      if (!element._buttonRipple) {
        element._buttonRipple = new ButtonRipple(element);
      }
    });
  };

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', autoInit);
  } else {
    autoInit();
  }

  // Observer pour les nouveaux éléments
  if (typeof MutationObserver !== 'undefined') {
    const observer = new MutationObserver(mutations => {
      mutations.forEach(mutation => {
        mutation.addedNodes.forEach(node => {
          if (node.nodeType === 1) {
            if (node.hasAttribute('data-ripple') && !node._buttonRipple) {
              node._buttonRipple = new ButtonRipple(node);
            }
            node.querySelectorAll('[data-ripple]').forEach(element => {
              if (!element._buttonRipple) {
                element._buttonRipple = new ButtonRipple(element);
              }
            });
          }
        });
      });
    });

    observer.observe(document.body, {
      childList: true,
      subtree: true
    });
  }
}

// Export ES Module
export default ButtonRipple;

// Export global pour compatibilité
if (typeof window !== 'undefined') {
  window.DSButtonRipple = ButtonRipple;
}

// Export CommonJS pour les tests
if (typeof module !== 'undefined' && module.exports) {
  module.exports = ButtonRipple;
}
