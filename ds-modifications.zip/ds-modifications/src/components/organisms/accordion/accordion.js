/**
 * Accordion Component
 * Composant accordéon accessible avec support ARIA et navigation clavier
 * 
 * @class Accordion
 */
class Accordion {
  /**
   * @param {HTMLElement} element - L'élément conteneur de l'accordéon
   * @param {Object} options - Options de configuration
   */
  constructor(element, options = {}) {
    if (!element) {
      console.warn('Accordion: element est requis');
      return;
    }

    this.element = element;
    this.options = {
      allowMultiple: element.dataset.allowMultiple === 'true' || options.allowMultiple || false,
      ...options
    };

    this.items = [];
    this.init();
  }

  /**
   * Initialise le composant
   */
  init() {
    // Récupérer tous les items
    const itemElements = this.element.querySelectorAll('.ds-accordion__item');
    
    itemElements.forEach((item, index) => {
      const trigger = item.querySelector('.ds-accordion__trigger');
      const content = item.querySelector('.ds-accordion__content');
      
      if (!trigger || !content) return;

      // Générer des IDs uniques si nécessaire
      const triggerId = trigger.id || `accordion-trigger-${Date.now()}-${index}`;
      const contentId = content.id || `accordion-content-${Date.now()}-${index}`;
      
      trigger.id = triggerId;
      content.id = contentId;

      // Configurer ARIA
      trigger.setAttribute('aria-controls', contentId);
      trigger.setAttribute('aria-expanded', 'false');
      content.setAttribute('role', 'region');
      content.setAttribute('aria-labelledby', triggerId);

      // État initial
      const isExpanded = item.classList.contains('is-active');
      if (isExpanded) {
        this.expand(item);
      }

      // Ajouter à la liste
      this.items.push({ item, trigger, content });

      // Attacher les événements
      trigger.addEventListener('click', () => this.toggle(item));
      trigger.addEventListener('keydown', (e) => this.handleKeydown(e, index));
    });

    // Observer pour les nouveaux items ajoutés dynamiquement
    this.observeChanges();
  }

  /**
   * Toggle un item
   * @param {HTMLElement} item - L'item à toggler
   */
  toggle(item) {
    const isExpanded = item.classList.contains('is-active');
    
    if (isExpanded) {
      this.collapse(item);
    } else {
      // Si allowMultiple est false, fermer les autres items
      if (!this.options.allowMultiple) {
        this.items.forEach(({ item: otherItem }) => {
          if (otherItem !== item) {
            this.collapse(otherItem);
          }
        });
      }
      this.expand(item);
    }

    // Émettre un événement personnalisé
    this.element.dispatchEvent(new CustomEvent('accordion:toggle', {
      detail: { item, expanded: !isExpanded }
    }));
  }

  /**
   * Expand un item
   * @param {HTMLElement} item - L'item à expand
   */
  expand(item) {
    const trigger = item.querySelector('.ds-accordion__trigger');
    const content = item.querySelector('.ds-accordion__content');
    
    item.classList.add('is-active');
    trigger.setAttribute('aria-expanded', 'true');
    content.style.maxHeight = content.scrollHeight + 'px';

    this.element.dispatchEvent(new CustomEvent('accordion:expanded', {
      detail: { item }
    }));
  }

  /**
   * Collapse un item
   * @param {HTMLElement} item - L'item à collapse
   */
  collapse(item) {
    const trigger = item.querySelector('.ds-accordion__trigger');
    const content = item.querySelector('.ds-accordion__content');
    
    item.classList.remove('is-active');
    trigger.setAttribute('aria-expanded', 'false');
    content.style.maxHeight = '0';

    this.element.dispatchEvent(new CustomEvent('accordion:collapsed', {
      detail: { item }
    }));
  }

  /**
   * Gère la navigation clavier
   * @param {KeyboardEvent} event - L'événement clavier
   * @param {number} currentIndex - L'index de l'item courant
   */
  handleKeydown(event, currentIndex) {
    const { key } = event;
    let targetIndex = currentIndex;

    switch (key) {
      case 'ArrowDown':
        event.preventDefault();
        targetIndex = (currentIndex + 1) % this.items.length;
        break;
      case 'ArrowUp':
        event.preventDefault();
        targetIndex = currentIndex === 0 ? this.items.length - 1 : currentIndex - 1;
        break;
      case 'Home':
        event.preventDefault();
        targetIndex = 0;
        break;
      case 'End':
        event.preventDefault();
        targetIndex = this.items.length - 1;
        break;
      default:
        return;
    }

    this.items[targetIndex].trigger.focus();
  }

  /**
   * Expand tous les items
   */
  expandAll() {
    if (!this.options.allowMultiple) {
      console.warn('Accordion: expandAll nécessite allowMultiple=true');
      return;
    }
    
    this.items.forEach(({ item }) => this.expand(item));
  }

  /**
   * Collapse tous les items
   */
  collapseAll() {
    this.items.forEach(({ item }) => this.collapse(item));
  }

  /**
   * Observe les changements du DOM pour initialiser les nouveaux items
   */
  observeChanges() {
    if (typeof MutationObserver === 'undefined') return;

    const observer = new MutationObserver(() => {
      const newItemElements = this.element.querySelectorAll('.ds-accordion__item');
      if (newItemElements.length > this.items.length) {
        // Réinitialiser
        this.items = [];
        this.init();
      }
    });

    observer.observe(this.element, {
      childList: true,
      subtree: true
    });
  }

  /**
   * Détruit le composant
   */
  destroy() {
    this.items.forEach(({ trigger }) => {
      trigger.removeEventListener('click', this.toggle);
      trigger.removeEventListener('keydown', this.handleKeydown);
    });
    this.items = [];
  }
}

// Auto-initialisation pour les éléments avec data-toggle="accordion"
if (typeof document !== 'undefined') {
  const autoInit = () => {
    document.querySelectorAll('[data-toggle="accordion"]').forEach(element => {
      if (!element._accordion) {
        element._accordion = new Accordion(element);
      }
    });
  };

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', autoInit);
  } else {
    autoInit();
  }

  // Observer pour les nouveaux éléments
  if (typeof MutationObserver !== 'undefined') {
    const observer = new MutationObserver(mutations => {
      mutations.forEach(mutation => {
        mutation.addedNodes.forEach(node => {
          if (node.nodeType === 1) {
            if (node.hasAttribute('data-toggle') && node.getAttribute('data-toggle') === 'accordion' && !node._accordion) {
              node._accordion = new Accordion(node);
            }
            node.querySelectorAll('[data-toggle="accordion"]').forEach(element => {
              if (!element._accordion) {
                element._accordion = new Accordion(element);
              }
            });
          }
        });
      });
    });

    observer.observe(document.body, {
      childList: true,
      subtree: true
    });
  }
}

// Export ES Module
export default Accordion;

// Export global pour compatibilité
if (typeof window !== 'undefined') {
  window.DSAccordion = Accordion;
}

// Export CommonJS pour les tests
if (typeof module !== 'undefined' && module.exports) {
  module.exports = Accordion;
}
