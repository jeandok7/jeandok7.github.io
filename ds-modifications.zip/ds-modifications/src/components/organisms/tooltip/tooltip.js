import { computePosition, flip, shift, offset, arrow } from '@floating-ui/dom';

/**
 * Tooltip Component
 * Infobulle contextuelle avec Floating UI
 * 
 * @class Tooltip
 */
class Tooltip {
  /**
   * @param {HTMLElement} element - L'élément déclencheur
   * @param {Object} options - Options de configuration
   */
  constructor(element, options = {}) {
    if (!element) {
      console.warn('Tooltip: element est requis');
      return;
    }

    this.element = element;
    this.options = {
      content: element.dataset.tooltipContent || element.title || options.content || '',
      placement: element.dataset.tooltipPlacement || options.placement || 'top',
      trigger: element.dataset.tooltipTrigger || options.trigger || 'hover',
      delay: parseInt(element.dataset.tooltipDelay) || options.delay || 200,
      ...options
    };

    this.tooltip = null;
    this.arrowElement = null;
    this.isVisible = false;
    this.showTimeout = null;
    this.hideTimeout = null;

    this.init();
  }

  /**
   * Initialise le composant
   */
  init() {
    // Retirer l'attribut title pour éviter le tooltip natif
    if (this.element.title) {
      this.options.content = this.element.title;
      this.element.removeAttribute('title');
    }

    // Créer le tooltip
    this.createTooltip();

    // Attacher les événements selon le trigger
    this.attachEvents();
  }

  /**
   * Crée l'élément tooltip
   */
  createTooltip() {
    this.tooltip = document.createElement('div');
    this.tooltip.className = 'ds-tooltip';
    this.tooltip.setAttribute('role', 'tooltip');
    this.tooltip.setAttribute('id', `tooltip-${Date.now()}`);

    // Contenu
    const content = document.createElement('div');
    content.className = 'ds-tooltip__content';
    content.textContent = this.options.content;
    this.tooltip.appendChild(content);

    // Flèche
    this.arrowElement = document.createElement('div');
    this.arrowElement.className = 'ds-tooltip__arrow';
    this.tooltip.appendChild(this.arrowElement);

    // Ajouter au DOM mais caché
    document.body.appendChild(this.tooltip);

    // Configurer ARIA
    this.element.setAttribute('aria-describedby', this.tooltip.id);
  }

  /**
   * Attache les événements
   */
  attachEvents() {
    switch (this.options.trigger) {
      case 'hover':
        this.element.addEventListener('mouseenter', this.handleMouseEnter.bind(this));
        this.element.addEventListener('mouseleave', this.handleMouseLeave.bind(this));
        this.element.addEventListener('focus', this.handleFocus.bind(this));
        this.element.addEventListener('blur', this.handleBlur.bind(this));
        break;

      case 'click':
        this.element.addEventListener('click', this.handleClick.bind(this));
        document.addEventListener('click', this.handleDocumentClick.bind(this));
        break;

      case 'focus':
        this.element.addEventListener('focus', this.handleFocus.bind(this));
        this.element.addEventListener('blur', this.handleBlur.bind(this));
        break;
    }
  }

  /**
   * Gestionnaires d'événements
   */
  handleMouseEnter() {
    this.clearHideTimeout();
    this.showTimeout = setTimeout(() => {
      this.show();
    }, this.options.delay);
  }

  handleMouseLeave() {
    this.clearShowTimeout();
    this.hideTimeout = setTimeout(() => {
      this.hide();
    }, this.options.delay);
  }

  handleFocus() {
    this.clearHideTimeout();
    this.show();
  }

  handleBlur() {
    this.clearShowTimeout();
    this.hide();
  }

  handleClick(event) {
    event.stopPropagation();
    this.toggle();
  }

  handleDocumentClick(event) {
    if (!this.element.contains(event.target) && !this.tooltip.contains(event.target)) {
      this.hide();
    }
  }

  /**
   * Clear timeouts
   */
  clearShowTimeout() {
    if (this.showTimeout) {
      clearTimeout(this.showTimeout);
      this.showTimeout = null;
    }
  }

  clearHideTimeout() {
    if (this.hideTimeout) {
      clearTimeout(this.hideTimeout);
      this.hideTimeout = null;
    }
  }

  /**
   * Affiche le tooltip
   */
  async show() {
    if (this.isVisible) return;

    this.isVisible = true;
    this.tooltip.classList.add('ds-tooltip--visible');

    // Positionner avec Floating UI
    await this.updatePosition();

    // Émettre un événement
    this.element.dispatchEvent(new CustomEvent('tooltip:show', {
      detail: { tooltip: this.tooltip }
    }));
  }

  /**
   * Cache le tooltip
   */
  hide() {
    if (!this.isVisible) return;

    this.isVisible = false;
    this.tooltip.classList.remove('ds-tooltip--visible');

    // Émettre un événement
    this.element.dispatchEvent(new CustomEvent('tooltip:hide', {
      detail: { tooltip: this.tooltip }
    }));
  }

  /**
   * Toggle le tooltip
   */
  toggle() {
    if (this.isVisible) {
      this.hide();
    } else {
      this.show();
    }
  }

  /**
   * Met à jour la position du tooltip
   */
  async updatePosition() {
    const { x, y, placement, middlewareData } = await computePosition(
      this.element,
      this.tooltip,
      {
        placement: this.options.placement,
        middleware: [
          offset(8),
          flip(),
          shift({ padding: 8 }),
          arrow({ element: this.arrowElement })
        ]
      }
    );

    // Positionner le tooltip
    Object.assign(this.tooltip.style, {
      left: `${x}px`,
      top: `${y}px`
    });

    // Positionner la flèche
    if (middlewareData.arrow) {
      const { x: arrowX, y: arrowY } = middlewareData.arrow;
      
      const staticSide = {
        top: 'bottom',
        right: 'left',
        bottom: 'top',
        left: 'right'
      }[placement.split('-')[0]];

      Object.assign(this.arrowElement.style, {
        left: arrowX != null ? `${arrowX}px` : '',
        top: arrowY != null ? `${arrowY}px` : '',
        right: '',
        bottom: '',
        [staticSide]: '-4px'
      });
    }

    // Ajouter la classe de placement
    this.tooltip.className = `ds-tooltip ds-tooltip--${placement.split('-')[0]}`;
    if (this.isVisible) {
      this.tooltip.classList.add('ds-tooltip--visible');
    }
  }

  /**
   * Met à jour le contenu
   * @param {string} content - Le nouveau contenu
   */
  setContent(content) {
    this.options.content = content;
    const contentEl = this.tooltip.querySelector('.ds-tooltip__content');
    if (contentEl) {
      contentEl.textContent = content;
    }
  }

  /**
   * Détruit le composant
   */
  destroy() {
    this.clearShowTimeout();
    this.clearHideTimeout();
    
    // Retirer les événements
    switch (this.options.trigger) {
      case 'hover':
        this.element.removeEventListener('mouseenter', this.handleMouseEnter);
        this.element.removeEventListener('mouseleave', this.handleMouseLeave);
        this.element.removeEventListener('focus', this.handleFocus);
        this.element.removeEventListener('blur', this.handleBlur);
        break;

      case 'click':
        this.element.removeEventListener('click', this.handleClick);
        document.removeEventListener('click', this.handleDocumentClick);
        break;

      case 'focus':
        this.element.removeEventListener('focus', this.handleFocus);
        this.element.removeEventListener('blur', this.handleBlur);
        break;
    }

    // Retirer du DOM
    if (this.tooltip && this.tooltip.parentNode) {
      this.tooltip.parentNode.removeChild(this.tooltip);
    }

    // Nettoyer les références
    this.element.removeAttribute('aria-describedby');
    this.tooltip = null;
    this.arrowElement = null;
  }
}

// Auto-initialisation pour les éléments avec data-toggle="tooltip"
if (typeof document !== 'undefined') {
  const autoInit = () => {
    document.querySelectorAll('[data-toggle="tooltip"]').forEach(element => {
      if (!element._tooltip) {
        element._tooltip = new Tooltip(element);
      }
    });
  };

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', autoInit);
  } else {
    autoInit();
  }

  // Observer pour les nouveaux éléments
  if (typeof MutationObserver !== 'undefined') {
    const observer = new MutationObserver(mutations => {
      mutations.forEach(mutation => {
        mutation.addedNodes.forEach(node => {
          if (node.nodeType === 1) {
            if (node.hasAttribute('data-toggle') && node.getAttribute('data-toggle') === 'tooltip' && !node._tooltip) {
              node._tooltip = new Tooltip(node);
            }
            node.querySelectorAll('[data-toggle="tooltip"]').forEach(element => {
              if (!element._tooltip) {
                element._tooltip = new Tooltip(element);
              }
            });
          }
        });
      });
    });

    observer.observe(document.body, {
      childList: true,
      subtree: true
    });
  }
}

// Export ES Module
export default Tooltip;

// Export global pour compatibilité
if (typeof window !== 'undefined') {
  window.DSTooltip = Tooltip;
}

// Export CommonJS pour les tests
if (typeof module !== 'undefined' && module.exports) {
  module.exports = Tooltip;
}
