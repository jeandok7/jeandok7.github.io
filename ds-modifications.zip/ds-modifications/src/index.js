// ============================================================================
// Design System - Point d'entrée principal
// ============================================================================

// Import des styles globaux
import './assets/styles/main.scss';

// Import des composants (styles + JavaScript)
import './components/atoms/button/button.scss';
import ButtonRipple from './components/atoms/button/button.js';

import './components/organisms/accordion/accordion.scss';
import Accordion from './components/organisms/accordion/accordion.js';

import './components/organisms/tooltip/tooltip.scss';
import Tooltip from './components/organisms/tooltip/tooltip.js';

// ============================================================================
// Initialisation automatique des composants
// ============================================================================

/**
 * Initialise tous les composants du Design System au chargement de la page
 */
function initDesignSystem() {
  console.log('🎨 Design System - Initialisation...');

  // Initialiser les boutons avec effet ripple
  const buttonsWithRipple = document.querySelectorAll('[data-ripple]');
  if (buttonsWithRipple.length > 0) {
    console.log(`✓ ${buttonsWithRipple.length} bouton(s) avec effet ripple initialisé(s)`);
  }

  // Initialiser les accordéons
  const accordions = document.querySelectorAll('[data-toggle="accordion"]');
  accordions.forEach(element => {
    new Accordion(element);
  });
  if (accordions.length > 0) {
    console.log(`✓ ${accordions.length} accordéon(s) initialisé(s)`);
  }

  // Initialiser les tooltips
  const tooltips = document.querySelectorAll('[data-toggle="tooltip"]');
  tooltips.forEach(element => {
    new Tooltip(element);
  });
  if (tooltips.length > 0) {
    console.log(`✓ ${tooltips.length} tooltip(s) initialisé(s)`);
  }

  console.log('✅ Design System chargé avec succès');
}

// Initialiser au chargement du DOM
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', initDesignSystem);
} else {
  initDesignSystem();
}

// ============================================================================
// Export des composants pour utilisation programmatique
// ============================================================================

export { ButtonRipple, Accordion, Tooltip };

// Exposition globale pour compatibilité avec scripts externes
window.DesignSystem = {
  version: '1.0.0',
  components: {
    ButtonRipple,
    Accordion,
    Tooltip
  },
  init: initDesignSystem
};

export default window.DesignSystem;
