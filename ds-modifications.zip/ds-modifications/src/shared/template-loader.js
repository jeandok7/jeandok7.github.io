/**
 * Template Loader - Inject shared components into pages
 * Charge dynamiquement header, nav et footer
 */

async function loadComponent(selector, url) {
  try {
    const response = await fetch(url);
    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`);
    }
    const html = await response.text();
    const element = document.querySelector(selector);
    if (element) {
      element.innerHTML = html;
    }
  } catch (error) {
    console.error(`Error loading component from ${url}:`, error);
  }
}

/**
 * Marquer le lien actif dans la navigation
 */
function markActiveNavLink() {
  const currentPath = window.location.pathname;
  const navLinks = document.querySelectorAll('.nav-link');
  
  navLinks.forEach(link => {
    const linkPath = new URL(link.href).pathname;
    if (linkPath === currentPath) {
      link.classList.add('active');
    }
  });
}

/**
 * Initialiser les shared components
 */
async function initSharedComponents() {
  // Charger les composants partagés
  await Promise.all([
    loadComponent('#ds-header-slot', '/src/shared/header.html'),
    loadComponent('#ds-nav-slot', '/src/shared/nav.html'),
    loadComponent('#ds-footer-slot', '/src/shared/footer.html')
  ]);
  
  // Marquer le lien actif après chargement de la nav
  setTimeout(markActiveNavLink, 100);
  
  console.log('✅ Shared components loaded');
}

// Load shared components on DOMContentLoaded
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', initSharedComponents);
} else {
  initSharedComponents();
}

export { loadComponent, initSharedComponents };
