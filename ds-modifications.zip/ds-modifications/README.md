# 📦 Modifications du Design System

Ce package contient **uniquement les modifications** pour intégrer `vite-plugin-handlebars` et les partials Handlebars dans le Design System.

## 🎯 Objectifs des modifications

1. **Factorisation du code HTML** avec des partials Handlebars (header, nav, footer)
2. **Navigation améliorée** avec un accordéon dans la sidebar listant les composants par catégorie
3. **Conversion en ES Modules** de tous les composants JavaScript
4. **Pages de démonstration** pour chaque composant avec liens depuis la navigation

## 📁 Structure des modifications

```
ds-modifications/
├── package.json                                    # Ajout de vite-plugin-handlebars
├── vite.config.js                                  # Configuration Handlebars
│
├── src/
│   ├── partials/                                   # ✨ NOUVEAUX partials Handlebars
│   │   ├── header.hbs                              # En-tête avec logo et badges
│   │   ├── nav.hbs                                 # Navigation avec accordéon
│   │   └── footer.hbs                              # Footer avec copyright
│   │
│   ├── index.html                                  # ✏️ MODIFIÉ - Utilise les partials
│   ├── index.js                                    # ✏️ MODIFIÉ - Import ES Modules
│   │
│   └── components/
│       ├── atoms/
│       │   └── button/
│       │       ├── button.html                     # ✏️ MODIFIÉ - Page de démo
│       │       └── button.js                       # ✏️ MODIFIÉ - Export ES Module
│       │
│       └── organisms/
│           ├── accordion/
│           │   ├── accordion.html                  # ✏️ MODIFIÉ - Page de démo
│           │   └── accordion.js                    # ✏️ MODIFIÉ - Export ES Module
│           │
│           └── tooltip/
│               ├── tooltip.html                    # ✏️ MODIFIÉ - Page de démo
│               └── tooltip.js                      # ✏️ MODIFIÉ - Export ES Module
│
└── README.md                                       # Ce fichier

```

## 🚀 Installation des modifications

### 1. Copier les fichiers

Copiez tous les fichiers de ce package dans votre projet Design System en **écrasant** les fichiers existants.

```bash
# Depuis le dossier ds-modifications/
cp -r * /chemin/vers/design-system-project/
```

### 2. Installer les dépendances

```bash
npm install
```

La nouvelle dépendance ajoutée : `vite-plugin-handlebars@^2.0.0`

### 3. Lancer le projet

```bash
# Démarrer le serveur de développement
npm run dev

# Accéder à l'application
# → http://localhost:3000
```

## ✨ Nouvelles fonctionnalités

### 1. Partials Handlebars

Les partials permettent de réutiliser les éléments HTML communs :

- **`header.hbs`** : En-tête avec logo et badges (Vite 7.2, Storybook 10)
- **`nav.hbs`** : Navigation latérale avec accordéon par catégorie de composants
- **`footer.hbs`** : Footer avec copyright et version

**Utilisation dans les pages HTML :**

```html
<div class="ds-layout">
  {{> header}}
  
  <div class="ds-layout__body">
    {{> nav}}
    
    <main class="ds-main">
      <!-- Contenu de la page -->
    </main>
  </div>
  
  {{> footer}}
</div>
```

### 2. Navigation avec Accordéon

La navigation utilise le composant Accordion pour organiser les composants par catégorie (Atoms, Molecules, Organisms, Templates).

- **Auto-initialisation** via `data-toggle="accordion"`
- **Mode multiple** avec `data-allow-multiple="true"`
- **Navigation clavier** (ArrowUp/Down, Home/End)
- **Liens directs** vers les pages de chaque composant

### 3. Pages de démonstration

Chaque composant dispose d'une page dédiée avec :

- **Breadcrumb** pour la navigation
- **Sections démo** avec exemples interactifs
- **Code snippets** avec bouton "Voir le code"
- **Documentation** des props et API
- **Liens** vers Storybook et accueil

### 4. ES Modules

Tous les composants JavaScript sont maintenant des **ES Modules** :

**Export par défaut :**
```javascript
export default ButtonRipple;
```

**Import dans index.js :**
```javascript
import ButtonRipple from './components/atoms/button/button.js';
import Accordion from './components/organisms/accordion/accordion.js';
import Tooltip from './components/organisms/tooltip/tooltip.js';
```

**Export global** pour compatibilité :
```javascript
window.DSButtonRipple = ButtonRipple;
window.DSAccordion = Accordion;
window.DSTooltip = Tooltip;
```

## 🔧 Configuration Vite

Le fichier `vite.config.js` a été mis à jour pour intégrer `vite-plugin-handlebars` :

```javascript
import handlebars from 'vite-plugin-handlebars';

export default defineConfig({
  plugins: [
    handlebars({
      partialDirectory: resolve(__dirname, 'src/partials'),
      context: {
        title: 'Design System - Vite 7.2 & Storybook 10',
        year: new Date().getFullYear(),
        version: '1.0.0'
      },
      helpers: {
        eq: (a, b) => a === b,
        or: (...args) => args.slice(0, -1).some(Boolean),
        and: (...args) => args.slice(0, -1).every(Boolean)
      }
    }),
    // ... autres plugins
  ]
});
```

## 📝 Modifications détaillées

### `package.json`

**Ajout :**
```json
{
  "devDependencies": {
    "vite-plugin-handlebars": "^2.0.0"
  }
}
```

### `vite.config.js`

- Import du plugin `vite-plugin-handlebars`
- Configuration du `partialDirectory`
- Contexte global (title, year, version)
- Helpers Handlebars (eq, or, and)

### `src/index.html`

- Utilisation des partials `{{> header}}`, `{{> nav}}`, `{{> footer}}`
- Structure de layout avec sidebar
- Cards des composants avec liens vers les pages démo
- Section Quick Start et Technologies

### `src/index.js`

- Import des styles et composants en ES Modules
- Fonction `initDesignSystem()` pour l'auto-initialisation
- Export des composants (ButtonRipple, Accordion, Tooltip)
- Export global `window.DesignSystem`

### Composants JavaScript

**Modifications communes :**
- Ajout de `export default ComponentName;`
- Maintien de l'export global `window.DSComponentName`
- Maintien de l'export CommonJS pour les tests
- Auto-initialisation avec `data-toggle`
- MutationObserver pour les éléments ajoutés dynamiquement

### Pages HTML des composants

**Structure commune :**
```html
<!DOCTYPE html>
<html lang="fr">
<head>
  <meta charset="UTF-8">
  <title>Composant - Design System</title>
  <link rel="stylesheet" href="../../../assets/styles/main.scss">
</head>
<body>
  <div class="ds-layout">
    {{> header}}
    
    <div class="ds-layout__body">
      {{> nav}}
      
      <main class="ds-main">
        <div class="ds-component-page">
          <!-- Breadcrumb -->
          <!-- Titre et description -->
          <!-- Sections de démo -->
          <!-- Code snippets -->
          <!-- Utilisation JavaScript -->
          <!-- Footer avec liens -->
        </div>
      </main>
    </div>
    
    {{> footer}}
  </div>

  <script type="module" src="../../../index.js"></script>
</body>
</html>
```

## 🎨 Styles CSS

Les styles pour les partials et les pages de composants sont **intégrés directement** dans les fichiers HTML via des balises `<style>`.

**Principaux ajouts :**
- `.ds-layout` : Layout principal avec flex
- `.ds-layout__body` : Container pour nav + main
- `.ds-nav` : Navigation latérale sticky
- `.ds-component-page` : Layout des pages de composants
- `.ds-demo-section` : Sections de démonstration
- `.ds-code-details` : Blocs de code avec bouton reveal

## 🧪 Tests

Les composants conservent leur structure de tests existante. Aucune modification n'est nécessaire car :

- Les exports CommonJS sont maintenus (`module.exports`)
- Les tests importent toujours les composants de la même manière
- L'auto-initialisation ne s'exécute pas dans l'environnement de test (pas de `document`)

## 📚 Documentation

### Storybook

Storybook reste inchangé et fonctionne avec les fichiers existants (`.stories.js`).

**Accès :**
```bash
npm run storybook
# → http://localhost:6006
```

### Pages HTML de démo

Les pages HTML servent uniquement à la **démonstration en conditions réelles** :

- Navigation entre les composants
- Exemples interactifs
- Visualisation des variantes et états
- Tests manuels d'accessibilité

## 🔄 Migration depuis l'ancien système

Si vous avez des fichiers existants :

### 1. Sauvegarder vos modifications

```bash
# Créer une branche de sauvegarde
git checkout -b backup-before-handlebars

# Commit de l'état actuel
git add .
git commit -m "Backup avant migration Handlebars"
```

### 2. Appliquer les modifications

```bash
# Copier les nouveaux fichiers
cp -r ds-modifications/* .

# Installer les dépendances
npm install
```

### 3. Vérifier le fonctionnement

```bash
# Tester le build
npm run build

# Tester le dev server
npm run dev

# Tester Storybook
npm run storybook

# Lancer les tests
npm test
```

## ⚠️ Points d'attention

1. **Chemins relatifs** : Les chemins dans les imports CSS/JS doivent être corrects (`../../../`)
2. **Build multi-pages** : Le `vite.config.js` inclut toutes les pages HTML dans `rollupOptions.input`
3. **MutationObserver** : Les composants s'initialisent automatiquement même pour les éléments ajoutés dynamiquement
4. **Handlebars context** : Les variables `{{title}}`, `{{year}}`, `{{version}}` sont disponibles dans tous les partials

## 🆘 Dépannage

### Les partials ne s'affichent pas

Vérifiez que :
- `vite-plugin-handlebars` est installé
- Le `partialDirectory` dans `vite.config.js` pointe vers `src/partials`
- Les fichiers `.hbs` sont bien présents dans `src/partials/`

### Erreur "Cannot find module"

Vérifiez que :
- Les chemins d'import sont corrects (relatifs)
- Les fichiers `.js` existent
- Les extensions `.js` sont présentes dans les imports

### La navigation ne fonctionne pas

Vérifiez que :
- Le composant Accordion est importé dans `index.js`
- Les éléments ont l'attribut `data-toggle="accordion"`
- Le fichier `accordion.js` est correctement chargé

### Les tooltips ne s'affichent pas

Vérifiez que :
- Floating UI est installé (`@floating-ui/dom`)
- Le composant Tooltip est importé dans `index.js`
- Les éléments ont l'attribut `data-toggle="tooltip"`

## 🎉 Résultat final

Après application des modifications :

- ✅ Code HTML factorisé avec Handlebars
- ✅ Navigation améliorée avec accordéon
- ✅ Composants en ES Modules
- ✅ Pages de démo pour chaque composant
- ✅ Build optimisé multi-pages
- ✅ Compatibilité maintenue avec les tests
- ✅ Storybook fonctionnel

## 📞 Support

Pour toute question ou problème, référez-vous à :

- **README.md** du projet principal
- **COMPONENT-CREATION.md** pour créer de nouveaux composants
- **QUICKSTART.md** pour le guide de démarrage
- **Storybook** pour la documentation interactive

---

**Design System © 2026 - Vite 7.2 & Storybook 10**
