import { defineConfig } from 'vite';
import { createHtmlPlugin } from 'vite-plugin-html';
import handlebars from 'vite-plugin-handlebars';
import { ViteImageOptimizer } from 'vite-plugin-image-optimizer';
import { resolve } from 'path';

export default defineConfig({
  root: 'src',
  base: './',
  
  resolve: {
    alias: {
      '@': resolve(__dirname, './src'),
      '@components': resolve(__dirname, './src/components'),
      '@atoms': resolve(__dirname, './src/components/atoms'),
      '@molecules': resolve(__dirname, './src/components/molecules'),
      '@organisms': resolve(__dirname, './src/components/organisms'),
      '@templates': resolve(__dirname, './src/components/templates'),
      '@pages': resolve(__dirname, './src/components/pages'),
      '@styles': resolve(__dirname, './src/assets/styles'),
      '@tokens': resolve(__dirname, './src/assets/styles/tokens'),
      '@utils': resolve(__dirname, './src/utils'),
      '@tests': resolve(__dirname, './tests'),
    }
  },

  plugins: [
    handlebars({
      partialDirectory: resolve(__dirname, 'src/partials'),
      context: {
        title: 'Design System - Vite 7.2 & Storybook 10',
        year: new Date().getFullYear(),
        version: '1.0.0'
      },
      helpers: {
        eq: (a, b) => a === b,
        or: (...args) => args.slice(0, -1).some(Boolean),
        and: (...args) => args.slice(0, -1).every(Boolean)
      }
    }),
    
    ViteImageOptimizer({
      test: /\.(jpe?g|png|gif|svg|webp)$/i,
      png: { quality: 80 },
      jpeg: { quality: 80 },
      webp: { quality: 80 }
    })
  ],

  css: {
    preprocessorOptions: {
      scss: {
        api: 'modern-compiler',
        additionalData: `@use "@styles/tokens/variables" as *;`,
        includePaths: [resolve(__dirname, 'src/assets/styles')]
      }
    },
    transformer: 'lightningcss'
  },

  build: {
    outDir: '../dist',
    emptyOutDir: true,
    
    rollupOptions: {
      input: {
        main: resolve(__dirname, 'src/index.html'),
        button: resolve(__dirname, 'src/components/atoms/button/button.html'),
        accordion: resolve(__dirname, 'src/components/organisms/accordion/accordion.html'),
        tooltip: resolve(__dirname, 'src/components/organisms/tooltip/tooltip.html')
      },
      
      output: {
        entryFileNames: 'assets/js/[name].[hash].js',
        chunkFileNames: 'assets/js/chunks/[name].[hash].js',
        assetFileNames: (assetInfo) => {
          const info = assetInfo.name.split('.');
          const ext = info[info.length - 1];
          
          if (/\.(png|jpe?g|svg|gif|webp|ico)$/i.test(assetInfo.name)) {
            return 'assets/images/[name].[hash][extname]';
          }
          if (/\.(woff2?|eot|ttf|otf)$/i.test(assetInfo.name)) {
            return 'assets/fonts/[name].[hash][extname]';
          }
          if (ext === 'css') {
            return 'assets/css/[name].[hash][extname]';
          }
          return 'assets/[name].[hash][extname]';
        }
      }
    },

    minify: 'terser',
    terserOptions: {
      compress: {
        drop_console: true,
        drop_debugger: true,
        pure_funcs: ['console.log', 'console.info']
      }
    },
    
    cssMinify: 'lightningcss',
    sourcemap: false,
    target: 'es2020',
    
    modulePreload: {
      polyfill: true
    }
  },

  server: {
    port: 3000,
    open: true,
    strictPort: false,
    cors: true
  },

  preview: {
    port: 4173,
    open: true
  }
});
