# Guide de Création de Composants

## Structure d'un Composant

Chaque composant suit cette structure :

```
components/
└── atoms/button/
    ├── button.html        # Template HTML
    ├── button.scss        # Styles
    ├── button.js          # Logique
    ├── button.stories.js  # Documentation Storybook
    └── button.test.js     # Tests unitaires
```

## Créer un Nouveau Composant

### 1. Créer la Structure

```bash
mkdir -p src/components/atoms/my-component
cd src/components/atoms/my-component
touch my-component.{html,scss,js,stories.js,test.js}
```

### 2. HTML Template

```html
<!-- my-component.html -->
<div class="ds-my-component" data-toggle="ds-my-component">
  <p>My Component Content</p>
</div>
```

### 3. Styles SCSS

```scss
// my-component.scss
.ds-my-component {
  padding: var(--spacing-md);
  background: var(--color-background);
  border: 1px solid var(--color-primary);
  border-radius: var(--border-radius-md);
}
```

### 4. Logique JavaScript

```javascript
// my-component.js
(function() {
  'use strict';
  
  class MyComponent {
    constructor(element, options = {}) {
      this.element = element;
      this.options = options;
      this.element._myComponentInstance = this;
      this.init();
    }
    
    init() {
      console.log('MyComponent initialized');
    }
    
    destroy() {
      delete this.element._myComponentInstance;
    }
  }
  
  // Auto-initialisation
  function initComponents() {
    document.querySelectorAll('[data-toggle="ds-my-component"]').forEach(el => {
      if (!el._myComponentInstance) {
        new MyComponent(el);
      }
    });
  }
  
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initComponents);
  } else {
    initComponents();
  }
  
  window.DSMyComponent = MyComponent;
  if (typeof module !== 'undefined') module.exports = MyComponent;
})();
```

### 5. Storybook Story

```javascript
// my-component.stories.js
import './my-component.scss';
import './my-component.js';

export default {
  title: 'Atoms/MyComponent',
  argTypes: {
    content: { control: 'text' },
  },
};

const Template = ({ content }) => {
  const div = document.createElement('div');
  div.className = 'ds-my-component';
  div.setAttribute('data-toggle', 'ds-my-component');
  div.innerHTML = `<p>${content}</p>`;
  return div;
};

export const Default = Template.bind({});
Default.args = {
  content: 'My Component Content',
};
```

### 6. Tests Unitaires

```javascript
// my-component.test.js
import { describe, it, expect, beforeEach, afterEach } from 'vitest';
import './my-component.js';

describe('MyComponent', () => {
  let container;
  
  beforeEach(() => {
    container = document.createElement('div');
    document.body.appendChild(container);
  });
  
  afterEach(() => {
    document.body.innerHTML = '';
  });
  
  it('should initialize', () => {
    container.innerHTML = '<div data-toggle="ds-my-component">Test</div>';
    document.dispatchEvent(new Event('DOMContentLoaded'));
    const el = container.querySelector('[data-toggle="ds-my-component"]');
    expect(el._myComponentInstance).toBeDefined();
  });
});
```

## Bonnes Pratiques

### Naming Convention (BEM)

```scss
.ds-component {}              // Block
.ds-component__element {}     // Element
.ds-component--modifier {}    // Modifier
.ds-component.is-active {}    // State
```

### Auto-initialisation

Utiliser `data-toggle="ds-*"` pour auto-initialisation :

```html
<div data-toggle="ds-my-component"></div>
```

### Variables CSS

Utiliser les tokens définis dans `tokens/_variables.scss` :

```scss
.my-component {
  color: var(--color-primary);
  padding: var(--spacing-md);
  border-radius: var(--border-radius-md);
}
```

### Import des Dépendances

```javascript
// Dans src/index.js ou page spécifique
import '@atoms/my-component/my-component.js';
import '@atoms/my-component/my-component.scss';
```

### Accessibilité

Toujours inclure les attributs ARIA appropriés :

```html
<button 
  class="ds-accordion__header" 
  aria-expanded="false"
  aria-controls="content-1"
  id="header-1"
>
  Section
</button>

<div 
  id="content-1"
  role="region"
  aria-labelledby="header-1"
>
  Content
</div>
```

## Atomic Design Levels

### Atoms
Composants de base non décomposables (button, input, label)

### Molecules
Groupes d'atoms (form-field = label + input)

### Organisms
Composants complexes (header, navigation, accordion)

### Templates
Structures de pages réutilisables

### Pages
Pages complètes spécifiques

## Tester le Composant

```bash
# Dev avec HMR
npm run dev

# Storybook
npm run storybook

# Tests
npm run test

# Build
npm run build
```

## Checklist

- [ ] HTML template créé
- [ ] SCSS avec BEM
- [ ] JS avec auto-initialisation
- [ ] Story Storybook fonctionnelle
- [ ] Tests unitaires passent
- [ ] Accessibilité vérifiée
- [ ] Documentation inline (JSDoc)
- [ ] Import dans index.js si nécessaire
