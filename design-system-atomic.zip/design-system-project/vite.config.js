import { defineConfig } from 'vite';
import { resolve } from 'path';
import { readdirSync, statSync, existsSync } from 'fs';
import { fileURLToPath } from 'url';
import viteCompression from 'vite-plugin-compression';
import { createSvgIconsPlugin } from 'vite-plugin-svg-icons';
import viteImagemin from '@vheemstra/vite-plugin-imagemin';
import imageminMozjpeg from 'imagemin-mozjpeg';
import imageminPngquant from 'imagemin-pngquant';
import imageminSvgo from 'imagemin-svgo';
import imageminGifsicle from 'imagemin-gifsicle';

const __dirname = fileURLToPath(new URL('.', import.meta.url));

/**
 * Scanner récursif pour trouver tous les composants
 * @param {string} baseDir - Chemin de base (ex: 'src/components')
 * @returns {Object} Map des composants { 'atoms/button': '/path/to/button.js' }
 */
function scanComponents(baseDir) {
  const components = {};
  const categories = ['atoms', 'molecules', 'organisms', 'templates'];

  categories.forEach(category => {
    const categoryPath = resolve(__dirname, baseDir, category);
    
    if (!existsSync(categoryPath)) {
      console.warn(`⚠️  Dossier ${category} non trouvé`);
      return;
    }

    const items = readdirSync(categoryPath);
    
    items.forEach(item => {
      const itemPath = resolve(categoryPath, item);
      const stat = statSync(itemPath);
      
      if (stat.isDirectory()) {
        // Chercher le fichier JS principal
        const jsFile = resolve(itemPath, `${item}.js`);
        if (existsSync(jsFile)) {
          components[`components-${category}-${item}`] = jsFile;
        }
      }
    });
  });

  return components;
}

/**
 * Scanner les pages HTML
 * @param {string} baseDir - Chemin vers les pages
 * @returns {Object} Map des pages HTML
 */
function scanHTMLPages(baseDir) {
  const pages = {};
  const pagesPath = resolve(__dirname, baseDir);
  
  if (!existsSync(pagesPath)) {
    return pages;
  }

  const files = readdirSync(pagesPath);
  
  files.forEach(file => {
    if (file.endsWith('.html')) {
      const name = file.replace('.html', '');
      pages[name === 'index' ? 'index' : `pages-${name}`] = resolve(pagesPath, file);
    }
  });

  return pages;
}

export default defineConfig({
  root: resolve(__dirname, 'src'),
  publicDir: resolve(__dirname, 'public'),
  
  build: {
    outDir: resolve(__dirname, 'dist'),
    emptyOutDir: true,
    
    // Minification
    minify: 'terser',
    terserOptions: {
      compress: {
        drop_console: true,
        drop_debugger: true,
        pure_funcs: ['console.log', 'console.info', 'console.debug'],
        passes: 2, // Vite 8 - améliore la compression
      },
      format: {
        comments: false,
      },
      mangle: {
        safari10: true, // Vite 8 - fix Safari 10/11 bugs
      },
    },
    
    // Configuration CSS
    cssMinify: 'lightningcss', // Vite 8 - plus rapide que esbuild
    cssCodeSplit: true,
    
    // Source maps (désactiver en production)
    sourcemap: false,
    
    // Taille des chunks
    chunkSizeWarningLimit: 1000,
    
    // Assets inline limit
    assetsInlineLimit: 4096,
    
    rollupOptions: {
      input: {
        // Page principale (index.html à la racine)
        main: resolve(__dirname, 'src/index.html'),
        
        // Pages HTML dans components/pages/
        ...scanHTMLPages('src/components/pages'),
        
        // Point d'entrée principal JS
        index: resolve(__dirname, 'src/index.js'),
        
        // Composants individuels
        ...scanComponents('src/components'),
      },
      
      output: {
        // Organisation des fichiers JS
        entryFileNames: (chunkInfo) => {
          const name = chunkInfo.name;
          
          // Point d'entrée principal
          if (name === 'index') {
            return 'assets/js/bundle.[hash].min.js';
          }
          
          // Composants atoms/molecules/organisms
          if (name.startsWith('components-')) {
            const parts = name.split('-'); // ['components', 'atoms', 'button']
            const category = parts[1]; // atoms, molecules, organisms, templates
            const component = parts[2]; // button
            return `components/${category}/${component}/${component}.[hash].min.js`;
          }
          
          // Pages
          if (name.startsWith('pages-')) {
            return 'assets/js/pages/[name].[hash].min.js';
          }
          
          // Fallback
          return 'assets/js/[name].[hash].min.js';
        },
        
        // Organisation des chunks (code splitting)
        chunkFileNames: (chunkInfo) => {
          // Vendors (node_modules)
          if (chunkInfo.name === 'vendor' || /node_modules/.test(chunkInfo.moduleIds?.join('') || '')) {
            return 'assets/js/vendors.[hash].min.js';
          }
          
          // Autres chunks partagés
          return 'assets/js/chunks.[hash].min.js';
        },
        
        // Organisation des assets (CSS, images, fonts)
        assetFileNames: (assetInfo) => {
          const name = assetInfo.name || '';
          const ext = name.split('.').pop();
          
          // CSS
          if (ext === 'css') {
            // CSS de composants
            if (name.includes('components/')) {
              const match = name.match(/components\/(atoms|molecules|organisms|templates)\/([^/]+)/);
              if (match) {
                const category = match[1];
                const component = match[2];
                return `components/${category}/${component}/${component}.[hash].min.css`;
              }
            }
            
            // CSS principal
            if (name.includes('main')) {
              return 'assets/css/main.[hash].min.css';
            }
            
            // Autres CSS
            return 'assets/css/[name].[hash].min.css';
          }
          
          // Fonts
          if (/\.(woff2?|eot|ttf|otf)$/i.test(ext)) {
            return 'assets/fonts/[name].[hash][extname]';
          }
          
          // Images
          if (/\.(png|jpe?g|gif|webp|avif)$/i.test(ext)) {
            return 'assets/images/[name].[hash][extname]';
          }
          
          // SVG
          if (ext === 'svg') {
            return 'assets/images/svg/[name].[hash][extname]';
          }
          
          // Autres assets
          return 'assets/[name].[hash][extname]';
        },
        
        // Configuration du manuel chunking
        manualChunks: (id) => {
          // Vendor chunk pour node_modules
          if (id.includes('node_modules')) {
            // Séparer les gros vendors si besoin
            if (id.includes('@floating-ui')) {
              return 'vendor-floating';
            }
            return 'vendor';
          }
          
          // Chunk pour les utilitaires partagés
          if (id.includes('src/assets/js/chunks')) {
            return 'chunks';
          }
        },
      },
      
      // Vite 8 - Optimisations Rollup avancées
      treeshake: {
        moduleSideEffects: 'no-external',
        propertyReadSideEffects: false,
        tryCatchDeoptimization: false,
      },
    },
  },
  
  // Configuration CSS/SASS
  css: {
    preprocessorOptions: {
      scss: {
        api: 'modern-compiler', // Vite 8 - nouveau compilateur Sass
        // Import automatique des tokens et variables
        additionalData: `
          @use "@/assets/styles/tokens/_variables.scss" as *;
        `,
        // Chemins de recherche pour @import
        loadPaths: [
          resolve(__dirname, 'src/assets/styles'),
        ],
        // Vite 8 - Options du modern compiler
        silenceDeprecations: ['legacy-js-api'],
      },
    },
    
    // Vite 8 - Lightning CSS par défaut
    transformer: 'lightningcss',
    
    lightningcss: {
      targets: {
        chrome: 95,
        firefox: 91,
        safari: 14,
        edge: 95,
      },
      drafts: {
        nesting: true, // Support du CSS nesting natif
      },
    },
  },
  
  // Plugins
  plugins: [
    // Compression Gzip
    viteCompression({
      algorithm: 'gzip',
      ext: '.gz',
      threshold: 10240, // Fichiers > 10KB
      deleteOriginFile: false,
      compressionOptions: {
        level: 9, // Niveau de compression max
      },
    }),
    
    // Compression Brotli (meilleure que Gzip)
    viteCompression({
      algorithm: 'brotliCompress',
      ext: '.br',
      threshold: 10240,
      deleteOriginFile: false,
      compressionOptions: {
        params: {
          [require('zlib').constants.BROTLI_PARAM_QUALITY]: 11, // Max quality
          [require('zlib').constants.BROTLI_PARAM_MODE]: require('zlib').constants.BROTLI_MODE_TEXT,
        },
      },
    }),
    
    // Optimisation des images (compatible Vite 8)
    viteImagemin({
      plugins: {
        jpg: imageminMozjpeg({
          quality: 80,
          progressive: true,
        }),
        png: imageminPngquant({
          quality: [0.8, 0.9],
          speed: 4,
          strip: true,
        }),
        gif: imageminGifsicle({
          optimizationLevel: 7,
          interlaced: false,
        }),
        svg: imageminSvgo({
          plugins: [
            {
              name: 'preset-default',
              params: {
                overrides: {
                  removeViewBox: false,
                  cleanupIDs: true,
                },
              },
            },
            {
              name: 'removeEmptyAttrs',
            },
            {
              name: 'removeScriptElement',
            },
            {
              name: 'removeStyleElement',
            },
          ],
        }),
      },
      makeWebp: {
        plugins: {
          jpg: imageminMozjpeg({
            quality: 80,
          }),
          png: imageminPngquant({
            quality: [0.8, 0.9],
          }),
        },
      },
    }),
    
    // SVG Sprites (optionnel)
    createSvgIconsPlugin({
      iconDirs: [resolve(__dirname, 'src/assets/images/svg')],
      symbolId: 'icon-[dir]-[name]',
      inject: 'body-last',
      customDomId: '__svg__icons__dom__',
    }),
  ],
  
  // Configuration du serveur de dev (Vite 8)
  server: {
    port: 3000,
    open: true,
    cors: true,
    host: true,
    // Vite 8 - Pre-bundling amélioré
    preTransformRequests: true,
    warmup: {
      clientFiles: [
        './src/index.html',
        './src/index.js',
        './src/assets/styles/main.scss',
      ],
    },
  },
  
  // Preview du build
  preview: {
    port: 4173,
    open: true,
  },
  
  // Résolution des modules
  resolve: {
    alias: {
      '@': resolve(__dirname, 'src'),
      '@components': resolve(__dirname, 'src/components'),
      '@atoms': resolve(__dirname, 'src/components/atoms'),
      '@molecules': resolve(__dirname, 'src/components/molecules'),
      '@organisms': resolve(__dirname, 'src/components/organisms'),
      '@templates': resolve(__dirname, 'src/components/templates'),
      '@pages': resolve(__dirname, 'src/components/pages'),
      '@assets': resolve(__dirname, 'src/assets'),
      '@styles': resolve(__dirname, 'src/assets/styles'),
      '@images': resolve(__dirname, 'src/assets/images'),
      '@fonts': resolve(__dirname, 'src/assets/fonts'),
      '@js': resolve(__dirname, 'src/assets/js'),
    },
  },
  
  // Vite 8 - Optimisation des dépendances améliorée
  optimizeDeps: {
    include: ['@floating-ui/dom'],
    exclude: [],
    force: false, // Vite 8 - auto-détection améliorée
    esbuildOptions: {
      target: 'es2020',
    },
  },
  
  // Vite 8 - Environment API (nouveau)
  environments: {
    client: {
      build: {
        target: 'es2020',
        rollupOptions: {
          output: {
            format: 'es',
          },
        },
      },
    },
  },
});
