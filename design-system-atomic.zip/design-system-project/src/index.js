import '@/assets/styles/main.scss';
import '@/components/atoms/button/button.js';
import '@/components/atoms/button/button.scss';
import '@/components/organisms/accordion/accordion.js';
import '@/components/organisms/accordion/accordion.scss';
import '@/components/organisms/tooltip/tooltip.js';
import '@/components/organisms/tooltip/tooltip.scss';

console.log('Design System initialized');
