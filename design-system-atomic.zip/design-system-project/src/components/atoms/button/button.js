(function() {
  'use strict';
  class Button {
    constructor(element) {
      this.element = element;
      this.element._buttonInstance = this;
    }
    destroy() {
      delete this.element._buttonInstance;
    }
  }
  function init() {
    document.querySelectorAll('[data-toggle="ds-button"]').forEach(el => {
      if (!el._buttonInstance) new Button(el);
    });
  }
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
  window.DSButton = Button;
  if (typeof module !== 'undefined') module.exports = Button;
})();
