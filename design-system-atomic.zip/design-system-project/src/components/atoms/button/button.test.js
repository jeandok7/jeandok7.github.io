import { describe, it, expect, beforeEach, afterEach } from 'vitest';
import './button.js';

describe('Button', () => {
  let container;
  beforeEach(() => {
    container = document.createElement('div');
    document.body.appendChild(container);
  });
  afterEach(() => {
    document.body.innerHTML = '';
  });
  
  it('should initialize', () => {
    container.innerHTML = '<button data-toggle="ds-button">Test</button>';
    document.dispatchEvent(new Event('DOMContentLoaded'));
    const btn = container.querySelector('button');
    expect(btn._buttonInstance).toBeDefined();
  });
});
