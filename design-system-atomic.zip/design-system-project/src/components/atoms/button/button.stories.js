import './button.scss';
import './button.js';

export default {
  title: 'Atoms/Button',
  argTypes: {
    variant: {
      control: 'select',
      options: ['primary', 'secondary', 'outline'],
    },
    label: { control: 'text' },
  },
};

const Template = ({ label, variant }) => {
  const button = document.createElement('button');
  button.className = `ds-button ds-button--${variant}`;
  button.textContent = label;
  button.setAttribute('data-toggle', 'ds-button');
  return button;
};

export const Primary = Template.bind({});
Primary.args = { label: 'Primary Button', variant: 'primary' };

export const Secondary = Template.bind({});
Secondary.args = { label: 'Secondary Button', variant: 'secondary' };

export const Outline = Template.bind({});
Outline.args = { label: 'Outline Button', variant: 'outline' };
