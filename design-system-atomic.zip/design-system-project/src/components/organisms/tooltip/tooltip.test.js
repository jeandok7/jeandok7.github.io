import { describe, it, expect, beforeEach, afterEach, vi } from 'vitest';
import './tooltip.js';

// Mock FloatingUI
global.FloatingUIDOM = {
  computePosition: vi.fn().mockResolvedValue({ x: 100, y: 100 }),
  offset: vi.fn(() => ({})),
  flip: vi.fn(() => ({})),
};

describe('Tooltip', () => {
  let container;
  beforeEach(() => {
    container = document.createElement('div');
    document.body.appendChild(container);
  });
  afterEach(() => {
    document.body.innerHTML = '';
  });
  
  it('should create tooltip', () => {
    container.innerHTML = '<button data-toggle="ds-tooltip" data-tooltip="Test">Btn</button>';
    document.dispatchEvent(new Event('DOMContentLoaded'));
    const btn = container.querySelector('button');
    expect(btn._tooltipInstance).toBeDefined();
  });
});
