import './tooltip.scss';
import './tooltip.js';

export default {
  title: 'Organisms/Tooltip',
};

export const Default = () => {
  const button = document.createElement('button');
  button.className = 'ds-button ds-button--primary';
  button.textContent = 'Hover me';
  button.setAttribute('data-toggle', 'ds-tooltip');
  button.setAttribute('data-tooltip', 'This is a tooltip!');
  return button;
};
