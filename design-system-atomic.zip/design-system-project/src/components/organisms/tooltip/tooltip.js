(function() {
  const hasFloatingUI = typeof FloatingUIDOM !== 'undefined';
  if (!hasFloatingUI) {
    console.warn('Tooltip: FloatingUI requis');
    return;
  }
  const { computePosition, offset, flip } = FloatingUIDOM;
  
  class Tooltip {
    constructor(trigger) {
      this.trigger = trigger;
      this.trigger._tooltipInstance = this;
      this.tooltip = null;
      this.isVisible = false;
      this.init();
    }
    init() {
      this.createTooltip();
      this.trigger.addEventListener('mouseenter', () => this.show());
      this.trigger.addEventListener('mouseleave', () => this.hide());
    }
    createTooltip() {
      const content = this.trigger.dataset.tooltip;
      if (!content) return;
      this.tooltip = document.createElement('div');
      this.tooltip.className = 'ds-tooltip';
      this.tooltip.textContent = content;
      this.tooltip.setAttribute('hidden', '');
      document.body.appendChild(this.tooltip);
    }
    async show() {
      if (!this.tooltip) return;
      this.isVisible = true;
      this.tooltip.removeAttribute('hidden');
      await this.updatePosition();
    }
    hide() {
      if (!this.tooltip) return;
      this.isVisible = false;
      this.tooltip.setAttribute('hidden', '');
    }
    async updatePosition() {
      const { x, y } = await computePosition(this.trigger, this.tooltip, {
        placement: 'top',
        middleware: [offset(8), flip()],
      });
      Object.assign(this.tooltip.style, { left: `${x}px`, top: `${y}px` });
    }
    destroy() {
      if (this.tooltip) this.tooltip.remove();
      delete this.trigger._tooltipInstance;
    }
  }
  function init() {
    document.querySelectorAll('[data-toggle="ds-tooltip"]').forEach(el => {
      if (!el._tooltipInstance) new Tooltip(el);
    });
  }
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
  window.DSTooltip = Tooltip;
  if (typeof module !== 'undefined') module.exports = Tooltip;
})();
