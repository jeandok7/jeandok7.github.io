(function() {
  class Accordion {
    constructor(element) {
      this.element = element;
      this.element._accordionInstance = this;
      this.init();
    }
    init() {
      const headers = this.element.querySelectorAll('.ds-accordion__header');
      headers.forEach(header => {
        header.addEventListener('click', () => this.toggle(header));
      });
    }
    toggle(header) {
      const content = header.nextElementSibling;
      const isExpanded = header.getAttribute('aria-expanded') === 'true';
      header.setAttribute('aria-expanded', !isExpanded);
      content.classList.toggle('is-active');
    }
    destroy() {
      delete this.element._accordionInstance;
    }
  }
  function init() {
    document.querySelectorAll('[data-toggle="ds-accordion"]').forEach(el => {
      if (!el._accordionInstance) new Accordion(el);
    });
  }
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
  window.DSAccordion = Accordion;
  if (typeof module !== 'undefined') module.exports = Accordion;
})();
