import './accordion.scss';
import './accordion.js';

export default {
  title: 'Organisms/Accordion',
};

export const Default = () => {
  const div = document.createElement('div');
  div.innerHTML = `
    <div class="ds-accordion" data-toggle="ds-accordion">
      <div class="ds-accordion__item">
        <button class="ds-accordion__header" aria-expanded="false">Section 1</button>
        <div class="ds-accordion__content"><div class="ds-accordion__body"><p>Content 1</p></div></div>
      </div>
      <div class="ds-accordion__item">
        <button class="ds-accordion__header" aria-expanded="false">Section 2</button>
        <div class="ds-accordion__content"><div class="ds-accordion__body"><p>Content 2</p></div></div>
      </div>
    </div>
  `;
  return div;
};
