import { describe, it, expect, beforeEach, afterEach } from 'vitest';
import { fireEvent } from '@testing-library/dom';
import './accordion.js';

describe('Accordion', () => {
  let container;
  beforeEach(() => {
    container = document.createElement('div');
    document.body.appendChild(container);
  });
  afterEach(() => {
    document.body.innerHTML = '';
  });
  
  it('should toggle on click', () => {
    container.innerHTML = `
      <div class="ds-accordion" data-toggle="ds-accordion">
        <div class="ds-accordion__item">
          <button class="ds-accordion__header" aria-expanded="false">Test</button>
          <div class="ds-accordion__content"></div>
        </div>
      </div>
    `;
    document.dispatchEvent(new Event('DOMContentLoaded'));
    const header = container.querySelector('.ds-accordion__header');
    fireEvent.click(header);
    expect(header.getAttribute('aria-expanded')).toBe('true');
  });
});
