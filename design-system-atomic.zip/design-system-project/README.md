# Design System - Atomic Design

Design System moderne en Vanilla JavaScript avec Vite 6 et Storybook 8.

## 🚀 Quick Start

```bash
npm install
npm run dev          # Dev sur http://localhost:3000
npm run storybook    # Storybook sur http://localhost:6006
npm run build        # Build production
```

## 📁 Structure

```
src/
├── components/      # Atomic Design
│   ├── atoms/       # button, input, label
│   ├── molecules/   # form-field
│   ├── organisms/   # accordion, tooltip
│   ├── templates/
│   └── pages/
├── assets/
│   ├── styles/      # SCSS (tokens, base, utilities)
│   ├── images/
│   ├── fonts/
│   └── js/
└── index.{html,js}
```

## 🎯 Composants Disponibles

### Atoms
- **Button** : Boutons avec variantes (primary, secondary, outline)

### Organisms
- **Accordion** : Accordéon avec gestion ARIA
- **Tooltip** : Tooltip avec Floating UI

## 📦 Build

```bash
npm run build
```

Génère `dist/` avec :
- Assets minifiés (CSS, JS)
- Compression Gzip + Brotli
- Images optimisées
- Cache-busting (hash)

## 📖 Documentation

- [Quick Start](./QUICKSTART.md) - Installation rapide
- [Component Creation](./COMPONENT-CREATION.md) - Créer des composants

## 🧪 Tests

```bash
npm run test             # Tests unitaires
npm run test:ui          # Interface Vitest
npm run test:coverage    # Couverture
```

## 🛠️ Technologies

- **Vite 6.0.5** - Build ultra-rapide
- **Storybook 8.6.15** - Documentation
- **Vitest** - Tests unitaires
- **SASS** - Préprocesseur CSS
- **Lightning CSS** - Minification CSS
- **Floating UI** - Positionnement tooltip

## 📄 Licence

MIT
