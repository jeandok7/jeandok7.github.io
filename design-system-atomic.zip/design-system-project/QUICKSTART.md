# Quick Start Guide

## Installation

### Prérequis
- Node.js >= 18.0.0
- npm >= 9.0.0

### Installation

```bash
npm install
```

## Développement

### Démarrer le serveur de dev

```bash
npm run dev
```

Ouvre automatiquement http://localhost:3000

### Lancer Storybook

```bash
npm run storybook
```

Documentation interactive sur http://localhost:6006

## Utiliser les Composants

### Button

```html
<!-- HTML -->
<button class="ds-button ds-button--primary" data-toggle="ds-button">
  Primary Button
</button>
```

```javascript
// JavaScript (optionnel pour button)
import '@atoms/button/button.js';
import '@atoms/button/button.scss';
```

### Accordion

```html
<!-- HTML -->
<div class="ds-accordion" data-toggle="ds-accordion">
  <div class="ds-accordion__item">
    <button class="ds-accordion__header" aria-expanded="false">Section 1</button>
    <div class="ds-accordion__content">
      <div class="ds-accordion__body">
        <p>Contenu</p>
      </div>
    </div>
  </div>
</div>
```

```javascript
// JavaScript (auto-initialisation)
import '@organisms/accordion/accordion.js';
import '@organisms/accordion/accordion.scss';
```

### Tooltip

```html
<!-- HTML -->
<button data-toggle="ds-tooltip" data-tooltip="Message">Hover me</button>

<!-- CDN Floating UI requis -->
<script src="https://cdn.jsdelivr.net/npm/@floating-ui/dom@1.6.13/dist/floating-ui.dom.min.js"></script>
```

```javascript
// JavaScript
import '@organisms/tooltip/tooltip.js';
import '@organisms/tooltip/tooltip.scss';
```

## Build Production

```bash
npm run build
```

Génère `dist/` avec structure optimisée.

## Tests

```bash
npm run test              # Watch mode
npm run test:coverage     # Avec couverture
```

## Commandes Disponibles

| Commande | Description |
|----------|-------------|
| `npm run dev` | Serveur de développement |
| `npm run build` | Build production |
| `npm run preview` | Preview du build |
| `npm run storybook` | Storybook dev |
| `npm run build-storybook` | Build Storybook |
| `npm run test` | Tests (watch) |
| `npm run test:ui` | Interface Vitest |
| `npm run test:coverage` | Couverture tests |

## Prochaines Étapes

1. Consulter [COMPONENT-CREATION.md](./COMPONENT-CREATION.md) pour créer des composants
2. Lire les stories dans `.stories.js` pour les exemples d'usage
3. Voir les tests dans `.test.js` pour comprendre le comportement
