import { createButton } from './button.js'
import './button.scss'

export default {
  title: 'Atoms/Button',
  tags: ['autodocs'],
  argTypes: {
    label: { 
      control: 'text',
      description: 'Texte affiché dans le bouton'
    },
    variant: {
      control: 'select',
      options: ['primary', 'secondary', 'outline', 'danger'],
      description: 'Style du bouton'
    },
    size: {
      control: 'radio',
      options: ['sm', 'md', 'lg'],
      description: 'Taille du bouton'
    },
    disabled: {
      control: 'boolean',
      description: 'État désactivé'
    },
    block: {
      control: 'boolean',
      description: 'Prend toute la largeur disponible'
    },
    onClick: { action: 'clicked' }
  },
  parameters: {
    docs: {
      description: {
        component: `
# Button Component

Composant bouton conforme RGAA avec :
- ✅ Contraste minimum 4.5:1
- ✅ Zone tactile minimum 44x44px
- ✅ Focus visible
- ✅ Support clavier
- ✅ États hover/active/disabled
- ✅ Respect prefers-reduced-motion

## Accessibility

Ce composant respecte les critères RGAA :
- **Critère 10.3** : Contraste des couleurs suffisant
- **Critère 7.1** : Chaque script est, si nécessaire, compatible avec les technologies d'assistance
- **Critère 10.7** : Pour chaque élément recevant le focus, la prise de focus est-elle visible ?
        `
      }
    },
    a11y: {
      config: {
        rules: [
          {
            id: 'color-contrast',
            enabled: true
          },
          {
            id: 'button-name',
            enabled: true
          }
        ]
      }
    }
  }
}

// Story par défaut
export const Primary = {
  args: {
    label: 'Primary Button',
    variant: 'primary',
    size: 'md',
    disabled: false,
    block: false
  },
  render: (args) => {
    const button = createButton(args)
    button.addEventListener('click', args.onClick)
    return button
  }
}

export const Secondary = {
  args: {
    ...Primary.args,
    label: 'Secondary Button',
    variant: 'secondary'
  },
  render: Primary.render
}

export const Outline = {
  args: {
    ...Primary.args,
    label: 'Outline Button',
    variant: 'outline'
  },
  render: Primary.render
}

export const Danger = {
  args: {
    ...Primary.args,
    label: 'Danger Button',
    variant: 'danger'
  },
  render: Primary.render
}

export const Small = {
  args: {
    ...Primary.args,
    label: 'Small Button',
    size: 'sm'
  },
  render: Primary.render
}

export const Large = {
  args: {
    ...Primary.args,
    label: 'Large Button',
    size: 'lg'
  },
  render: Primary.render
}

export const Disabled = {
  args: {
    ...Primary.args,
    label: 'Disabled Button',
    disabled: true
  },
  render: Primary.render
}

export const Block = {
  args: {
    ...Primary.args,
    label: 'Block Button',
    block: true
  },
  render: Primary.render
}

export const WithIcon = {
  args: {
    ...Primary.args,
    label: 'Button with Icon',
    icon: '<svg width="16" height="16" viewBox="0 0 16 16" fill="currentColor"><path d="M8 0a8 8 0 100 16A8 8 0 008 0zm1 11H7V7h2v4zm0-5H7V4h2v2z"/></svg>'
  },
  render: Primary.render
}

// Playground interactif
export const Playground = {
  args: Primary.args,
  render: Primary.render
}
