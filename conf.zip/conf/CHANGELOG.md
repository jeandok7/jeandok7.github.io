# Changelog - Button

Toutes les modifications notées dans ce fichier suivent [Semantic Versioning](https://semver.org/).

## [1.4.0] - 2026-01-12
### Added
- Ajout de la prop `loading` avec spinner intégré
- Ajout des variantes `tertiary` et `icon-only`

### Changed
- Ajustement des paddings

### Fixed
- Correction du focus visible sous Windows

## [1.3.0] - 2025-12-20
### Added
- Ajout de la prop `size="sm"`

### Fixed
- Correction du bug de double clic
