#!/usr/bin/env node

import fs from "fs";
import path from "path";
import matter from "gray-matter";

const ROOT = path.join(process.cwd());
const COMPONENTS_DIR = path.join(ROOT, "src/components");

// Helper pour lire les changelogs
function readChangelog(filePath) {
  const content = fs.readFileSync(filePath, "utf-8");
  const lines = content.split("\n");

  const versions = [];
  let current = null;

  lines.forEach((line) => {
    const versionMatch = line.match(/^## \[(\d+\.\d+\.\d+)\] - (\d{4}-\d{2}-\d{2})/);
    if (versionMatch) {
      if (current) versions.push(current);
      current = {
        version: versionMatch[1],
        date: versionMatch[2],
        changes: []
      };
    } else if (current) {
      current.changes.push(line);
    }
  });

  if (current) versions.push(current);
  return versions;
}

// Find all CHANGELOG.md files recursively
function findChangelogs(dir) {
  let files = [];

  fs.readdirSync(dir, { withFileTypes: true }).forEach((entry) => {
    const fullPath = path.join(dir, entry.name);
    if (entry.isDirectory()) {
      files.push(...findChangelogs(fullPath));
    } else if (entry.isFile() && entry.name === "CHANGELOG.md") {
      files.push(fullPath);
    }
  });

  return files;
}

// Main
function generateGlobalChangelog() {
  const changelogFiles = findChangelogs(COMPONENTS_DIR);
  const allVersions = [];

  changelogFiles.forEach((file) => {
    const componentName = path.basename(path.dirname(file));
    const versions = readChangelog(file);

    versions.forEach((v) => {
      allVersions.push({
        component: componentName,
        ...v,
      });
    });
  });

  // Sort by date desc, then by version
  allVersions.sort((a, b) => {
    const da = new Date(a.date),
      db = new Date(b.date);
    if (da > db) return -1;
    if (da < db) return 1;
    return b.version.localeCompare(a.version);
  });

  const globalMd = [
    "# Changelog Global",
    "",
    "Toutes les modifications des composants triées par date (plus récentes en premier).",
    ""
  ];

  allVersions.forEach((entry) => {
    globalMd.push(
      `## [${entry.version}] - ${entry.date} - **${entry.component}**`
    );
    globalMd.push(...entry.changes, "");
  });

  fs.writeFileSync(path.join(ROOT, "CHANGELOG_GLOBAL.md"), globalMd.join("\n"));
  console.log("✅ CHANGELOG_GLOBAL.md généré !");
}

generateGlobalChangelog();
