# Design System - Vite 7.2 & Storybook 10

Un Design System moderne et complet construit avec **Vanilla JavaScript**, suivant l'architecture **Atomic Design**, propulsé par **Vite 7.2** et documenté avec **Storybook 10**.

## 🎯 Vue d'ensemble

Ce Design System fournit une collection de composants UI réutilisables, testés et documentés, conçus pour créer des interfaces cohérentes et accessibles. Tous les composants s'auto-initialisent via l'attribut `data-toggle` pour une utilisation simple, sans nécessiter de framework JavaScript.

### Caractéristiques principales

- ✅ **Vanilla JavaScript** - Aucune dépendance framework, compatibilité maximale
- ✅ **Atomic Design** - Organisation claire (Atoms, Molecules, Organisms, Templates, Pages)
- ✅ **Auto-initialisation** - Composants Bootstrap-like avec `data-toggle`
- ✅ **Vite 7.2** - Build ultra-rapide, HMR instantané
- ✅ **Storybook 10** - Documentation interactive des composants
- ✅ **Design Tokens** - Système de tokens avec Style Dictionary
- ✅ **Accessibilité** - ARIA complet, navigation clavier
- ✅ **Tests unitaires** - Vitest avec couverture de code
- ✅ **TypeScript-ready** - Types disponibles via JSDoc
- ✅ **SEO-friendly** - Pas de Web Components, HTML natif

## 🚀 Quick Start

### Prérequis

- Node.js >= 20.0.0
- npm >= 10.0.0

### Installation

```bash
# Cloner le projet
git clone <repository-url>
cd design-system-vite7-storybook10

# Installer les dépendances
npm install

# Générer les design tokens
npm run build-tokens
```

### Développement

```bash
# Démarrer le serveur de développement (port 3000)
npm run dev

# Démarrer Storybook (port 6006)
npm run storybook
```

### Build de production

```bash
# Build des assets
npm run build

# Prévisualiser le build
npm run preview

# Build de Storybook
npm run build-storybook
```

### Tests

```bash
# Lancer les tests
npm test

# Tests avec UI
npm run test:ui

# Coverage
npm run test:coverage
```

## 📁 Structure du projet

```
design-system-vite7-storybook10/
├── src/
│   ├── components/          # Composants Atomic Design
│   │   ├── atoms/           # Composants de base
│   │   │   └── button/
│   │   ├── molecules/       # Compositions d'atoms
│   │   ├── organisms/       # Composants complexes
│   │   │   ├── accordion/
│   │   │   └── tooltip/
│   │   ├── templates/       # Templates de pages
│   │   └── pages/           # Pages complètes
│   │
│   ├── assets/
│   │   └── styles/
│   │       ├── tokens/      # Design tokens (généré)
│   │       ├── base/        # Reset, typography
│   │       ├── utilities/   # Classes utilitaires
│   │       └── main.scss    # Point d'entrée
│   │
│   ├── index.html           # Page de démo
│   └── index.js             # Point d'entrée JS
│
├── tokens/                  # Configuration des tokens JSON
├── tests/                   # Configuration tests
├── .storybook/              # Configuration Storybook
├── vite.config.js           # Configuration Vite 7.2
├── vitest.config.js         # Configuration Vitest
└── package.json
```

## 🎨 Composants disponibles

### Atoms
- **Button** - Bouton avec variantes (primary, secondary, outline, ghost), tailles, états

### Organisms
- **Accordion** - Accordéon avec navigation clavier, ARIA complet, API publique
- **Tooltip** - Tooltip avec Floating UI, multiple triggers, placement intelligent

## 🎭 Technologies utilisées

### Build & Dev Tools
- **Vite 7.2** - Build tool moderne et ultra-rapide
- **Rollup** - Bundler pour la production
- **Lightning CSS** - Minification CSS performante
- **Terser** - Minification JavaScript

### Styling
- **SASS (Modern Compiler)** - Préprocesseur CSS avec API moderne
- **Style Dictionary** - Génération de design tokens
- **BEM** - Naming convention pour les classes CSS

### Testing
- **Vitest** - Framework de test rapide et compatible Vite
- **@testing-library/dom** - Utilitaires de test DOM
- **happy-dom** - Environnement DOM pour les tests

### Documentation
- **Storybook 10** - Documentation interactive des composants
- **lit-html** - Templating pour les stories

### Dépendances
- **@floating-ui/dom** - Positionnement intelligent pour tooltip

## 📦 Build Production

Le build de production génère des fichiers optimisés :

```
dist/
├── assets/
│   ├── css/
│   │   └── main.[hash].min.css         # + .gz + .br
│   ├── js/
│   │   ├── bundle.[hash].min.js        # + .gz + .br
│   │   ├── vendors.[hash].min.js       # node_modules séparés
│   │   └── chunks/[name].[hash].min.js
│   ├── fonts/                          # Fonts optimisés
│   └── images/                         # Images optimisées
│
├── components/                         # Composants individuels
│   ├── atoms/button/
│   ├── organisms/accordion/
│   └── organisms/tooltip/
│
└── index.html
```

### Optimisations incluses

- ✅ Minification JavaScript (Terser niveau max)
- ✅ Minification CSS (Lightning CSS)
- ✅ Compression Gzip (niveau 9)
- ✅ Compression Brotli (niveau 11)
- ✅ Optimisation images (PNG, JPEG, SVG, WebP)
- ✅ Tree-shaking automatique
- ✅ Code splitting intelligent
- ✅ Cache busting (hash dans les noms de fichiers)

## 🎯 Utilisation des composants

### Méthode 1 : Auto-initialisation (Recommandé)

Les composants s'auto-initialisent via l'attribut `data-toggle` :

```html
<!-- Button avec ripple -->
<button class="ds-button ds-button--primary ds-button--ripple" 
        data-toggle="ds-button-ripple">
  Click me
</button>

<!-- Accordion -->
<div class="ds-accordion" data-toggle="ds-accordion">
  <!-- items... -->
</div>

<!-- Tooltip -->
<button data-toggle="ds-tooltip" 
        data-tooltip-content="Hello!"
        data-tooltip-placement="top">
  Hover me
</button>
```

### Méthode 2 : Initialisation programmatique

```javascript
import { DSAccordion, DSTooltip } from './index.js';

// Accordion
const accordion = new DSAccordion(element, {
  allowMultiple: true
});

// Tooltip
const tooltip = new DSTooltip(element, {
  content: 'My tooltip',
  placement: 'top',
  trigger: 'hover'
});

// API publique
accordion.open(0);
accordion.close(1);
accordion.toggle(2);
tooltip.show();
tooltip.hide();
```

## 🌐 Design Tokens

Les design tokens sont générés automatiquement depuis `tokens/design-tokens.json` :

```bash
npm run build-tokens
```

Cela génère :
- `src/assets/styles/tokens/_variables.scss` - Variables SCSS référençant CSS vars
- Variables CSS dans `:root` pour theming dynamique

### Structure des tokens

```json
{
  "color": { "primary": { "value": "#007bff" } },
  "spacing": { "md": { "value": "1rem" } },
  "font": { "size": { "base": { "value": "1rem" } } },
  "borderRadius": { "md": { "value": "0.375rem" } },
  "shadow": { "md": { "value": "..." } },
  "transition": { "base": { "value": "300ms" } }
}
```

## ♿ Accessibilité

Tous les composants respectent les standards WCAG 2.1 Level AA :

- ✅ **ARIA complet** - Tous les attributs ARIA nécessaires
- ✅ **Navigation clavier** - Support complet du clavier
- ✅ **Focus visible** - Indicateurs de focus clairs
- ✅ **Annonces screen reader** - Contenus accessibles
- ✅ **Reduced motion** - Support prefers-reduced-motion

## 📝 Scripts disponibles

```bash
npm run dev              # Serveur de développement (port 3000)
npm run build            # Build de production
npm run preview          # Prévisualiser le build
npm run storybook        # Lancer Storybook (port 6006)
npm run build-storybook  # Build de Storybook
npm test                 # Lancer les tests
npm run test:ui          # Tests avec interface UI
npm run test:coverage    # Tests avec couverture
npm run lint             # Linter le code
npm run format           # Formater le code
npm run build-tokens     # Générer les design tokens
```

## 📚 Documentation

- **[QUICKSTART.md](./QUICKSTART.md)** - Guide de démarrage rapide et exemples d'utilisation
- **[COMPONENT-CREATION.md](./COMPONENT-CREATION.md)** - Guide pour créer de nouveaux composants
- **Storybook** - Documentation interactive (lancez `npm run storybook`)

## 🤝 Contribution

1. Fork le projet
2. Créer une branche (`git checkout -b feature/amazing-feature`)
3. Commit les changements (`git commit -m 'Add amazing feature'`)
4. Push vers la branche (`git push origin feature/amazing-feature`)
5. Ouvrir une Pull Request

## 📄 Licence

MIT License - voir [LICENSE](./LICENSE) pour plus de détails

## 🙏 Remerciements

- **Vite** - Build tool moderne
- **Storybook** - Documentation de composants
- **Floating UI** - Positionnement intelligent
- **Style Dictionary** - Gestion des design tokens
- **Brad Frost** - Atomic Design methodology

---

**Construit avec ❤️ et Vanilla JavaScript**
