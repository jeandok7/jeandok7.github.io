import { describe, it, expect, beforeEach, afterEach, vi } from 'vitest';
import './button.js';

describe('Button Component', () => {
  let container;

  beforeEach(() => {
    container = document.createElement('div');
    document.body.appendChild(container);
  });

  afterEach(() => {
    document.body.innerHTML = '';
  });

  describe('ButtonRipple', () => {
    it('should auto-initialize on buttons with data-toggle attribute', () => {
      container.innerHTML = `
        <button class="ds-button ds-button--ripple" data-toggle="ds-button-ripple" type="button">
          Ripple Button
        </button>
      `;

      const button = container.querySelector('[data-toggle="ds-button-ripple"]');
      const event = new Event('DOMContentLoaded');
      document.dispatchEvent(event);

      expect(button._buttonRippleInstance).toBeDefined();
    });

    it('should add rippling class on click', () => {
      container.innerHTML = `
        <button class="ds-button ds-button--ripple" data-toggle="ds-button-ripple" type="button">
          Ripple Button
        </button>
      `;

      const button = container.querySelector('[data-toggle="ds-button-ripple"]');
      const rippleInstance = new window.DSButtonRipple(button);

      button.click();

      expect(button.classList.contains('is-rippling')).toBe(true);
    });

    it('should remove rippling class after animation', (done) => {
      container.innerHTML = `
        <button class="ds-button ds-button--ripple" data-toggle="ds-button-ripple" type="button">
          Ripple Button
        </button>
      `;

      const button = container.querySelector('[data-toggle="ds-button-ripple"]');
      const rippleInstance = new window.DSButtonRipple(button);

      button.click();

      setTimeout(() => {
        expect(button.classList.contains('is-rippling')).toBe(false);
        done();
      }, 550);
    });

    it('should be able to destroy instance', () => {
      container.innerHTML = `
        <button class="ds-button ds-button--ripple" data-toggle="ds-button-ripple" type="button">
          Ripple Button
        </button>
      `;

      const button = container.querySelector('[data-toggle="ds-button-ripple"]');
      const rippleInstance = new window.DSButtonRipple(button);

      expect(button._buttonRippleInstance).toBeDefined();

      rippleInstance.destroy();

      expect(button._buttonRippleInstance).toBeUndefined();
    });

    it('should initialize dynamically added buttons', (done) => {
      const newButton = document.createElement('button');
      newButton.className = 'ds-button ds-button--ripple';
      newButton.setAttribute('data-toggle', 'ds-button-ripple');
      newButton.textContent = 'Dynamic Button';

      container.appendChild(newButton);

      setTimeout(() => {
        expect(newButton._buttonRippleInstance).toBeDefined();
        done();
      }, 100);
    });
  });

  describe('Button Styles', () => {
    it('should render with correct base classes', () => {
      container.innerHTML = `
        <button class="ds-button ds-button--primary" type="button">
          Primary Button
        </button>
      `;

      const button = container.querySelector('.ds-button');
      expect(button).toBeDefined();
      expect(button.classList.contains('ds-button--primary')).toBe(true);
    });

    it('should support different variants', () => {
      container.innerHTML = `
        <button class="ds-button ds-button--primary" type="button">Primary</button>
        <button class="ds-button ds-button--secondary" type="button">Secondary</button>
        <button class="ds-button ds-button--outline" type="button">Outline</button>
        <button class="ds-button ds-button--ghost" type="button">Ghost</button>
      `;

      expect(container.querySelector('.ds-button--primary')).toBeDefined();
      expect(container.querySelector('.ds-button--secondary')).toBeDefined();
      expect(container.querySelector('.ds-button--outline')).toBeDefined();
      expect(container.querySelector('.ds-button--ghost')).toBeDefined();
    });

    it('should support different sizes', () => {
      container.innerHTML = `
        <button class="ds-button ds-button--primary ds-button--sm" type="button">Small</button>
        <button class="ds-button ds-button--primary" type="button">Default</button>
        <button class="ds-button ds-button--primary ds-button--lg" type="button">Large</button>
      `;

      expect(container.querySelector('.ds-button--sm')).toBeDefined();
      expect(container.querySelector('.ds-button--lg')).toBeDefined();
    });

    it('should handle disabled state', () => {
      container.innerHTML = `
        <button class="ds-button ds-button--primary" type="button" disabled>
          Disabled Button
        </button>
      `;

      const button = container.querySelector('.ds-button');
      expect(button.disabled).toBe(true);
    });

    it('should handle loading state', () => {
      container.innerHTML = `
        <button class="ds-button ds-button--primary ds-button--loading" type="button">
          <span class="ds-button__spinner"></span>
          Loading...
        </button>
      `;

      const button = container.querySelector('.ds-button');
      const spinner = button.querySelector('.ds-button__spinner');

      expect(button.classList.contains('ds-button--loading')).toBe(true);
      expect(spinner).toBeDefined();
    });
  });
});
