/**
 * Button Component - Ripple Effect
 */

export default class ButtonRipple {
  constructor(element) {
    if (!element) {
      throw new Error('Button element is required');
    }

    this.element = element;
    this.handleClick = this.handleClick.bind(this);
    this.element._buttonRippleInstance = this;
    this.init();
  }

  init() {
    this.element.addEventListener('click', this.handleClick);
  }

  handleClick() {
    this.element.classList.remove('is-rippling');
    void this.element.offsetWidth;
    this.element.classList.add('is-rippling');

    setTimeout(() => {
      this.element.classList.remove('is-rippling');
    }, 500);
  }

  destroy() {
    this.element.removeEventListener('click', this.handleClick);
    delete this.element._buttonRippleInstance;
  }
}

/**
 * Auto-init
 */
export function initButtonRipples(root = document) {
  root
    .querySelectorAll('[data-toggle="ds-button-ripple"]')
    .forEach(button => {
      if (!button._buttonRippleInstance) {
        new ButtonRipple(button);
      }
    });
}

/**
 * DOM ready
 */
if (typeof window !== 'undefined') {
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', () => initButtonRipples());
  } else {
    initButtonRipples();
  }

  // MutationObserver
  if (typeof MutationObserver !== 'undefined') {
    const observer = new MutationObserver(mutations => {
      mutations.forEach(mutation => {
        mutation.addedNodes.forEach(node => {
          if (node.nodeType === 1) {
            initButtonRipples(node);
          }
        });
      });
    });

    observer.observe(document.body, {
      childList: true,
      subtree: true
    });
  }
}
