import { describe, it, expect, beforeEach, afterEach, vi } from 'vitest';
import { computePosition } from '@floating-ui/dom';
import './tooltip.js';

// Mock Floating UI
vi.mock('@floating-ui/dom', () => ({
  computePosition: vi.fn(() => Promise.resolve({
    x: 100,
    y: 100,
    placement: 'top',
    middlewareData: {
      arrow: { x: 50, y: null }
    }
  })),
  flip: vi.fn(() => ({})),
  shift: vi.fn(() => ({})),
  offset: vi.fn(() => ({})),
  arrow: vi.fn(() => ({}))
}));

describe('Tooltip Component', () => {
  let container;

  beforeEach(() => {
    container = document.createElement('div');
    document.body.appendChild(container);
  });

  afterEach(() => {
    document.body.innerHTML = '';
    vi.clearAllMocks();
  });

  describe('Initialization', () => {
    it('should auto-initialize tooltip with data-toggle attribute', () => {
      container.innerHTML = `
        <button data-toggle="ds-tooltip" data-tooltip-content="Test tooltip">
          Hover me
        </button>
      `;

      const button = container.querySelector('[data-toggle="ds-tooltip"]');
      const event = new Event('DOMContentLoaded');
      document.dispatchEvent(event);

      expect(button._tooltipInstance).toBeDefined();
    });

    it('should create tooltip element in body', () => {
      container.innerHTML = `
        <button data-toggle="ds-tooltip" data-tooltip-content="Test tooltip">
          Hover me
        </button>
      `;

      const button = container.querySelector('[data-toggle="ds-tooltip"]');
      new window.DSTooltip(button);

      const tooltip = document.querySelector('.ds-tooltip');
      expect(tooltip).toBeDefined();
      expect(tooltip.textContent).toContain('Test tooltip');
    });

    it('should set ARIA attributes', () => {
      container.innerHTML = `
        <button data-toggle="ds-tooltip" data-tooltip-content="Test tooltip">
          Hover me
        </button>
      `;

      const button = container.querySelector('[data-toggle="ds-tooltip"]');
      const instance = new window.DSTooltip(button);

      expect(button.getAttribute('aria-describedby')).toBeTruthy();
    });

    it('should support HTML content from template', () => {
      container.innerHTML = `
        <button data-toggle="ds-tooltip" data-tooltip-html="#custom-content">
          Hover me
        </button>
        <template id="custom-content">
          <strong>Bold text</strong>
        </template>
      `;

      const button = container.querySelector('[data-toggle="ds-tooltip"]');
      const instance = new window.DSTooltip(button);

      const tooltip = document.querySelector('.ds-tooltip');
      expect(tooltip.querySelector('strong')).toBeDefined();
    });
  });

  describe('Hover Trigger', () => {
    it('should show tooltip on mouseenter', async () => {
      container.innerHTML = `
        <button data-toggle="ds-tooltip" data-tooltip-content="Test tooltip" data-tooltip-trigger="hover">
          Hover me
        </button>
      `;

      const button = container.querySelector('[data-toggle="ds-tooltip"]');
      const instance = new window.DSTooltip(button);

      button.dispatchEvent(new Event('mouseenter'));

      await new Promise(resolve => setTimeout(resolve, 50));

      const tooltip = document.querySelector('.ds-tooltip');
      expect(tooltip.classList.contains('is-visible')).toBe(true);
    });

    it('should hide tooltip on mouseleave', async () => {
      container.innerHTML = `
        <button data-toggle="ds-tooltip" data-tooltip-content="Test tooltip" data-tooltip-trigger="hover">
          Hover me
        </button>
      `;

      const button = container.querySelector('[data-toggle="ds-tooltip"]');
      const instance = new window.DSTooltip(button);

      button.dispatchEvent(new Event('mouseenter'));
      await new Promise(resolve => setTimeout(resolve, 50));

      button.dispatchEvent(new Event('mouseleave'));

      const tooltip = document.querySelector('.ds-tooltip');
      expect(tooltip.classList.contains('is-visible')).toBe(false);
    });
  });

  describe('Click Trigger', () => {
    it('should toggle tooltip on click', async () => {
      container.innerHTML = `
        <button data-toggle="ds-tooltip" data-tooltip-content="Test tooltip" data-tooltip-trigger="click">
          Click me
        </button>
      `;

      const button = container.querySelector('[data-toggle="ds-tooltip"]');
      const instance = new window.DSTooltip(button);

      button.click();
      await new Promise(resolve => setTimeout(resolve, 50));

      const tooltip = document.querySelector('.ds-tooltip');
      expect(tooltip.classList.contains('is-visible')).toBe(true);

      button.click();
      expect(tooltip.classList.contains('is-visible')).toBe(false);
    });

    it('should close tooltip on outside click', async () => {
      container.innerHTML = `
        <button data-toggle="ds-tooltip" data-tooltip-content="Test tooltip" data-tooltip-trigger="click">
          Click me
        </button>
        <div id="outside">Outside</div>
      `;

      const button = container.querySelector('[data-toggle="ds-tooltip"]');
      const outside = container.querySelector('#outside');
      const instance = new window.DSTooltip(button);

      button.click();
      await new Promise(resolve => setTimeout(resolve, 50));

      const tooltip = document.querySelector('.ds-tooltip');
      expect(tooltip.classList.contains('is-visible')).toBe(true);

      outside.click();
      expect(tooltip.classList.contains('is-visible')).toBe(false);
    });
  });

  describe('Focus Trigger', () => {
    it('should show tooltip on focus', async () => {
      container.innerHTML = `
        <button data-toggle="ds-tooltip" data-tooltip-content="Test tooltip" data-tooltip-trigger="focus">
          Focus me
        </button>
      `;

      const button = container.querySelector('[data-toggle="ds-tooltip"]');
      const instance = new window.DSTooltip(button);

      button.dispatchEvent(new Event('focus'));
      await new Promise(resolve => setTimeout(resolve, 50));

      const tooltip = document.querySelector('.ds-tooltip');
      expect(tooltip.classList.contains('is-visible')).toBe(true);
    });

    it('should hide tooltip on blur', async () => {
      container.innerHTML = `
        <button data-toggle="ds-tooltip" data-tooltip-content="Test tooltip" data-tooltip-trigger="focus">
          Focus me
        </button>
      `;

      const button = container.querySelector('[data-toggle="ds-tooltip"]');
      const instance = new window.DSTooltip(button);

      button.dispatchEvent(new Event('focus'));
      await new Promise(resolve => setTimeout(resolve, 50));

      button.dispatchEvent(new Event('blur'));

      const tooltip = document.querySelector('.ds-tooltip');
      expect(tooltip.classList.contains('is-visible')).toBe(false);
    });
  });

  describe('Positioning with Floating UI', () => {
    it('should call computePosition when showing tooltip', async () => {
      container.innerHTML = `
        <button data-toggle="ds-tooltip" data-tooltip-content="Test tooltip">
          Hover me
        </button>
      `;

      const button = container.querySelector('[data-toggle="ds-tooltip"]');
      const instance = new window.DSTooltip(button);

      await instance.show();

      expect(computePosition).toHaveBeenCalled();
    });

    it('should apply position from Floating UI', async () => {
      container.innerHTML = `
        <button data-toggle="ds-tooltip" data-tooltip-content="Test tooltip">
          Hover me
        </button>
      `;

      const button = container.querySelector('[data-toggle="ds-tooltip"]');
      const instance = new window.DSTooltip(button);

      await instance.show();

      const tooltip = document.querySelector('.ds-tooltip');
      expect(tooltip.style.left).toBe('100px');
      expect(tooltip.style.top).toBe('100px');
    });

    it('should respect placement option', () => {
      container.innerHTML = `
        <button data-toggle="ds-tooltip" data-tooltip-content="Test tooltip" data-tooltip-placement="bottom">
          Hover me
        </button>
      `;

      const button = container.querySelector('[data-toggle="ds-tooltip"]');
      const instance = new window.DSTooltip(button);

      expect(instance.options.placement).toBe('bottom');
    });
  });

  describe('Public API', () => {
    it('should provide show() method', async () => {
      container.innerHTML = `
        <button data-toggle="ds-tooltip" data-tooltip-content="Test tooltip">
          Hover me
        </button>
      `;

      const button = container.querySelector('[data-toggle="ds-tooltip"]');
      const instance = new window.DSTooltip(button);

      await instance.show();

      const tooltip = document.querySelector('.ds-tooltip');
      expect(tooltip.classList.contains('is-visible')).toBe(true);
    });

    it('should provide hide() method', async () => {
      container.innerHTML = `
        <button data-toggle="ds-tooltip" data-tooltip-content="Test tooltip">
          Hover me
        </button>
      `;

      const button = container.querySelector('[data-toggle="ds-tooltip"]');
      const instance = new window.DSTooltip(button);

      await instance.show();
      instance.hide();

      const tooltip = document.querySelector('.ds-tooltip');
      expect(tooltip.classList.contains('is-visible')).toBe(false);
    });

    it('should provide toggle() method', async () => {
      container.innerHTML = `
        <button data-toggle="ds-tooltip" data-tooltip-content="Test tooltip">
          Hover me
        </button>
      `;

      const button = container.querySelector('[data-toggle="ds-tooltip"]');
      const instance = new window.DSTooltip(button);

      await instance.toggle();
      const tooltip = document.querySelector('.ds-tooltip');
      expect(tooltip.classList.contains('is-visible')).toBe(true);

      instance.toggle();
      expect(tooltip.classList.contains('is-visible')).toBe(false);
    });

    it('should destroy instance properly', () => {
      container.innerHTML = `
        <button data-toggle="ds-tooltip" data-tooltip-content="Test tooltip">
          Hover me
        </button>
      `;

      const button = container.querySelector('[data-toggle="ds-tooltip"]');
      const instance = new window.DSTooltip(button);

      const tooltip = document.querySelector('.ds-tooltip');
      expect(tooltip).toBeDefined();

      instance.destroy();

      expect(button._tooltipInstance).toBeUndefined();
      expect(button.getAttribute('aria-describedby')).toBeNull();
      expect(document.querySelector('.ds-tooltip')).toBeNull();
    });
  });

  describe('Custom Events', () => {
    it('should dispatch shown event', async (done) => {
      container.innerHTML = `
        <button data-toggle="ds-tooltip" data-tooltip-content="Test tooltip">
          Hover me
        </button>
      `;

      const button = container.querySelector('[data-toggle="ds-tooltip"]');
      const instance = new window.DSTooltip(button);

      button.addEventListener('ds-tooltip:shown', (event) => {
        expect(event.detail.tooltip).toBeInstanceOf(window.DSTooltip);
        done();
      });

      await instance.show();
    });

    it('should dispatch hidden event', (done) => {
      container.innerHTML = `
        <button data-toggle="ds-tooltip" data-tooltip-content="Test tooltip">
          Hover me
        </button>
      `;

      const button = container.querySelector('[data-toggle="ds-tooltip"]');
      const instance = new window.DSTooltip(button);

      button.addEventListener('ds-tooltip:hidden', (event) => {
        expect(event.detail.tooltip).toBeInstanceOf(window.DSTooltip);
        done();
      });

      instance.show().then(() => {
        instance.hide();
      });
    });
  });

  describe('Dynamic Content', () => {
    it('should initialize dynamically added tooltips', (done) => {
      const newButton = document.createElement('button');
      newButton.setAttribute('data-toggle', 'ds-tooltip');
      newButton.setAttribute('data-tooltip-content', 'Dynamic tooltip');
      newButton.textContent = 'Dynamic Button';

      container.appendChild(newButton);

      setTimeout(() => {
        expect(newButton._tooltipInstance).toBeDefined();
        done();
      }, 100);
    });
  });
});
