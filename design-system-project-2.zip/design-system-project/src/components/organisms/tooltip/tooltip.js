/**
 * Tooltip Component - Organism
 * Floating UI positioning
 */

import {
  computePosition,
  flip,
  shift,
  offset,
  arrow as floatingArrow
} from '@floating-ui/dom';

export default class Tooltip {
  constructor(element, options = {}) {
    if (!element) {
      throw new Error('Tooltip element is required');
    }

    this.element = element;
    this.options = {
      content: element.dataset.tooltipContent || options.content || '',
      html: element.dataset.tooltipHtml || options.html || null,
      placement:
        element.dataset.tooltipPlacement || options.placement || 'top',
      trigger:
        element.dataset.tooltipTrigger || options.trigger || 'hover',
      offset:
        parseInt(element.dataset.tooltipOffset, 10) ||
        options.offset ||
        8,
      ...options
    };

    this.tooltip = null;
    this.arrowElement = null;
    this.isVisible = false;

    this.handleClick = this.handleClick.bind(this);
    this.handleOutsideClick = this.handleOutsideClick.bind(this);
    this.show = this.show.bind(this);
    this.hide = this.hide.bind(this);

    this.element._tooltipInstance = this;

    this.init();
  }

  init() {
    this.createTooltip();
    this.setupEventListeners();
    this.element.setAttribute('aria-describedby', this.tooltip.id);
  }

  createTooltip() {
    this.tooltip = document.createElement('div');
    this.tooltip.className = 'ds-tooltip';
    this.tooltip.id = `ds-tooltip-${this.generateId()}`;
    this.tooltip.setAttribute('role', 'tooltip');

    const arrow = document.createElement('div');
    arrow.className = 'ds-tooltip__arrow';
    this.tooltip.appendChild(arrow);
    this.arrowElement = arrow;

    const content = document.createElement('div');
    content.className = 'ds-tooltip__content';

    if (this.options.html) {
      const template = document.querySelector(this.options.html);
      if (template?.content) {
        content.appendChild(template.content.cloneNode(true));
      } else {
        content.innerHTML = this.options.html;
      }
    } else {
      content.textContent = this.options.content;
    }

    this.tooltip.appendChild(content);
    document.body.appendChild(this.tooltip);
  }

  setupEventListeners() {
    switch (this.options.trigger) {
      case 'click':
        this.element.addEventListener('click', this.handleClick);
        document.addEventListener('click', this.handleOutsideClick);
        break;

      case 'focus':
        this.element.addEventListener('focus', this.show);
        this.element.addEventListener('blur', this.hide);
        break;

      case 'hover':
      default:
        this.element.addEventListener('mouseenter', this.show);
        this.element.addEventListener('mouseleave', this.hide);
        this.element.addEventListener('focus', this.show);
        this.element.addEventListener('blur', this.hide);
        break;
    }
  }

  handleClick(event) {
    event.stopPropagation();
    this.toggle();
  }

  handleOutsideClick(event) {
    if (
      !this.element.contains(event.target) &&
      !this.tooltip.contains(event.target)
    ) {
      this.hide();
    }
  }

  async show() {
    if (this.isVisible) return;

    this.isVisible = true;
    this.tooltip.classList.add('is-visible');

    await this.updatePosition();
    this.dispatchEvent('shown');
  }

  hide() {
    if (!this.isVisible) return;

    this.isVisible = false;
    this.tooltip.classList.remove('is-visible');
    this.dispatchEvent('hidden');
  }

  toggle() {
    this.isVisible ? this.hide() : this.show();
  }

  async updatePosition() {
    const { x, y, placement, middlewareData } =
      await computePosition(this.element, this.tooltip, {
        placement: this.options.placement,
        middleware: [
          offset(this.options.offset),
          flip(),
          shift({ padding: 5 }),
          floatingArrow({ element: this.arrowElement })
        ]
      });

    Object.assign(this.tooltip.style, {
      left: `${x}px`,
      top: `${y}px`
    });

    this.tooltip.setAttribute('data-placement', placement);

    if (middlewareData.arrow) {
      const { x: ax, y: ay } = middlewareData.arrow;
      const side = {
        top: 'bottom',
        right: 'left',
        bottom: 'top',
        left: 'right'
      }[placement.split('-')[0]];

      Object.assign(this.arrowElement.style, {
        left: ax != null ? `${ax}px` : '',
        top: ay != null ? `${ay}px` : '',
        right: '',
        bottom: '',
        [side]: '-4px'
      });
    }
  }

  generateId() {
    return `${Date.now()}-${Math.random().toString(36).slice(2)}`;
  }

  dispatchEvent(name, detail = {}) {
    this.element.dispatchEvent(
      new CustomEvent(`ds-tooltip:${name}`, {
        bubbles: true,
        detail: { tooltip: this, ...detail }
      })
    );
  }

  destroy() {
    this.element.removeEventListener('click', this.handleClick);
    this.element.removeEventListener('mouseenter', this.show);
    this.element.removeEventListener('mouseleave', this.hide);
    this.element.removeEventListener('focus', this.show);
    this.element.removeEventListener('blur', this.hide);
    document.removeEventListener('click', this.handleOutsideClick);

    this.tooltip?.remove();
    this.element.removeAttribute('aria-describedby');

    delete this.element._tooltipInstance;
  }
}

/**
 * Auto-init
 */
export function initTooltips(root = document) {
  root
    .querySelectorAll('[data-toggle="ds-tooltip"]')
    .forEach(element => {
      if (!element._tooltipInstance) {
        new Tooltip(element);
      }
    });
}

/**
 * DOM + MutationObserver
 */
if (typeof window !== 'undefined') {
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', () =>
      initTooltips()
    );
  } else {
    initTooltips();
  }

  if (typeof MutationObserver !== 'undefined') {
    const observer = new MutationObserver(mutations => {
      mutations.forEach(mutation => {
        mutation.addedNodes.forEach(node => {
          if (node.nodeType === 1) {
            initTooltips(node);
          }
        });
      });
    });

    observer.observe(document.body, {
      childList: true,
      subtree: true
    });
  }
}
