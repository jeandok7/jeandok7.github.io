import { html } from 'lit-html';
import './tooltip.scss';
import './tooltip.js';
import '../../../assets/styles/main.scss';

/**
 * Tooltip Component Story
 */
export default {
  title: 'Organisms/Tooltip',
  tags: ['autodocs'],
  argTypes: {
    content: {
      control: 'text',
      description: 'Tooltip content text'
    },
    placement: {
      control: 'select',
      options: ['top', 'right', 'bottom', 'left'],
      description: 'Tooltip placement'
    },
    trigger: {
      control: 'select',
      options: ['hover', 'click', 'focus'],
      description: 'Trigger type'
    }
  }
};

/**
 * Template de base
 */
const Template = ({ content = 'This is a tooltip', placement = 'top', trigger = 'hover' }) => html`
  <div style="padding: 100px; text-align: center;">
    <button class="ds-button ds-button--primary"
            data-toggle="ds-tooltip"
            data-tooltip-content="${content}"
            data-tooltip-placement="${placement}"
            data-tooltip-trigger="${trigger}">
      ${trigger === 'hover' ? 'Hover Me' : trigger === 'click' ? 'Click Me' : 'Focus Me'}
    </button>
  </div>
`;

/**
 * Stories
 */
export const Default = Template.bind({});
Default.args = {
  content: 'This is a default tooltip',
  placement: 'top',
  trigger: 'hover'
};

export const OnRight = Template.bind({});
OnRight.args = {
  content: 'Tooltip on the right side',
  placement: 'right',
  trigger: 'hover'
};

export const OnBottom = Template.bind({});
OnBottom.args = {
  content: 'Tooltip on the bottom',
  placement: 'bottom',
  trigger: 'hover'
};

export const OnLeft = Template.bind({});
OnLeft.args = {
  content: 'Tooltip on the left side',
  placement: 'left',
  trigger: 'hover'
};

export const ClickTrigger = Template.bind({});
ClickTrigger.args = {
  content: 'Click to toggle this tooltip',
  placement: 'top',
  trigger: 'click'
};

export const FocusTrigger = Template.bind({});
FocusTrigger.args = {
  content: 'Focus to show this tooltip',
  placement: 'top',
  trigger: 'focus'
};

/**
 * All Placements Demo
 */
export const AllPlacements = () => html`
  <div style="display: flex; gap: 2rem; padding: 150px; justify-content: center; align-items: center;">
    <button class="ds-button ds-button--primary"
            data-toggle="ds-tooltip"
            data-tooltip-content="Tooltip on top"
            data-tooltip-placement="top">
      Top
    </button>

    <button class="ds-button ds-button--primary"
            data-toggle="ds-tooltip"
            data-tooltip-content="Tooltip on right"
            data-tooltip-placement="right">
      Right
    </button>

    <button class="ds-button ds-button--primary"
            data-toggle="ds-tooltip"
            data-tooltip-content="Tooltip on bottom"
            data-tooltip-placement="bottom">
      Bottom
    </button>

    <button class="ds-button ds-button--primary"
            data-toggle="ds-tooltip"
            data-tooltip-content="Tooltip on left"
            data-tooltip-placement="left">
      Left
    </button>
  </div>
`;

/**
 * With HTML Content
 */
export const WithHTMLContent = () => html`
  <div style="padding: 100px; text-align: center;">
    <button class="ds-button ds-button--primary"
            data-toggle="ds-tooltip"
            data-tooltip-html="#custom-html-tooltip">
      HTML Tooltip
    </button>

    <template id="custom-html-tooltip">
      <div>
        <strong>Rich HTML Content</strong><br>
        <em>This tooltip supports HTML!</em><br>
        <code>console.log('Hello');</code>
      </div>
    </template>
  </div>
`;

/**
 * Long Content
 */
export const LongContent = () => html`
  <div style="padding: 100px; text-align: center;">
    <button class="ds-button ds-button--primary"
            data-toggle="ds-tooltip"
            data-tooltip-content="This is a tooltip with a much longer content to demonstrate how it handles text wrapping and maximum width constraints. The tooltip should wrap nicely."
            data-tooltip-placement="top">
      Long Content Tooltip
    </button>
  </div>
`;

/**
 * Disabled Element
 */
export const DisabledElement = () => html`
  <div style="padding: 100px; text-align: center;">
    <span data-toggle="ds-tooltip"
          data-tooltip-content="This button is disabled"
          style="display: inline-block;">
      <button class="ds-button ds-button--primary" disabled>
        Disabled Button
      </button>
    </span>
  </div>
`;

/**
 * Multiple Tooltips
 */
export const MultipleTooltips = () => html`
  <div style="display: flex; gap: 1rem; padding: 100px; justify-content: center; flex-wrap: wrap;">
    <button class="ds-button ds-button--primary"
            data-toggle="ds-tooltip"
            data-tooltip-content="First tooltip">
      Button 1
    </button>

    <button class="ds-button ds-button--secondary"
            data-toggle="ds-tooltip"
            data-tooltip-content="Second tooltip"
            data-tooltip-placement="right">
      Button 2
    </button>

    <button class="ds-button ds-button--outline"
            data-toggle="ds-tooltip"
            data-tooltip-content="Third tooltip"
            data-tooltip-placement="bottom">
      Button 3
    </button>

    <button class="ds-button ds-button--ghost"
            data-toggle="ds-tooltip"
            data-tooltip-content="Fourth tooltip"
            data-tooltip-placement="left">
      Button 4
    </button>
  </div>
`;
