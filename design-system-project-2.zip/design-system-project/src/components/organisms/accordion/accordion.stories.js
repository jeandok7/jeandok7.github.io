import { html } from 'lit-html';
import './accordion.scss';
import './accordion.js';

/**
 * Accordion Component Story
 */
export default {
  title: 'Organisms/Accordion',
  tags: ['autodocs'],
  argTypes: {
    allowMultiple: {
      control: 'boolean',
      description: 'Allow multiple items to be open at the same time'
    },
    itemsCount: {
      control: { type: 'range', min: 2, max: 6, step: 1 },
      description: 'Number of accordion items'
    }
  }
};

/**
 * Template de base
 */
const Template = ({ allowMultiple = false, itemsCount = 3 }) => {
  const items = Array.from({ length: itemsCount }, (_, i) => i + 1);

  return html`
    <div class="ds-accordion" data-toggle="ds-accordion" data-allow-multiple="${allowMultiple}">
      ${items.map(num => html`
        <div class="ds-accordion__item">
          <button class="ds-accordion__trigger"
                  type="button"
                  aria-expanded="false"
                  aria-controls="accordion-item-${num}">
            <span class="ds-accordion__title">Accordion Item #${num}</span>
            <span class="ds-accordion__icon" aria-hidden="true"></span>
          </button>
          <div class="ds-accordion__content"
               id="accordion-item-${num}"
               role="region"
               hidden>
            <div class="ds-accordion__body">
              This is the content of accordion item #${num}. It contains some text and information 
              that can be expanded or collapsed. Lorem ipsum dolor sit amet, consectetur adipiscing elit.
            </div>
          </div>
        </div>
      `)}
    </div>
  `;
};

/**
 * Stories
 */
export const Default = Template.bind({});
Default.args = {
  allowMultiple: false,
  itemsCount: 3
};

export const AllowMultiple = Template.bind({});
AllowMultiple.args = {
  allowMultiple: true,
  itemsCount: 3
};

export const ManyItems = Template.bind({});
ManyItems.args = {
  allowMultiple: false,
  itemsCount: 6
};

/**
 * With Default Open
 */
export const WithDefaultOpen = () => html`
  <div class="ds-accordion" data-toggle="ds-accordion">
    <div class="ds-accordion__item ds-accordion__item--active">
      <button class="ds-accordion__trigger"
              type="button"
              aria-expanded="true"
              aria-controls="default-open-1">
        <span class="ds-accordion__title">Default Open Item</span>
        <span class="ds-accordion__icon" aria-hidden="true"></span>
      </button>
      <div class="ds-accordion__content"
           id="default-open-1"
           role="region">
        <div class="ds-accordion__body">
          This item is open by default when the page loads.
        </div>
      </div>
    </div>

    <div class="ds-accordion__item">
      <button class="ds-accordion__trigger"
              type="button"
              aria-expanded="false"
              aria-controls="default-closed-1">
        <span class="ds-accordion__title">Closed Item</span>
        <span class="ds-accordion__icon" aria-hidden="true"></span>
      </button>
      <div class="ds-accordion__content"
           id="default-closed-1"
           role="region"
           hidden>
        <div class="ds-accordion__body">
          This item is closed by default.
        </div>
      </div>
    </div>
  </div>
`;

/**
 * With Rich Content
 */
export const WithRichContent = () => html`
  <div class="ds-accordion" data-toggle="ds-accordion">
    <div class="ds-accordion__item">
      <button class="ds-accordion__trigger"
              type="button"
              aria-expanded="false"
              aria-controls="rich-content-1">
        <span class="ds-accordion__title">Rich Content Example</span>
        <span class="ds-accordion__icon" aria-hidden="true"></span>
      </button>
      <div class="ds-accordion__content"
           id="rich-content-1"
           role="region"
           hidden>
        <div class="ds-accordion__body">
          <h4>Title in Content</h4>
          <p>This accordion supports rich HTML content including:</p>
          <ul>
            <li>Lists</li>
            <li>Images</li>
            <li>Links</li>
            <li>Code blocks</li>
          </ul>
          <pre><code>const example = "code block";</code></pre>
        </div>
      </div>
    </div>
  </div>
`;

/**
 * API Usage Example
 */
export const APIUsage = () => {
  setTimeout(() => {
    const accordion = document.querySelector('[data-toggle="ds-accordion"]');
    if (accordion && accordion._accordionInstance) {
      // Exemple d'utilisation de l'API
      console.log('Accordion API available:', accordion._accordionInstance);
    }
  }, 100);

  return html`
    <div class="ds-accordion" data-toggle="ds-accordion">
      <div class="ds-accordion__item">
        <button class="ds-accordion__trigger"
                type="button"
                aria-expanded="false"
                aria-controls="api-item-1">
          <span class="ds-accordion__title">Item 1</span>
          <span class="ds-accordion__icon" aria-hidden="true"></span>
        </button>
        <div class="ds-accordion__content"
             id="api-item-1"
             role="region"
             hidden>
          <div class="ds-accordion__body">
            Content 1
          </div>
        </div>
      </div>

      <div class="ds-accordion__item">
        <button class="ds-accordion__trigger"
                type="button"
                aria-expanded="false"
                aria-controls="api-item-2">
          <span class="ds-accordion__title">Item 2</span>
          <span class="ds-accordion__icon" aria-hidden="true"></span>
        </button>
        <div class="ds-accordion__content"
             id="api-item-2"
             role="region"
             hidden>
          <div class="ds-accordion__body">
            Content 2
          </div>
        </div>
      </div>
    </div>

    <div style="margin-top: 1rem; display: flex; gap: 0.5rem;">
      <button class="ds-button ds-button--primary" onclick="document.querySelector('[data-toggle=ds-accordion]')._accordionInstance.openAll()">
        Open All
      </button>
      <button class="ds-button ds-button--secondary" onclick="document.querySelector('[data-toggle=ds-accordion]')._accordionInstance.closeAll()">
        Close All
      </button>
    </div>
  `;
};
