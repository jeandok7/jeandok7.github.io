/**
 * Design System - Main JavaScript Entry Point
 * 
 * Ce fichier importe tous les composants pour les rendre disponibles
 * dans l'application. Chaque composant s'auto-initialise via data-toggle.
 */

// Import des styles globaux
import '@styles/main.scss';

// Import des composants
// Atoms
import '@atoms/button/button.scss';
import ButtonRipple, {
  initButtonRipples
} from '@atoms/button/button.js';

// Organisms
import '@organisms/accordion/accordion.scss';
import Accordion, {
  initAccordions
} from '@organisms/accordion/accordion.js';

import '@organisms/tooltip/tooltip.scss';
import Tooltip, {
  initTooltips
} from '@organisms/tooltip/tooltip.js';

// Log pour confirmer le chargement
console.log('Design System initialized');

// Export des classes pour usage programmatique
export { ButtonRipple as DSButtonRipple, initButtonRipples };
export { Accordion as DSAccordion, initAccordions };
export { Tooltip as DSTooltip, initTooltips };
