import { defineConfig } from 'vite';
import { resolve } from 'path';

export default defineConfig({
  resolve: {
    alias: {
      '@': resolve(__dirname, 'src'),
      '@components': resolve(__dirname, 'src/components'),
      '@atoms': resolve(__dirname, 'src/components/atoms'),
      '@molecules': resolve(__dirname, 'src/components/molecules'),
      '@organisms': resolve(__dirname, 'src/components/organisms'),
      '@templates': resolve(__dirname, 'src/components/templates'),
      '@pages': resolve(__dirname, 'src/components/pages'),
      '@assets': resolve(__dirname, 'src/assets'),
      '@styles': resolve(__dirname, 'src/assets/styles'),
      '@images': resolve(__dirname, 'src/assets/images'),
      '@fonts': resolve(__dirname, 'src/assets/fonts'),
      '@js': resolve(__dirname, 'src/assets/js'),
    }
  },
  
  css: {
    preprocessorOptions: {
      scss: {
        api: 'modern-compiler',
        additionalData: `@use "sass:math"; @use "@styles/tokens/_variables.css" as *;`,
        silenceDeprecations: ['legacy-js-api']
      }
    },
    transformer: 'lightningcss',
    lightningcss: {
      targets: { chrome: 95, firefox: 91, safari: 14 }
    }
  },

  build: {
    outDir: resolve(__dirname, 'dist/lib'),
    emptyOutDir: true,
    minify: 'terser',
    terserOptions: {
      compress: { drop_console: true, drop_debugger: true },
      format: { comments: false }
    },
    lib: {
      entry: resolve(__dirname, 'src/index.js'),
      name: 'DesignSystemCardif',
      formats: ['es', 'umd'],
      fileName: (format) => `design-system-cardif.${format}.js`
    },
    rollupOptions: {
      external: [],
      output: {
        assetFileNames: (assetInfo) =>
          assetInfo.name === 'main.css' ? 'design-system-cardif.css' : assetInfo.name
      }
    }
  }
});