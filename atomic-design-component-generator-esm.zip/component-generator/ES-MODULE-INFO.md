# ES Module Version - Component Generator

## 🎉 What's New

This version uses **ES Modules** (ESM) instead of CommonJS:

### Changes:
- ✅ Uses `import` instead of `require`
- ✅ Uses `export` instead of `module.exports`
- ✅ Added `"type": "module"` in package.json
- ✅ Generated component JS files use `export default`

## 📦 Requirements

- **Node.js 14.0.0 or higher** (with ES Module support)
- **Modern browser** (for generated components)

## 🚀 Usage

### Run the Generator

```bash
node generate-component.js
```

### Import Generated Components (ES Module)

```javascript
// In your application (ES Module)
import ProductCard from './components/molecules/product-card/product-card.js';

const element = document.querySelector('.ds-product-card');
const card = new ProductCard(element);

// Or use auto-initialization with data-toggle
// <div class="ds-product-card" data-toggle="ds-product-card">
```

### Import in HTML

```html
<!-- Use as ES Module -->
<script type="module">
  import ProductCard from './product-card.js';
  
  const card = new ProductCard(document.querySelector('.ds-product-card'));
</script>

<!-- Or use the auto-initialization (included in the generated file) -->
<script type="module" src="./product-card.js"></script>
```

## 🔧 Technical Details

### Generator Script (generate-component.js)

```javascript
// ✅ ES Module imports
import fs from 'fs';
import path from 'path';
import readline from 'readline';
import { fileURLToPath } from 'url';

// ✅ ES Module equivalent of __dirname
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// ✅ ES Module export
export async function main() {
  // ...
}

// ✅ Run if main module
if (import.meta.url === `file://${process.argv[1]}`) {
  main();
}
```

### Generated Component Files

```javascript
// ✅ Generated JS files now export as ES Module
(function() {
  'use strict';
  
  class ProductCard {
    // ... component logic
  }
  
  // Global export (for browser)
  window.DSProductCard = ProductCard;
  
  // ✅ ES Module export
  export default ProductCard;
})();
```

## 📋 Package.json

```json
{
  "name": "atomic-design-component-generator",
  "version": "1.0.0",
  "type": "module",  // ✅ Enables ES Modules
  "main": "generate-component.js",
  "scripts": {
    "generate": "node generate-component.js"
  }
}
```

## 🔄 Migration from CommonJS

If you were using the CommonJS version, here are the changes:

### Before (CommonJS):
```javascript
const fs = require('fs');
const Component = require('./component.js');
module.exports = Component;
```

### After (ES Module):
```javascript
import fs from 'fs';
import Component from './component.js';
export default Component;
```

## ✨ Benefits of ES Modules

1. **Modern Standard**: Official JavaScript module system
2. **Tree Shaking**: Better bundle optimization
3. **Static Analysis**: Better IDE support
4. **Browser Native**: Works directly in modern browsers
5. **Future-Proof**: Aligned with JavaScript evolution

## 🌐 Browser Compatibility

Generated components work in:
- ✅ Chrome 61+
- ✅ Firefox 60+
- ✅ Safari 11+
- ✅ Edge 16+

## 🧪 Testing with ES Modules

Your test files should also use ES modules:

```javascript
// ✅ product-card.test.js
import { describe, it, expect } from 'vitest';
import ProductCard from './product-card.js';

describe('ProductCard', () => {
  it('should initialize', () => {
    // ... tests
  });
});
```

## 📦 Build Tools Compatibility

Works with:
- ✅ **Vite** (native ES module support)
- ✅ **Webpack 5** (supports ES modules)
- ✅ **Rollup** (designed for ES modules)
- ✅ **esbuild** (fast ES module bundler)

## ⚠️ Important Notes

### 1. File Extensions
Always include `.js` extension in imports:

```javascript
// ✅ Correct
import ProductCard from './product-card.js';

// ❌ Incorrect (works in CommonJS, not in ESM)
import ProductCard from './product-card';
```

### 2. __dirname and __filename
Use the ESM equivalent:

```javascript
import { fileURLToPath } from 'url';
import path from 'path';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
```

### 3. Top-Level Await
ES Modules support top-level await:

```javascript
// ✅ Works in ES modules
const data = await fetch('/api/data');
```

## 🔧 Troubleshooting

### Error: "Cannot use import statement outside a module"

**Solution**: Make sure `package.json` has `"type": "module"`

### Error: "Cannot find module"

**Solution**: Include `.js` extension in your import paths

### Error: "__dirname is not defined"

**Solution**: Use the ESM equivalent:
```javascript
import { fileURLToPath } from 'url';
const __dirname = path.dirname(fileURLToPath(import.meta.url));
```

## 📚 Resources

- [Node.js ES Modules](https://nodejs.org/api/esm.html)
- [MDN: JavaScript Modules](https://developer.mozilla.org/en-US/docs/Web/JavaScript/Guide/Modules)
- [ES Modules in Browsers](https://developer.mozilla.org/en-US/docs/Web/JavaScript/Guide/Modules)

---

**The generator is now fully ES Module compatible! 🎉**

All generated code follows modern JavaScript standards and works seamlessly with contemporary build tools and browsers.
