# Example Output: Creating a "Product Card" Molecule

This document shows what the generator creates when you generate a "ProductCard" molecule component.

## Command Execution

```
$ node generate-component.js

╔═══════════════════════════════════════════════════╗
║                                                   ║
║     Atomic Design Component Generator            ║
║                                                   ║
╚═══════════════════════════════════════════════════╝

Select component category:

  1. ATOMS
     Basic building blocks (Button, Input, Label, Icon, Badge)

  2. MOLECULES
     Groups of atoms (Form Field, Search Bar, Card Header)

  3. ORGANISMS
     Complex components (Accordion, Modal, Navigation, Card)

  4. TEMPLATES
     Page structures without content (Layout, Dashboard Template)

  5. PAGES
     Complete pages with real content (Home, About, Contact)

Enter category number (1-5): 2
✓ Selected: molecules

Enter component name (e.g., "MyComponent" or "my-component"): ProductCard
✓ Component name: product-card
  Pascal case: ProductCard
  Camel case: productCard

Create component in src/components/molecules/product-card/? (y/n): y

Creating component...

✓ Created directory: /project/src/components/molecules/product-card
✓ Created: product-card.html
✓ Created: product-card.scss
✓ Created: product-card.js
✓ Created: product-card.stories.js
✓ Created: product-card.test.js
✓ Created: README.md
✓ Created: CHANGELOG.md

═══════════════════════════════════════════════════
✓ Component created successfully!
═══════════════════════════════════════════════════

Component location:
  /project/src/components/molecules/product-card

Next steps:
  1. Review and customize the generated files
  2. Import styles in your main SCSS: @import 'components/molecules/product-card/product-card';
  3. Run Storybook to see your component: npm run storybook
  4. Run tests: npm run test product-card.test.js
  5. Update the component based on your requirements
```

## Generated Structure

```
src/components/molecules/product-card/
├── product-card.html          # Complete HTML examples with partials
├── product-card.scss          # BEM styles with design tokens
├── product-card.js            # Auto-initialization logic
├── product-card.stories.js    # Storybook documentation
├── product-card.test.js       # Comprehensive unit tests
├── README.md                  # Component documentation
└── CHANGELOG.md               # Version history
```

## File Contents Preview

### product-card.html (excerpt)

```html
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>ProductCard Component</title>
  
  <!-- Partials -->
  {{> header}}
  
  <!-- Component Styles -->
  <link rel="stylesheet" href="product-card.scss">
</head>
<body>
  {{> nav}}
  
  <main class="container">
    <h1>ProductCard Component Examples</h1>
    
    <!-- Basic ProductCard -->
    <section class="example-section">
      <h2>Default ProductCard</h2>
      <div class="ds-product-card" data-toggle="ds-product-card">
        <div class="ds-product-card__header">
          <h3 class="ds-product-card__title">ProductCard Title</h3>
        </div>
        <div class="ds-product-card__body">
          <p>Content goes here...</p>
        </div>
      </div>
    </section>
    <!-- More examples... -->
  </main>

  {{> footer}}
  
  <!-- Component Script -->
  <script src="product-card.js"></script>
</body>
</html>
```

### product-card.scss (excerpt)

```scss
/**
 * product-card Component - Molecules
 * 
 * Functional group of atoms. Combines multiple basic elements 
 * into a cohesive unit with coordinated behavior.
 */

.ds-product-card {
  // Layout
  display: flex;
  flex-direction: column;
  
  // Spacing
  padding: $spacing-lg;
  
  // Visual
  background-color: $color-white;
  border: 1px solid $color-border;
  border-radius: $border-radius-md;
  
  // Effects
  box-shadow: $shadow-sm;
  transition: all $transition-base ease-in-out;

  // Hover state
  &:hover {
    box-shadow: $shadow-md;
  }

  /* Element: Header */
  &__header {
    padding-bottom: $spacing-md;
    border-bottom: 1px solid $color-border;
  }

  /* Element: Title */
  &__title {
    margin: 0;
    font-size: $font-size-lg;
    font-weight: $font-weight-semibold;
    color: $color-text;
  }

  /* Element: Body */
  &__body {
    flex: 1;
    padding: $spacing-md 0;
  }

  /* Modifier: Variant */
  &--variant {
    background-color: $color-background-light;
    border-color: $color-primary;
  }

  /* State: Active */
  &.is-active {
    border-color: $color-primary;
    box-shadow: 0 0 0 3px rgba($color-primary, 0.1);
  }

  /* Reduced Motion */
  @media (prefers-reduced-motion: reduce) {
    transition: none;
    animation: none;
  }
}
```

### product-card.js (excerpt)

```javascript
/**
 * ProductCard Component - Molecules
 * Functional group of atoms. Combines multiple basic elements 
 * into a cohesive unit with coordinated behavior.
 * 
 * Features:
 * - Auto-initialization via data-toggle
 * - Custom events for state changes
 * - Public API for programmatic control
 * - MutationObserver for dynamic content
 * - Keyboard navigation support
 * - ARIA accessibility
 */

(function() {
  'use strict';

  /**
   * ProductCard Class
   */
  class ProductCard {
    /**
     * Constructor
     * @param {HTMLElement} element - The component element
     * @param {Object} options - Configuration options
     */
    constructor(element, options = {}) {
      if (!element) {
        throw new Error('ProductCard element is required');
      }

      this.element = element;
      this.options = {
        animated: element.dataset.animated !== 'false',
        closeOnOutsideClick: element.dataset.closeOnOutsideClick === 'true',
        keyboard: element.dataset.keyboard !== 'false',
        ...options
      };

      // State
      this.state = {
        isOpen: false,
        isActive: false,
        isDisabled: false
      };

      // Store instance reference
      this.element._productCardInstance = this;

      // Initialize
      this.init();
    }

    /**
     * Initialize the component
     */
    init() {
      this.setupElements();
      this.setupEventListeners();
      this.setupAccessibility();
      
      this.dispatchEvent('initialized');
    }

    // ... more methods
  }

  /**
   * Auto-initialization
   */
  function initProductCardComponents() {
    document.querySelectorAll('[data-toggle="ds-product-card"]').forEach(element => {
      if (!element._productCardInstance) {
        new ProductCard(element);
      }
    });
  }

  // Initialize on DOM ready
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initProductCardComponents);
  } else {
    initProductCardComponents();
  }

  // Export
  window.DSProductCard = ProductCard;
})();
```

### product-card.stories.js (excerpt)

```javascript
/**
 * ProductCard Component Stories
 */

import { html } from 'lit-html';
import './product-card.scss';
import './product-card.js';

export default {
  title: 'Molecules/ProductCard',
  tags: ['autodocs'],
  argTypes: {
    title: {
      control: 'text',
      description: 'Title of the product-card',
      defaultValue: 'ProductCard Title'
    },
    // ... more argTypes
  }
};

const Template = ({ title, content, variant, disabled }) => {
  const variantClass = variant !== 'default' ? `ds-product-card--${variant}` : '';
  const disabledClass = disabled ? 'is-disabled' : '';
  
  return html`
    <div class="ds-product-card ${variantClass} ${disabledClass}" 
         data-toggle="ds-product-card">
      <div class="ds-product-card__header">
        <h3 class="ds-product-card__title">${title}</h3>
      </div>
      <div class="ds-product-card__body">
        <p>${content}</p>
      </div>
    </div>
  `;
};

export const Default = Template.bind({});
Default.args = {
  title: 'Default ProductCard',
  content: 'This is the default product-card component.',
  variant: 'default',
  disabled: false
};

// ... more stories
```

### product-card.test.js (excerpt)

```javascript
/**
 * ProductCard Component Tests
 */

import { describe, it, expect, beforeEach, afterEach } from 'vitest';
import './product-card.js';

describe('ProductCard Component', () => {
  let container;

  beforeEach(() => {
    container = document.createElement('div');
    document.body.appendChild(container);
  });

  afterEach(() => {
    document.body.innerHTML = '';
  });

  describe('Initialization', () => {
    it('should auto-initialize with data-toggle attribute', () => {
      container.innerHTML = `
        <div class="ds-product-card" data-toggle="ds-product-card">
          <div class="ds-product-card__content">Test</div>
        </div>
      `;

      const element = container.querySelector('[data-toggle="ds-product-card"]');
      document.dispatchEvent(new Event('DOMContentLoaded'));

      expect(element._productCardInstance).toBeDefined();
      expect(element._productCardInstance).toBeInstanceOf(window.DSProductCard);
    });

    // ... more tests
  });

  describe('Public API', () => {
    // ... API tests
  });

  describe('Accessibility', () => {
    // ... accessibility tests
  });
});
```

## Usage After Generation

### 1. Import in Main SCSS

```scss
// src/styles/main.scss
@import 'components/molecules/product-card/product-card';
```

### 2. Use in HTML

```html
<!-- Auto-initialization -->
<div class="ds-product-card" data-toggle="ds-product-card">
  <div class="ds-product-card__header">
    <h3 class="ds-product-card__title">Product Title</h3>
  </div>
  <div class="ds-product-card__body">
    <p>Product description...</p>
  </div>
</div>
```

### 3. Manual JavaScript Usage

```javascript
import ProductCard from './components/molecules/product-card/product-card.js';

const element = document.querySelector('.ds-product-card');
const card = new ProductCard(element, {
  animated: true,
  keyboard: true
});

// Use public API
card.open();
card.close();
card.toggle();

// Listen to events
element.addEventListener('ds-product-card:opened', (e) => {
  console.log('Card opened!', e.detail);
});
```

### 4. View in Storybook

```bash
npm run storybook
# Navigate to: Molecules > ProductCard
```

### 5. Run Tests

```bash
npm run test product-card.test.js
```

## Customization Tips

After generation, you can customize:

1. **HTML Structure**: Add more elements specific to your product card
2. **SCSS Styles**: Adjust colors, spacing, add animations
3. **JavaScript Logic**: Add cart functionality, wishlist, quick view
4. **Stories**: Add more use cases (featured card, sale card, etc.)
5. **Tests**: Add product-specific test cases

## Benefits

✅ **Consistency**: All components follow the same structure  
✅ **Speed**: Generate in seconds instead of hours  
✅ **Best Practices**: Built-in accessibility, BEM, design tokens  
✅ **Documentation**: README and Storybook stories included  
✅ **Testing**: Unit tests ready to run  
✅ **Maintainability**: Clear structure and naming conventions  
✅ **Scalability**: Easy to extend and modify  

---

This example demonstrates the complete workflow from generation to usage!
