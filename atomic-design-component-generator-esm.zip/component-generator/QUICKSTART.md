# Component Generator - Quick Start Guide

> Automated component creation for Atomic Design System

## Overview

This tool automates the creation of components following Atomic Design principles. It generates a complete component structure with 7 files, each initialized with production-ready templates.

## Prerequisites

- **Node.js** 14.0.0 or higher
- **Project structure** following Atomic Design:
  ```
  src/
  ├── assets/
  ├── components/
  │   ├── atoms/
  │   ├── molecules/
  │   ├── organisms/
  │   ├── templates/
  │   └── pages/
  └── partials/
      ├── header.hbs
      ├── footer.hbs
      └── nav.hbs
  ```

## Installation

### Option 1: Direct Execution (Recommended)

Place the script in your project root and run directly:

```bash
# Make the script executable (Unix/Mac)
chmod +x generate-component.js

# Run the generator
node generate-component.js
```

### Option 2: NPM Script

Add to your project's `package.json`:

```json
{
  "scripts": {
    "generate:component": "node generate-component.js"
  }
}
```

Then run:

```bash
npm run generate:component
```

### Option 3: Global Installation

Install globally for use across multiple projects:

```bash
# Copy files to a global location
npm install -g .

# Run from anywhere
generate-component
```

## Usage

### Step-by-Step Process

#### 1. Run the Generator

```bash
node generate-component.js
```

#### 2. Select Component Category

You'll see a menu with 5 Atomic Design categories:

```
Select component category:

  1. ATOMS
     Basic building blocks (Button, Input, Label, Icon, Badge)

  2. MOLECULES
     Groups of atoms (Form Field, Search Bar, Card Header)

  3. ORGANISMS
     Complex components (Accordion, Modal, Navigation, Card)

  4. TEMPLATES
     Page structures without content (Layout, Dashboard Template)

  5. PAGES
     Complete pages with real content (Home, About, Contact)

Enter category number (1-5):
```

**Enter a number between 1-5** based on your component's complexity level.

#### 3. Enter Component Name

```
Enter component name (e.g., "MyComponent" or "my-component"):
```

The script accepts multiple formats and converts automatically:
- **PascalCase**: `MyComponent` → `my-component`
- **camelCase**: `myComponent` → `my-component`
- **kebab-case**: `my-component` → `my-component`
- **With spaces**: `My Component` → `my-component`

#### 4. Confirm Creation

```
Create component in src/components/molecules/my-component/? (y/n):
```

Type `y` to confirm or `n` to cancel.

#### 5. Component Generated

The generator creates:

```
src/components/molecules/my-component/
├── my-component.html          ✓ HTML examples with partials
├── my-component.scss          ✓ BEM styles with design tokens
├── my-component.js            ✓ Auto-initialization logic
├── my-component.stories.js    ✓ Storybook documentation
├── my-component.test.js       ✓ Unit tests
├── README.md                  ✓ Component documentation
└── CHANGELOG.md               ✓ Version history
```

## Generated Files Explained

### 1. HTML File (`my-component.html`)

Complete HTML page with:
- ✅ Partial references (header, nav, footer)
- ✅ Multiple usage examples
- ✅ Different component states
- ✅ Variant demonstrations
- ✅ Proper semantic structure

**Includes:**
```html
{{> header}}
{{> nav}}
<!-- Component examples -->
{{> footer}}
<script src="my-component.js"></script>
```

### 2. SCSS File (`my-component.scss`)

Production-ready styles with:
- ✅ BEM methodology
- ✅ Design tokens (no hardcoded values)
- ✅ Responsive breakpoints
- ✅ Accessibility (reduced motion)
- ✅ Multiple states and modifiers

**Example structure:**
```scss
.ds-my-component {}                // Block
.ds-my-component__header {}        // Element
.ds-my-component--variant {}       // Modifier
.ds-my-component.is-active {}      // State
```

### 3. JavaScript File (`my-component.js`)

Full-featured component class with:
- ✅ Auto-initialization via `data-toggle`
- ✅ Public API (open, close, toggle, etc.)
- ✅ Custom events
- ✅ MutationObserver for dynamic content
- ✅ Keyboard navigation
- ✅ ARIA accessibility
- ✅ State management

**Note**: Atoms and Templates get minimal/no JavaScript (CSS-only).

### 4. Storybook Stories (`my-component.stories.js`)

Interactive documentation with:
- ✅ Multiple stories (Default, Variant, Disabled, Multiple)
- ✅ Interactive controls (argTypes)
- ✅ Auto-generated docs
- ✅ Event logging examples

### 5. Unit Tests (`my-component.test.js`)

Comprehensive test suite covering:
- ✅ Initialization tests
- ✅ Public API tests
- ✅ Event dispatching tests
- ✅ Accessibility tests
- ✅ Dynamic content tests

### 6. README.md

Complete documentation including:
- ✅ Usage examples
- ✅ API reference
- ✅ Accessibility guidelines
- ✅ Browser support
- ✅ Contribution guide

### 7. CHANGELOG.md

Version tracking template following:
- ✅ Keep a Changelog format
- ✅ Semantic Versioning
- ✅ Change categories (Added, Changed, Fixed, etc.)

## After Generation

### 1. Import Component Styles

Add to your main SCSS file:

```scss
// Main SCSS file (e.g., src/styles/main.scss)
@import 'components/molecules/my-component/my-component';
```

### 2. Customize the Component

Review and modify generated files:
- Update HTML structure for your needs
- Adjust SCSS styling
- Enhance JavaScript functionality
- Add more Storybook stories
- Expand test coverage

### 3. View in Storybook

```bash
npm run storybook
```

Navigate to: **Molecules > MyComponent**

### 4. Run Tests

```bash
# Run all tests
npm run test

# Run specific component tests
npm run test my-component.test.js

# Watch mode
npm run test:watch
```

### 5. Use in Your Application

#### HTML with auto-initialization:
```html
<div class="ds-my-component" data-toggle="ds-my-component">
  <div class="ds-my-component__content">
    Content here...
  </div>
</div>
```

#### Manual JavaScript initialization:
```javascript
import MyComponent from './components/molecules/my-component/my-component.js';

const element = document.querySelector('.ds-my-component');
const instance = new MyComponent(element, {
  animated: true,
  keyboard: true
});

// Use public API
instance.open();
instance.close();
instance.toggle();
```

## Examples

### Example 1: Creating a Button Atom

```
Select category: 1 (ATOMS)
Component name: PrimaryButton
✓ Generated: src/components/atoms/primary-button/
```

**Result**: Simple button with CSS-only styling, no JavaScript needed.

### Example 2: Creating a Card Molecule

```
Select category: 2 (MOLECULES)
Component name: ProductCard
✓ Generated: src/components/molecules/product-card/
```

**Result**: Card component combining atoms (image, title, button) with coordinated behavior.

### Example 3: Creating a Modal Organism

```
Select category: 3 (ORGANISMS)
Component name: ConfirmationModal
✓ Generated: src/components/organisms/confirmation-modal/
```

**Result**: Full-featured modal with open/close logic, keyboard handling, focus trapping, and ARIA support.

### Example 4: Creating a Dashboard Template

```
Select category: 4 (TEMPLATES)
Component name: AdminDashboard
✓ Generated: src/components/templates/admin-dashboard/
```

**Result**: Layout structure with sidebar, header, content area, and footer.

### Example 5: Creating a Home Page

```
Select category: 5 (PAGES)
Component name: HomePage
✓ Generated: src/components/pages/home-page/
```

**Result**: Complete page with hero section, content areas, and real content placeholders.

## Component Adaptation by Category

The generator creates **category-specific templates**:

### Atoms
- **Complexity**: Simple
- **JavaScript**: Minimal/None (CSS-only)
- **Structure**: Single element with variants
- **Examples**: Buttons, inputs, labels, icons

### Molecules
- **Complexity**: Moderate
- **JavaScript**: Basic interactions
- **Structure**: Header + Body composition
- **Examples**: Form fields, search bars, card headers

### Organisms
- **Complexity**: Complex
- **JavaScript**: Full-featured with state management
- **Structure**: Header + Body + Footer with rich interactions
- **Examples**: Modals, accordions, navigation menus

### Templates
- **Complexity**: Structural
- **JavaScript**: None (layout only)
- **Structure**: Grid-based page structure
- **Examples**: Page layouts, dashboard templates

### Pages
- **Complexity**: Complete
- **JavaScript**: None (content only)
- **Structure**: Hero + Content sections
- **Examples**: Home page, about page, contact page

## Design Patterns Used

### BEM Naming Convention

```scss
.ds-component {}               // Block
.ds-component__element {}      // Element
.ds-component--modifier {}     // Modifier
.ds-component.is-state {}      // State
```

### Auto-Initialization Pattern

```javascript
// Components auto-initialize on page load
document.querySelectorAll('[data-toggle="ds-component"]').forEach(element => {
  if (!element._componentInstance) {
    new Component(element);
  }
});
```

### Custom Events Pattern

```javascript
// Dispatch custom events for state changes
dispatchEvent('opened', { component: this });
dispatchEvent('closed', { component: this });
dispatchEvent('changed', { value: newValue });
```

### MutationObserver Pattern

```javascript
// Automatically initialize dynamically added components
const observer = new MutationObserver(mutations => {
  // Initialize new components
});
observer.observe(document.body, { childList: true, subtree: true });
```

## Best Practices

### 1. Use Design Tokens

✅ **Good:**
```scss
padding: $spacing-lg;
color: $color-primary;
border-radius: $border-radius-md;
```

❌ **Bad:**
```scss
padding: 1.5rem;
color: #007bff;
border-radius: 0.375rem;
```

### 2. Follow BEM Methodology

✅ **Good:**
```html
<div class="ds-card">
  <div class="ds-card__header">
    <h3 class="ds-card__title">Title</h3>
  </div>
</div>
```

❌ **Bad:**
```html
<div class="card">
  <div class="header">
    <h3 class="title">Title</h3>
  </div>
</div>
```

### 3. Ensure Accessibility

✅ **Good:**
```javascript
element.setAttribute('aria-expanded', 'true');
element.setAttribute('role', 'dialog');
element.setAttribute('aria-labelledby', 'title-id');
```

❌ **Bad:**
```javascript
// No ARIA attributes, poor accessibility
element.classList.add('open');
```

### 4. Test Thoroughly

✅ **Good:**
```javascript
describe('Component', () => {
  it('should initialize correctly', () => { /* test */ });
  it('should handle interactions', () => { /* test */ });
  it('should be accessible', () => { /* test */ });
});
```

❌ **Bad:**
```javascript
// No tests or minimal coverage
```

## Troubleshooting

### Component Directory Already Exists

**Error:**
```
✗ Component directory already exists: src/components/molecules/my-component
```

**Solution:**
- Choose a different component name, or
- Delete the existing component directory, or
- Rename the existing component

### Invalid Category Selection

**Error:**
```
✗ Invalid category selection
```

**Solution:**
- Enter a number between 1-5
- Check that you're not entering text or symbols

### Component Name Empty

**Error:**
```
✗ Component name is required
```

**Solution:**
- Provide a valid component name
- Don't leave the input blank

### Permission Denied

**Error:**
```
Error: EACCES: permission denied
```

**Solution:**
```bash
# Make script executable (Unix/Mac)
chmod +x generate-component.js

# Or run with explicit node command
node generate-component.js
```

## Advanced Usage

### Batch Component Generation

Create a script to generate multiple components:

```javascript
// batch-generate.js
const { spawn } = require('child_process');

const components = [
  { category: '1', name: 'IconButton' },
  { category: '2', name: 'SearchBar' },
  { category: '3', name: 'NavigationMenu' }
];

components.forEach(comp => {
  const process = spawn('node', ['generate-component.js']);
  
  process.stdin.write(`${comp.category}\n`);
  process.stdin.write(`${comp.name}\n`);
  process.stdin.write('y\n');
  process.stdin.end();
});
```

### Custom Templates

Modify template functions in `generate-component.js`:
- `generateHTML()`
- `generateSCSS()`
- `generateJS()`
- `generateStories()`
- `generateTest()`

### Integration with CI/CD

Add to your CI pipeline:

```yaml
# .github/workflows/component-validation.yml
name: Validate Components

on: [push]

jobs:
  test:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v2
      - name: Run component tests
        run: npm run test
      - name: Build Storybook
        run: npm run build-storybook
```

## Support & Resources

### Documentation
- **Atomic Design**: https://atomicdesign.bradfrost.com/
- **BEM Methodology**: http://getbem.com/
- **ARIA Authoring Practices**: https://www.w3.org/WAI/ARIA/apg/

### Testing
- **Vitest**: https://vitest.dev/
- **Testing Library**: https://testing-library.com/

### Storybook
- **Storybook Docs**: https://storybook.js.org/docs

## License

Internal Design System Tool - © 2026

---

**Happy Component Creating! 🎨**

For questions or issues, contact the Design System team.
