# Atomic Design Component Generator

> Automated component creation tool for Design Systems using Atomic Design methodology

**✨ Now with ES Module support!** This version uses modern `import`/`export` syntax instead of `require`/`module.exports`.

## 🎯 Overview

This Node.js script automates the creation of components following **Atomic Design principles** with **Vite 7.3.1**, **Storybook 8.6.15**, and **Handlebars partials**. It generates a complete component structure with 7 production-ready files.

## ✨ Features

- 🏗️ **Atomic Design Architecture** - Supports all 5 levels (Atoms, Molecules, Organisms, Templates, Pages)
- 📦 **Complete Component Structure** - 7 files per component (HTML, SCSS, JS, Stories, Tests, README, CHANGELOG)
- 🎨 **BEM Methodology** - Consistent naming convention
- 🎭 **Design Tokens** - No hardcoded values, uses SASS variables
- ♿ **Accessibility First** - ARIA attributes, keyboard navigation, screen reader support
- 🧪 **Test Ready** - Vitest unit tests included
- 📚 **Storybook Integration** - Interactive documentation and examples
- 🔄 **Auto-Initialization** - Components initialize automatically via `data-toggle`
- 👀 **MutationObserver** - Handles dynamically added components
- 📱 **Responsive** - Mobile-first approach with breakpoints
- 🎬 **Reduced Motion** - Respects user preferences

## 📋 Prerequisites

- Node.js 14.0.0 or higher **(with ES Module support)**
- Project structure following Atomic Design:

```
src/
├── assets/
├── components/
│   ├── atoms/
│   ├── molecules/
│   ├── organisms/
│   ├── templates/
│   └── pages/
└── partials/
    ├── header.hbs
    ├── footer.hbs
    └── nav.hbs
```

## 🚀 Installation

### Quick Start

```bash
# Clone or copy the generator files to your project root
# Make the script executable (Unix/Mac)
chmod +x generate-component.js

# Run the generator
node generate-component.js
```

### NPM Integration

Add to your `package.json`:

```json
{
  "scripts": {
    "generate:component": "node generate-component.js"
  }
}
```

Then run:

```bash
npm run generate:component
```

## 📖 Usage

### Interactive Mode

1. **Run the generator:**
   ```bash
   node generate-component.js
   ```

2. **Select category (1-5):**
   - 1: Atoms (Button, Input, Icon)
   - 2: Molecules (Form Field, Search Bar)
   - 3: Organisms (Modal, Navigation, Accordion)
   - 4: Templates (Page Layout, Dashboard)
   - 5: Pages (Home, About, Contact)

3. **Enter component name:**
   - Accepts any format: `MyComponent`, `my-component`, `My Component`
   - Automatically converts to kebab-case

4. **Confirm creation:**
   - Review the output path
   - Type `y` to confirm

### Example Session

```
╔═══════════════════════════════════════════════════╗
║                                                   ║
║     Atomic Design Component Generator            ║
║                                                   ║
╚═══════════════════════════════════════════════════╝

Select component category:

  1. ATOMS
     Basic building blocks (Button, Input, Label, Icon, Badge)

  2. MOLECULES
     Groups of atoms (Form Field, Search Bar, Card Header)

Enter category number (1-5): 2
✓ Selected: molecules

Enter component name: ProductCard
✓ Component name: product-card
  Pascal case: ProductCard
  Camel case: productCard

Create component in src/components/molecules/product-card/? (y/n): y

Creating component...

✓ Created directory: /project/src/components/molecules/product-card
✓ Created: product-card.html
✓ Created: product-card.scss
✓ Created: product-card.js
✓ Created: product-card.stories.js
✓ Created: product-card.test.js
✓ Created: README.md
✓ Created: CHANGELOG.md

═══════════════════════════════════════════════════
✓ Component created successfully!
═══════════════════════════════════════════════════
```

## 📦 Generated Files

### 1. HTML File (`.html`)

Complete HTML page with:
- Handlebars partial references (header, nav, footer)
- Multiple usage examples
- Different component states (active, disabled, loading)
- Variant demonstrations
- Proper semantic structure

### 2. SCSS File (`.scss`)

Production-ready styles with:
- BEM naming convention
- Design tokens (no hardcoded values)
- Responsive breakpoints
- State management (active, disabled, loading)
- Reduced motion support
- Category-specific structure

**Example:**
```scss
.ds-product-card {}                     // Block
.ds-product-card__header {}             // Element
.ds-product-card--featured {}           // Modifier
.ds-product-card.is-active {}           // State
```

### 3. JavaScript File (`.js`)

Full-featured component class (for non-Atoms):
- Auto-initialization via `data-toggle`
- Public API (open, close, toggle, enable, disable, destroy)
- Custom events (`initialized`, `opened`, `closed`, etc.)
- MutationObserver for dynamic content
- Keyboard navigation
- ARIA accessibility
- State management

**Example:**
```javascript
const element = document.querySelector('.ds-product-card');
const card = new ProductCard(element, {
  animated: true,
  clickable: true
});

// Public API
card.open();
card.close();
card.toggle();

// Events
element.addEventListener('ds-product-card:opened', (e) => {
  console.log('Card opened', e.detail);
});
```

### 4. Storybook Stories (`.stories.js`)

Interactive documentation with:
- Multiple stories (Default, Variant, Disabled, Multiple)
- Interactive controls (argTypes)
- Auto-generated documentation
- Event logging examples
- Multiple instance examples

### 5. Unit Tests (`.test.js`)

Comprehensive test suite:
- ✅ Initialization tests
- ✅ Public API tests
- ✅ Event dispatching tests
- ✅ Accessibility tests (ARIA, keyboard)
- ✅ Dynamic content tests (MutationObserver)
- ✅ State management tests

### 6. README.md

Complete component documentation:
- Description and category
- Usage examples (HTML, JavaScript, SCSS)
- Public API reference
- Event documentation
- Accessibility guidelines
- Browser support
- Testing instructions

### 7. CHANGELOG.md

Version tracking:
- Follows Keep a Changelog format
- Semantic Versioning
- Pre-filled with initial version

## 🎨 Design Patterns

### BEM Naming Convention

```scss
// Block
.ds-component {}

// Element
.ds-component__element {}

// Modifier
.ds-component--modifier {}

// State
.ds-component.is-state {}
```

### Auto-Initialization Pattern

```html
<!-- Component auto-initializes on page load -->
<div class="ds-component" data-toggle="ds-component">
  <!-- Component content -->
</div>
```

```javascript
// Manual initialization
const element = document.querySelector('.ds-component');
const instance = new Component(element, options);
```

### Custom Events Pattern

```javascript
// Component dispatches custom events
element.addEventListener('ds-component:opened', (e) => {
  console.log('Component opened', e.detail);
});

element.addEventListener('ds-component:closed', (e) => {
  console.log('Component closed', e.detail);
});
```

## 🏗️ Atomic Design Levels

### Atoms (Level 1)
**Characteristics:**
- Simple, indivisible elements
- Pure UI, minimal logic
- CSS-only (no JavaScript)
- Examples: Button, Input, Label, Icon, Badge

**Generated Structure:**
```html
<div class="ds-atom">
  <span class="ds-atom__content">Content</span>
</div>
```

### Molecules (Level 2)
**Characteristics:**
- Combination of atoms
- Simple coordinated behavior
- Basic JavaScript interactions
- Examples: Form Field, Search Bar, Card Header

**Generated Structure:**
```html
<div class="ds-molecule" data-toggle="ds-molecule">
  <div class="ds-molecule__header">
    <h3 class="ds-molecule__title">Title</h3>
  </div>
  <div class="ds-molecule__body">Content</div>
</div>
```

### Organisms (Level 3)
**Characteristics:**
- Complex, feature-rich components
- Advanced interactions and state management
- Full JavaScript functionality
- Examples: Modal, Accordion, Navigation, Card

**Generated Structure:**
```html
<div class="ds-organism" data-toggle="ds-organism">
  <div class="ds-organism__header">
    <h3 class="ds-organism__title">Title</h3>
    <button class="ds-organism__close">×</button>
  </div>
  <div class="ds-organism__body">Complex content</div>
  <div class="ds-organism__footer">
    <button class="ds-button">Action</button>
  </div>
</div>
```

### Templates (Level 4)
**Characteristics:**
- Page structure layouts
- Grid-based organization
- No specific content
- Examples: Page Layout, Dashboard Template

**Generated Structure:**
```html
<div class="ds-template">
  <div class="ds-template__sidebar">Sidebar</div>
  <div class="ds-template__main">
    <header class="ds-template__header">Header</header>
    <div class="ds-template__content">Content</div>
    <footer class="ds-template__footer">Footer</footer>
  </div>
</div>
```

### Pages (Level 5)
**Characteristics:**
- Complete pages with real content
- Specific data and use cases
- Minimal/no JavaScript
- Examples: Home Page, About Page, Contact Page

**Generated Structure:**
```html
<div class="ds-page">
  <header class="ds-page__hero">
    <h1>Page Title</h1>
    <p>Hero content</p>
  </header>
  <section class="ds-page__content">
    <article>Real content...</article>
  </section>
</div>
```

## ✅ Best Practices

### 1. Use Design Tokens

✅ **Good:**
```scss
padding: $spacing-lg;
color: $color-primary;
border-radius: $border-radius-md;
box-shadow: $shadow-sm;
transition: all $transition-base;
```

❌ **Bad:**
```scss
padding: 1.5rem;
color: #007bff;
border-radius: 8px;
box-shadow: 0 1px 2px rgba(0, 0, 0, 0.05);
transition: all 0.3s ease;
```

### 2. Follow BEM Methodology

✅ **Good:**
```html
<div class="ds-card">
  <div class="ds-card__header">
    <h3 class="ds-card__title">Title</h3>
  </div>
  <div class="ds-card__body">Content</div>
</div>
```

❌ **Bad:**
```html
<div class="card">
  <div class="header">
    <h3 class="title">Title</h3>
  </div>
  <div class="body">Content</div>
</div>
```

### 3. Ensure Accessibility

✅ **Good:**
```javascript
element.setAttribute('role', 'dialog');
element.setAttribute('aria-expanded', 'true');
element.setAttribute('aria-labelledby', 'title-id');
element.setAttribute('tabindex', '0');

// Keyboard navigation
element.addEventListener('keydown', (e) => {
  if (e.key === 'Escape') this.close();
  if (e.key === 'Enter') this.open();
});
```

❌ **Bad:**
```javascript
// No ARIA, no keyboard support
element.classList.add('open');
```

### 4. Write Comprehensive Tests

✅ **Good:**
```javascript
describe('Component', () => {
  describe('Initialization', () => { /* tests */ });
  describe('Public API', () => { /* tests */ });
  describe('Events', () => { /* tests */ });
  describe('Accessibility', () => { /* tests */ });
  describe('Dynamic Content', () => { /* tests */ });
});
```

## 🔧 Customization

### Modify Templates

Edit the generator functions in `generate-component.js`:

```javascript
// Customize HTML structure
function generateHTML(componentName, category) {
  // Your custom HTML template logic
}

// Customize SCSS styles
function generateSCSS(componentName, category) {
  // Your custom SCSS template logic
}

// Customize JavaScript logic
function generateJS(componentName, category) {
  // Your custom JS template logic
}
```

### Add Custom Patterns

Extend the generator with your team's patterns:

```javascript
// Add custom design token categories
const CUSTOM_TOKENS = {
  spacing: ['xs', 'sm', 'md', 'lg', 'xl'],
  colors: ['primary', 'secondary', 'success', 'danger'],
  // ... more tokens
};

// Integrate into templates
```

## 🧪 Testing

### Run All Tests

```bash
npm run test
```

### Run Component-Specific Tests

```bash
npm run test product-card.test.js
```

### Watch Mode

```bash
npm run test:watch
```

### Coverage Report

```bash
npm run test:coverage
```

## 📚 Storybook

### Start Storybook

```bash
npm run storybook
```

### Build Storybook

```bash
npm run build-storybook
```

### View Component

Navigate to: **{Category} > {ComponentName}**

Example: **Molecules > ProductCard**

## 🐛 Troubleshooting

### Component Already Exists

**Error:** `✗ Component directory already exists`

**Solution:**
- Choose a different name
- Delete existing component
- Rename existing component

### Permission Denied

**Error:** `EACCES: permission denied`

**Solution:**
```bash
chmod +x generate-component.js
# or
sudo node generate-component.js
```

### Invalid Category

**Error:** `✗ Invalid category selection`

**Solution:**
- Enter a number between 1-5
- Don't use letters or symbols

## 📝 Workflow Integration

### Add to Git Hooks

```bash
# .husky/pre-commit
npm run test
npm run lint
```

### CI/CD Integration

```yaml
# .github/workflows/test.yml
name: Test Components
on: [push, pull_request]
jobs:
  test:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v2
      - run: npm install
      - run: npm run test
      - run: npm run build-storybook
```

## 📄 License

Internal Design System Tool

## 🤝 Contributing

1. Follow the component creation guidelines
2. Ensure all tests pass
3. Update documentation
4. Submit pull request

## 📞 Support

For questions or issues, contact the Design System team.

---

**Built with ❤️ for Design System efficiency**
