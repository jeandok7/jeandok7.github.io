DESIGN SYSTEM OFFLINE SERVER V3 (2 Ports)

Requirements:
- Node.js installed

Structure:

project
│
├─ dist
│   ├─ demo
│   └─ storybook
│
├─ server.js
├─ launch.bat
└─ launch.command

Usage:

Windows: Double click launch.bat
Mac: Double click launch.command
Universal fallback: node server.js

Servers:

Demo:      http://localhost:3003
Storybook: http://localhost:6006
Home page: http://localhost:3000  (links to both)

Browser opens automatically.