#!/bin/bash
DIR="$(cd "$(dirname "$0")" && pwd)"
echo "Starting Design System server..."
node "$DIR/server.js"
