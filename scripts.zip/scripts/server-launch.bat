
@echo off
echo Starting Design System server...
node server.js
pause
