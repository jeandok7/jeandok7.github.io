# Design System – Web Components

Ce repository contient un **design system Web Components** documenté avec **Storybook 8**, **MDX**, et **Vite**.

## Contenu
- Storybook Web Components (vanilla)
- Documentation MDX
- Changelog par composant
- Changelog global (agrégé)
- Quickstart développeur

## Scripts utiles
```bash
npm install
npm run storybook
npm run build
```
