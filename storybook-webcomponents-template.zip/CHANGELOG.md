# Changelog global

> Ce fichier est généré automatiquement à partir des changelogs des composants.

---

# Button

## [1.1.0]
### Added
- Variant danger

---

# Modal

## [1.0.0]
### Added
- Initial release
