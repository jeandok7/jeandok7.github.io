# Quickstart

## Installation
```bash
npm install
```

## Lancer Storybook
```bash
npm run storybook
```

## Ajouter un composant
1. Créer un dossier dans `src/components`
2. Ajouter :
   - composant JS
   - story
   - MDX
   - CHANGELOG.md
