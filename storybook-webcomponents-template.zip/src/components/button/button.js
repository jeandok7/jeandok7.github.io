class MyButton extends HTMLElement {
  connectedCallback() {
    this.innerHTML = `<button><slot></slot></button>`;
  }
}
customElements.define('my-button', MyButton);
