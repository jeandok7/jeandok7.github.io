## [1.1.0]
### Added
- Variant danger

## [1.0.0]
### Added
- Initial version
