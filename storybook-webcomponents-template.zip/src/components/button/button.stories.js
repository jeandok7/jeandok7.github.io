import './button.js';
import changelog from './CHANGELOG.md?raw';

export default {
  title: 'Components/Button',
  parameters: {
    changelog: {
      markdown: changelog,
    },
  },
};

export const Primary = {
  render: () => '<my-button>Button</my-button>',
};
