import { defineConfig } from 'vite';
import { resolve } from 'path';
import { readdirSync, statSync } from 'fs';
import viteCompression from 'vite-plugin-compression';
import viteImagemin from 'vite-plugin-imagemin';

// Scanner automatique des composants
function scanComponents(baseDir) {
  const entries = {};
  const categories = ['atoms', 'molecules', 'organisms', 'templates', 'pages'];
  
  categories.forEach(category => {
    const categoryPath = resolve(__dirname, `src/components/${category}`);
    try {
      const components = readdirSync(categoryPath);
      components.forEach(component => {
        const componentPath = resolve(categoryPath, component);
        if (statSync(componentPath).isDirectory()) {
          // Chercher les fichiers .js et .html
          const jsPath = resolve(componentPath, `${component}.js`);
          const htmlPath = resolve(componentPath, `${component}.html`);
          
          try {
            statSync(jsPath);
            entries[`${category}/${component}/js`] = jsPath;
          } catch {}
          
          try {
            statSync(htmlPath);
            entries[`${category}/${component}/html`] = htmlPath;
          } catch {}
        }
      });
    } catch (e) {
      // Catégorie n'existe pas encore
    }
  });
  
  return entries;
}

export default defineConfig({
  root: 'src',
  publicDir: resolve(__dirname, 'src/assets'),
  
  resolve: {
    alias: {
      '@': resolve(__dirname, 'src'),
      '@components': resolve(__dirname, 'src/components'),
      '@atoms': resolve(__dirname, 'src/components/atoms'),
      '@molecules': resolve(__dirname, 'src/components/molecules'),
      '@organisms': resolve(__dirname, 'src/components/organisms'),
      '@templates': resolve(__dirname, 'src/components/templates'),
      '@pages': resolve(__dirname, 'src/components/pages'),
      '@assets': resolve(__dirname, 'src/assets'),
      '@styles': resolve(__dirname, 'src/assets/styles'),
      '@images': resolve(__dirname, 'src/assets/images'),
      '@fonts': resolve(__dirname, 'src/assets/fonts'),
      '@js': resolve(__dirname, 'src/assets/js'),
    }
  },
  
  css: {
    preprocessorOptions: {
      scss: {
        api: 'modern-compiler',
        additionalData: `@use "@/assets/styles/tokens/_variables.scss" as *;\n`,
        silenceDeprecations: ['legacy-js-api']
      }
    },
    transformer: 'lightningcss',
    lightningcss: {
      targets: {
        chrome: 95,
        firefox: 91,
        safari: 14
      }
    }
  },
  
  build: {
    outDir: resolve(__dirname, 'dist'),
    emptyOutDir: true,
    sourcemap: false,
    minify: 'terser',
    
    terserOptions: {
      compress: {
        drop_console: true,
        drop_debugger: true,
        pure_funcs: ['console.log']
      },
      format: {
        comments: false
      }
    },
    
    rollupOptions: {
      input: {
        main: resolve(__dirname, 'src/index.html'),
        index: resolve(__dirname, 'src/index.js'),
        ...scanComponents(resolve(__dirname, 'src/components'))
      },
      
      output: {
        // Organisation des outputs
        entryFileNames: (chunkInfo) => {
          if (chunkInfo.name === 'index') {
            return 'assets/js/bundle.[hash].min.js';
          }
          if (chunkInfo.name.includes('/')) {
            const parts = chunkInfo.name.split('/');
            if (parts[1] && parts[2]) {
              return `components/${parts[0]}/${parts[1]}/${parts[1]}.[hash].min.js`;
            }
          }
          return 'assets/js/[name].[hash].min.js';
        },
        
        chunkFileNames: (chunkInfo) => {
          if (chunkInfo.name.includes('node_modules')) {
            return 'assets/js/vendors.[hash].min.js';
          }
          return 'assets/js/chunks/[name].[hash].min.js';
        },
        
        assetFileNames: (assetInfo) => {
          const info = assetInfo.name.split('.');
          const ext = info[info.length - 1];
          
          // CSS
          if (ext === 'css') {
            if (assetInfo.name.includes('components/')) {
              const match = assetInfo.name.match(/components\/(\w+)\/(\w+)/);
              if (match) {
                return `components/${match[1]}/${match[2]}/${match[2]}.[hash].min.css`;
              }
            }
            return 'assets/css/main.[hash].min.css';
          }
          
          // Fonts
          if (/woff2?|ttf|otf|eot/.test(ext)) {
            return 'assets/fonts/[name].[hash][extname]';
          }
          
          // Images
          if (/png|jpe?g|gif|webp|avif/.test(ext)) {
            return 'assets/images/[name].[hash][extname]';
          }
          
          // SVG
          if (ext === 'svg') {
            return 'assets/images/svg/[name].[hash][extname]';
          }
          
          return 'assets/[name].[hash][extname]';
        },
        
        manualChunks: (id) => {
          // Séparer node_modules
          if (id.includes('node_modules')) {
            return 'vendors';
          }
          // Code partagé
          if (id.includes('src/assets/js/')) {
            return 'chunks';
          }
        }
      }
    },
    
    chunkSizeWarningLimit: 1000,
    
    // Optimisations
    assetsInlineLimit: 4096,
    cssCodeSplit: true,
    
    reportCompressedSize: true,
    
    cssMinify: 'lightningcss'
  },
  
  server: {
    port: 3000,
    open: true,
    warmup: {
      clientFiles: [
        'src/index.html',
        'src/index.js',
        'src/assets/styles/main.scss'
      ]
    }
  },
  
  optimizeDeps: {
    include: ['@floating-ui/dom']
  },
  
  plugins: [
    // Compression Gzip
    viteCompression({
      verbose: true,
      disable: false,
      threshold: 10240, // 10KB
      algorithm: 'gzip',
      ext: '.gz',
      compressionOptions: {
        level: 9
      }
    }),
    
    // Compression Brotli
    viteCompression({
      verbose: true,
      disable: false,
      threshold: 10240,
      algorithm: 'brotliCompress',
      ext: '.br',
      compressionOptions: {
        level: 11
      }
    }),
    
    // Optimisation des images
    viteImagemin({
      gifsicle: {
        optimizationLevel: 7,
        interlaced: false
      },
      optipng: {
        optimizationLevel: 7
      },
      mozjpeg: {
        quality: 80
      },
      pngquant: {
        quality: [0.8, 0.9],
        speed: 4
      },
      svgo: {
        plugins: [
          {
            name: 'removeViewBox',
            active: false
          },
          {
            name: 'removeEmptyAttrs',
            active: true
          }
        ]
      }
    })
  ]
});
