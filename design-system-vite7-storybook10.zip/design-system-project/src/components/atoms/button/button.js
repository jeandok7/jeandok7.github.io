/**
 * Button Component - Ripple Effect
 * Optional interactive enhancement
 */

(function() {
  'use strict';

  /**
   * Classe pour gérer l'effet ripple sur les boutons
   */
  class ButtonRipple {
    constructor(element) {
      if (!element) {
        throw new Error('Button element is required');
      }

      this.element = element;
      this.element._buttonRippleInstance = this;
      this.init();
    }

    /**
     * Initialisation
     */
    init() {
      this.element.addEventListener('click', this.handleClick.bind(this));
    }

    /**
     * Gestion du clic
     */
    handleClick(event) {
      // Retirer la classe ripple existante
      this.element.classList.remove('is-rippling');

      // Force reflow pour restart animation
      void this.element.offsetWidth;

      // Ajouter la classe ripple
      this.element.classList.add('is-rippling');

      // Retirer la classe après l'animation
      setTimeout(() => {
        this.element.classList.remove('is-rippling');
      }, 500);
    }

    /**
     * Destruction de l'instance
     */
    destroy() {
      this.element.removeEventListener('click', this.handleClick.bind(this));
      delete this.element._buttonRippleInstance;
    }
  }

  /**
   * Auto-initialisation des boutons avec ripple
   */
  function initButtonRipples() {
    document.querySelectorAll('[data-toggle="ds-button-ripple"]').forEach(button => {
      if (!button._buttonRippleInstance) {
        new ButtonRipple(button);
      }
    });
  }

  // Initialisation au chargement du DOM
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initButtonRipples);
  } else {
    initButtonRipples();
  }

  // MutationObserver pour contenu dynamique
  if (typeof MutationObserver !== 'undefined') {
    const observer = new MutationObserver(mutations => {
      mutations.forEach(mutation => {
        mutation.addedNodes.forEach(node => {
          if (node.nodeType === 1) {
            // Check si le node lui-même est un bouton ripple
            if (node.matches && node.matches('[data-toggle="ds-button-ripple"]')) {
              if (!node._buttonRippleInstance) {
                new ButtonRipple(node);
              }
            }

            // Check les enfants
            if (node.querySelectorAll) {
              node.querySelectorAll('[data-toggle="ds-button-ripple"]').forEach(button => {
                if (!button._buttonRippleInstance) {
                  new ButtonRipple(button);
                }
              });
            }
          }
        });
      });
    });

    // Observer une fois le DOM chargé
    if (document.readyState === 'loading') {
      document.addEventListener('DOMContentLoaded', () => {
        observer.observe(document.body, {
          childList: true,
          subtree: true
        });
      });
    } else {
      observer.observe(document.body, {
        childList: true,
        subtree: true
      });
    }
  }

  // Export global et module
  window.DSButtonRipple = ButtonRipple;

  if (typeof module !== 'undefined' && module.exports) {
    module.exports = ButtonRipple;
  }
})();
