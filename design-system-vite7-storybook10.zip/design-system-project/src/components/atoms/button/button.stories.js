import { html } from 'lit-html';
import './button.scss';
import './button.js';

/**
 * Button Component Story
 */
export default {
  title: 'Atoms/Button',
  tags: ['autodocs'],
  argTypes: {
    variant: {
      control: 'select',
      options: ['primary', 'secondary', 'outline', 'ghost'],
      description: 'Visual variant of the button'
    },
    size: {
      control: 'select',
      options: ['sm', 'default', 'lg'],
      description: 'Size of the button'
    },
    label: {
      control: 'text',
      description: 'Button text'
    },
    disabled: {
      control: 'boolean',
      description: 'Disabled state'
    },
    loading: {
      control: 'boolean',
      description: 'Loading state'
    },
    ripple: {
      control: 'boolean',
      description: 'Enable ripple effect'
    }
  }
};

/**
 * Template de base
 */
const Template = ({ variant = 'primary', size = 'default', label = 'Button', disabled = false, loading = false, ripple = false }) => {
  const classes = [
    'ds-button',
    `ds-button--${variant}`,
    size !== 'default' ? `ds-button--${size}` : '',
    loading ? 'ds-button--loading' : '',
    ripple ? 'ds-button--ripple' : ''
  ].filter(Boolean).join(' ');

  const attrs = [
    disabled ? 'disabled' : '',
    ripple ? 'data-toggle="ds-button-ripple"' : ''
  ].filter(Boolean).join(' ');

  return html`
    <button class="${classes}" type="button" ${attrs}>
      ${loading ? html`<span class="ds-button__spinner"></span>` : ''}
      ${label}
    </button>
  `;
};

/**
 * Stories
 */
export const Primary = Template.bind({});
Primary.args = {
  variant: 'primary',
  label: 'Primary Button'
};

export const Secondary = Template.bind({});
Secondary.args = {
  variant: 'secondary',
  label: 'Secondary Button'
};

export const Outline = Template.bind({});
Outline.args = {
  variant: 'outline',
  label: 'Outline Button'
};

export const Ghost = Template.bind({});
Ghost.args = {
  variant: 'ghost',
  label: 'Ghost Button'
};

export const Small = Template.bind({});
Small.args = {
  variant: 'primary',
  size: 'sm',
  label: 'Small Button'
};

export const Large = Template.bind({});
Large.args = {
  variant: 'primary',
  size: 'lg',
  label: 'Large Button'
};

export const Disabled = Template.bind({});
Disabled.args = {
  variant: 'primary',
  label: 'Disabled Button',
  disabled: true
};

export const Loading = Template.bind({});
Loading.args = {
  variant: 'primary',
  label: 'Loading...',
  loading: true
};

export const WithRipple = Template.bind({});
WithRipple.args = {
  variant: 'primary',
  label: 'Ripple Effect',
  ripple: true
};

/**
 * All Variants Demo
 */
export const AllVariants = () => html`
  <div style="display: flex; gap: 1rem; flex-wrap: wrap;">
    <button class="ds-button ds-button--primary" type="button">Primary</button>
    <button class="ds-button ds-button--secondary" type="button">Secondary</button>
    <button class="ds-button ds-button--outline" type="button">Outline</button>
    <button class="ds-button ds-button--ghost" type="button">Ghost</button>
  </div>
`;

/**
 * All Sizes Demo
 */
export const AllSizes = () => html`
  <div style="display: flex; gap: 1rem; align-items: center; flex-wrap: wrap;">
    <button class="ds-button ds-button--primary ds-button--sm" type="button">Small</button>
    <button class="ds-button ds-button--primary" type="button">Default</button>
    <button class="ds-button ds-button--primary ds-button--lg" type="button">Large</button>
  </div>
`;

/**
 * With Icon Demo
 */
export const WithIcon = () => html`
  <button class="ds-button ds-button--primary" type="button">
    <svg class="ds-button__icon" width="16" height="16" viewBox="0 0 16 16" fill="currentColor">
      <path d="M8 0a8 8 0 1 1 0 16A8 8 0 0 1 8 0zM2.04 4.326c.325 1.329 2.532 2.54 3.717 3.19.48.263.793.434.743.484-.08.08-.162.158-.242.234-.416.396-.787.749-.758 1.266.035.634.618.824 1.214 1.017.577.188 1.168.38 1.286.983.082.417-.075.988-.22 1.52-.215.782-.406 1.48.22 1.48 1.5-.5 3.798-3.186 4-5 .138-1.243-2-2-3.5-2.5-.478-.16-.755.081-.99.284-.172.15-.322.279-.51.216-.445-.148-2.5-2.477-2.96-3.174z"/>
    </svg>
    Button with Icon
  </button>
`;
