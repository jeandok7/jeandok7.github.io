/**
 * Tooltip Component - Organism
 * Utilise Floating UI pour le positionnement intelligent
 */

import { computePosition, flip, shift, offset, arrow } from '@floating-ui/dom';

(function() {
  'use strict';

  /**
   * Classe Tooltip
   */
  class Tooltip {
    constructor(element, options = {}) {
      if (!element) {
        throw new Error('Tooltip element is required');
      }

      this.element = element;
      this.options = {
        content: element.dataset.tooltipContent || options.content || '',
        html: element.dataset.tooltipHtml || options.html || null,
        placement: element.dataset.tooltipPlacement || options.placement || 'top',
        trigger: element.dataset.tooltipTrigger || options.trigger || 'hover',
        offset: parseInt(element.dataset.tooltipOffset) || options.offset || 8,
        ...options
      };

      this.tooltip = null;
      this.isVisible = false;
      this.element._tooltipInstance = this;

      this.init();
    }

    /**
     * Initialisation
     */
    init() {
      // Créer le tooltip
      this.createTooltip();

      // Setup event listeners basés sur le trigger
      this.setupEventListeners();

      // Accessibilité
      this.element.setAttribute('aria-describedby', this.tooltip.id);
    }

    /**
     * Créer l'élément tooltip
     */
    createTooltip() {
      this.tooltip = document.createElement('div');
      this.tooltip.className = 'ds-tooltip';
      this.tooltip.id = `ds-tooltip-${this.generateId()}`;
      this.tooltip.setAttribute('role', 'tooltip');
      this.tooltip.setAttribute('data-placement', this.options.placement);

      // Arrow
      const arrow = document.createElement('div');
      arrow.className = 'ds-tooltip__arrow';
      this.tooltip.appendChild(arrow);
      this.arrowElement = arrow;

      // Content
      const content = document.createElement('div');
      content.className = 'ds-tooltip__content';

      // HTML ou texte simple
      if (this.options.html) {
        const template = document.querySelector(this.options.html);
        if (template && template.content) {
          content.appendChild(template.content.cloneNode(true));
        } else {
          content.innerHTML = this.options.html;
        }
      } else {
        content.textContent = this.options.content;
      }

      this.tooltip.appendChild(content);

      // Ajouter au body
      document.body.appendChild(this.tooltip);
    }

    /**
     * Setup des event listeners
     */
    setupEventListeners() {
      switch (this.options.trigger) {
        case 'click':
          this.element.addEventListener('click', this.handleClick.bind(this));
          document.addEventListener('click', this.handleOutsideClick.bind(this));
          break;

        case 'focus':
          this.element.addEventListener('focus', this.show.bind(this));
          this.element.addEventListener('blur', this.hide.bind(this));
          break;

        case 'hover':
        default:
          this.element.addEventListener('mouseenter', this.show.bind(this));
          this.element.addEventListener('mouseleave', this.hide.bind(this));
          this.element.addEventListener('focus', this.show.bind(this));
          this.element.addEventListener('blur', this.hide.bind(this));
          break;
      }
    }

    /**
     * Gestion du clic
     */
    handleClick(event) {
      event.stopPropagation();
      this.toggle();
    }

    /**
     * Gestion du clic à l'extérieur
     */
    handleOutsideClick(event) {
      if (!this.element.contains(event.target) && !this.tooltip.contains(event.target)) {
        this.hide();
      }
    }

    /**
     * Afficher le tooltip
     */
    async show() {
      if (this.isVisible) return;

      this.isVisible = true;
      this.tooltip.classList.add('is-visible');

      // Positionner avec Floating UI
      await this.updatePosition();

      // Dispatcher l'événement
      this.dispatchEvent('shown');
    }

    /**
     * Cacher le tooltip
     */
    hide() {
      if (!this.isVisible) return;

      this.isVisible = false;
      this.tooltip.classList.remove('is-visible');

      // Dispatcher l'événement
      this.dispatchEvent('hidden');
    }

    /**
     * Toggle
     */
    toggle() {
      if (this.isVisible) {
        this.hide();
      } else {
        this.show();
      }
    }

    /**
     * Mettre à jour la position avec Floating UI
     */
    async updatePosition() {
      const { x, y, placement, middlewareData } = await computePosition(
        this.element,
        this.tooltip,
        {
          placement: this.options.placement,
          middleware: [
            offset(this.options.offset),
            flip(),
            shift({ padding: 5 }),
            arrow({ element: this.arrowElement })
          ]
        }
      );

      // Appliquer la position
      Object.assign(this.tooltip.style, {
        left: `${x}px`,
        top: `${y}px`
      });

      // Mettre à jour l'attribut de placement
      this.tooltip.setAttribute('data-placement', placement);

      // Positionner l'arrow
      if (middlewareData.arrow) {
        const { x: arrowX, y: arrowY } = middlewareData.arrow;

        const staticSide = {
          top: 'bottom',
          right: 'left',
          bottom: 'top',
          left: 'right'
        }[placement.split('-')[0]];

        Object.assign(this.arrowElement.style, {
          left: arrowX != null ? `${arrowX}px` : '',
          top: arrowY != null ? `${arrowY}px` : '',
          right: '',
          bottom: '',
          [staticSide]: '-4px'
        });
      }
    }

    /**
     * Générer un ID unique
     */
    generateId() {
      return `${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
    }

    /**
     * Dispatcher un événement custom
     */
    dispatchEvent(eventName, detail = {}) {
      const event = new CustomEvent(`ds-tooltip:${eventName}`, {
        bubbles: true,
        detail: { tooltip: this, ...detail }
      });
      this.element.dispatchEvent(event);
    }

    /**
     * Détruire l'instance
     */
    destroy() {
      // Retirer les event listeners
      this.element.removeEventListener('click', this.handleClick);
      this.element.removeEventListener('mouseenter', this.show);
      this.element.removeEventListener('mouseleave', this.hide);
      this.element.removeEventListener('focus', this.show);
      this.element.removeEventListener('blur', this.hide);
      document.removeEventListener('click', this.handleOutsideClick);

      // Retirer le tooltip du DOM
      if (this.tooltip && this.tooltip.parentNode) {
        this.tooltip.parentNode.removeChild(this.tooltip);
      }

      // Retirer l'attribut ARIA
      this.element.removeAttribute('aria-describedby');

      delete this.element._tooltipInstance;
    }
  }

  /**
   * Auto-initialisation
   */
  function initTooltips() {
    document.querySelectorAll('[data-toggle="ds-tooltip"]').forEach(element => {
      if (!element._tooltipInstance) {
        new Tooltip(element);
      }
    });
  }

  // Initialisation au chargement du DOM
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initTooltips);
  } else {
    initTooltips();
  }

  // MutationObserver pour contenu dynamique
  if (typeof MutationObserver !== 'undefined') {
    const observer = new MutationObserver(mutations => {
      mutations.forEach(mutation => {
        mutation.addedNodes.forEach(node => {
          if (node.nodeType === 1) {
            if (node.matches && node.matches('[data-toggle="ds-tooltip"]')) {
              if (!node._tooltipInstance) {
                new Tooltip(node);
              }
            }

            if (node.querySelectorAll) {
              node.querySelectorAll('[data-toggle="ds-tooltip"]').forEach(element => {
                if (!element._tooltipInstance) {
                  new Tooltip(element);
                }
              });
            }
          }
        });
      });
    });

    if (document.readyState === 'loading') {
      document.addEventListener('DOMContentLoaded', () => {
        observer.observe(document.body, {
          childList: true,
          subtree: true
        });
      });
    } else {
      observer.observe(document.body, {
        childList: true,
        subtree: true
      });
    }
  }

  // Export global et module
  window.DSTooltip = Tooltip;

  if (typeof module !== 'undefined' && module.exports) {
    module.exports = Tooltip;
  }
})();
