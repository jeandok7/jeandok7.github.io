import { describe, it, expect, beforeEach, afterEach, vi } from 'vitest';
import './accordion.js';

describe('Accordion Component', () => {
  let container;

  beforeEach(() => {
    container = document.createElement('div');
    document.body.appendChild(container);
  });

  afterEach(() => {
    document.body.innerHTML = '';
  });

  describe('Initialization', () => {
    it('should auto-initialize accordion with data-toggle attribute', () => {
      container.innerHTML = `
        <div class="ds-accordion" data-toggle="ds-accordion">
          <div class="ds-accordion__item">
            <button class="ds-accordion__trigger" aria-expanded="false" aria-controls="item-1">Item 1</button>
            <div class="ds-accordion__content" id="item-1" hidden></div>
          </div>
        </div>
      `;

      const accordion = container.querySelector('[data-toggle="ds-accordion"]');
      const event = new Event('DOMContentLoaded');
      document.dispatchEvent(event);

      expect(accordion._accordionInstance).toBeDefined();
    });

    it('should set up ARIA attributes correctly', () => {
      container.innerHTML = `
        <div class="ds-accordion" data-toggle="ds-accordion">
          <div class="ds-accordion__item">
            <button class="ds-accordion__trigger" aria-expanded="false">Item 1</button>
            <div class="ds-accordion__content"></div>
          </div>
        </div>
      `;

      const accordion = container.querySelector('[data-toggle="ds-accordion"]');
      const instance = new window.DSAccordion(accordion);
      const trigger = accordion.querySelector('.ds-accordion__trigger');
      const content = accordion.querySelector('.ds-accordion__content');

      expect(trigger.getAttribute('aria-controls')).toBe(content.id);
      expect(content.id).toBeTruthy();
    });

    it('should dispatch initialized event', (done) => {
      container.innerHTML = `
        <div class="ds-accordion" data-toggle="ds-accordion">
          <div class="ds-accordion__item">
            <button class="ds-accordion__trigger" aria-expanded="false" aria-controls="item-1">Item 1</button>
            <div class="ds-accordion__content" id="item-1" hidden></div>
          </div>
        </div>
      `;

      const accordion = container.querySelector('[data-toggle="ds-accordion"]');

      accordion.addEventListener('ds-accordion:initialized', (event) => {
        expect(event.detail.accordion).toBeInstanceOf(window.DSAccordion);
        done();
      });

      new window.DSAccordion(accordion);
    });
  });

  describe('Click Interaction', () => {
    it('should open item on click', () => {
      container.innerHTML = `
        <div class="ds-accordion" data-toggle="ds-accordion">
          <div class="ds-accordion__item">
            <button class="ds-accordion__trigger" aria-expanded="false" aria-controls="item-1">Item 1</button>
            <div class="ds-accordion__content" id="item-1" hidden></div>
          </div>
        </div>
      `;

      const accordion = container.querySelector('[data-toggle="ds-accordion"]');
      const instance = new window.DSAccordion(accordion);
      const trigger = accordion.querySelector('.ds-accordion__trigger');

      trigger.click();

      expect(trigger.getAttribute('aria-expanded')).toBe('true');
      expect(accordion.querySelector('.ds-accordion__item').classList.contains('ds-accordion__item--active')).toBe(true);
    });

    it('should close item on second click', () => {
      container.innerHTML = `
        <div class="ds-accordion" data-toggle="ds-accordion">
          <div class="ds-accordion__item">
            <button class="ds-accordion__trigger" aria-expanded="false" aria-controls="item-1">Item 1</button>
            <div class="ds-accordion__content" id="item-1" hidden></div>
          </div>
        </div>
      `;

      const accordion = container.querySelector('[data-toggle="ds-accordion"]');
      const instance = new window.DSAccordion(accordion);
      const trigger = accordion.querySelector('.ds-accordion__trigger');

      trigger.click(); // Open
      trigger.click(); // Close

      expect(trigger.getAttribute('aria-expanded')).toBe('false');
      expect(accordion.querySelector('.ds-accordion__item').classList.contains('ds-accordion__item--active')).toBe(false);
    });

    it('should close other items when allowMultiple is false', () => {
      container.innerHTML = `
        <div class="ds-accordion" data-toggle="ds-accordion">
          <div class="ds-accordion__item">
            <button class="ds-accordion__trigger" aria-expanded="false" aria-controls="item-1">Item 1</button>
            <div class="ds-accordion__content" id="item-1" hidden></div>
          </div>
          <div class="ds-accordion__item">
            <button class="ds-accordion__trigger" aria-expanded="false" aria-controls="item-2">Item 2</button>
            <div class="ds-accordion__content" id="item-2" hidden></div>
          </div>
        </div>
      `;

      const accordion = container.querySelector('[data-toggle="ds-accordion"]');
      const instance = new window.DSAccordion(accordion);
      const triggers = accordion.querySelectorAll('.ds-accordion__trigger');

      triggers[0].click(); // Open first
      triggers[1].click(); // Open second

      expect(triggers[0].getAttribute('aria-expanded')).toBe('false');
      expect(triggers[1].getAttribute('aria-expanded')).toBe('true');
    });

    it('should allow multiple open items when allowMultiple is true', () => {
      container.innerHTML = `
        <div class="ds-accordion" data-toggle="ds-accordion" data-allow-multiple="true">
          <div class="ds-accordion__item">
            <button class="ds-accordion__trigger" aria-expanded="false" aria-controls="item-1">Item 1</button>
            <div class="ds-accordion__content" id="item-1" hidden></div>
          </div>
          <div class="ds-accordion__item">
            <button class="ds-accordion__trigger" aria-expanded="false" aria-controls="item-2">Item 2</button>
            <div class="ds-accordion__content" id="item-2" hidden></div>
          </div>
        </div>
      `;

      const accordion = container.querySelector('[data-toggle="ds-accordion"]');
      const instance = new window.DSAccordion(accordion);
      const triggers = accordion.querySelectorAll('.ds-accordion__trigger');

      triggers[0].click();
      triggers[1].click();

      expect(triggers[0].getAttribute('aria-expanded')).toBe('true');
      expect(triggers[1].getAttribute('aria-expanded')).toBe('true');
    });
  });

  describe('Keyboard Navigation', () => {
    it('should navigate down with ArrowDown key', () => {
      container.innerHTML = `
        <div class="ds-accordion" data-toggle="ds-accordion">
          <div class="ds-accordion__item">
            <button class="ds-accordion__trigger" aria-expanded="false" aria-controls="item-1">Item 1</button>
            <div class="ds-accordion__content" id="item-1" hidden></div>
          </div>
          <div class="ds-accordion__item">
            <button class="ds-accordion__trigger" aria-expanded="false" aria-controls="item-2">Item 2</button>
            <div class="ds-accordion__content" id="item-2" hidden></div>
          </div>
        </div>
      `;

      const accordion = container.querySelector('[data-toggle="ds-accordion"]');
      const instance = new window.DSAccordion(accordion);
      const triggers = accordion.querySelectorAll('.ds-accordion__trigger');

      triggers[0].focus();

      const event = new KeyboardEvent('keydown', { key: 'ArrowDown', bubbles: true });
      triggers[0].dispatchEvent(event);

      expect(document.activeElement).toBe(triggers[1]);
    });

    it('should navigate up with ArrowUp key', () => {
      container.innerHTML = `
        <div class="ds-accordion" data-toggle="ds-accordion">
          <div class="ds-accordion__item">
            <button class="ds-accordion__trigger" aria-expanded="false" aria-controls="item-1">Item 1</button>
            <div class="ds-accordion__content" id="item-1" hidden></div>
          </div>
          <div class="ds-accordion__item">
            <button class="ds-accordion__trigger" aria-expanded="false" aria-controls="item-2">Item 2</button>
            <div class="ds-accordion__content" id="item-2" hidden></div>
          </div>
        </div>
      `;

      const accordion = container.querySelector('[data-toggle="ds-accordion"]');
      const instance = new window.DSAccordion(accordion);
      const triggers = accordion.querySelectorAll('.ds-accordion__trigger');

      triggers[1].focus();

      const event = new KeyboardEvent('keydown', { key: 'ArrowUp', bubbles: true });
      triggers[1].dispatchEvent(event);

      expect(document.activeElement).toBe(triggers[0]);
    });

    it('should jump to first item with Home key', () => {
      container.innerHTML = `
        <div class="ds-accordion" data-toggle="ds-accordion">
          <div class="ds-accordion__item">
            <button class="ds-accordion__trigger" aria-expanded="false" aria-controls="item-1">Item 1</button>
            <div class="ds-accordion__content" id="item-1" hidden></div>
          </div>
          <div class="ds-accordion__item">
            <button class="ds-accordion__trigger" aria-expanded="false" aria-controls="item-2">Item 2</button>
            <div class="ds-accordion__content" id="item-2" hidden></div>
          </div>
        </div>
      `;

      const accordion = container.querySelector('[data-toggle="ds-accordion"]');
      const instance = new window.DSAccordion(accordion);
      const triggers = accordion.querySelectorAll('.ds-accordion__trigger');

      triggers[1].focus();

      const event = new KeyboardEvent('keydown', { key: 'Home', bubbles: true });
      triggers[1].dispatchEvent(event);

      expect(document.activeElement).toBe(triggers[0]);
    });

    it('should jump to last item with End key', () => {
      container.innerHTML = `
        <div class="ds-accordion" data-toggle="ds-accordion">
          <div class="ds-accordion__item">
            <button class="ds-accordion__trigger" aria-expanded="false" aria-controls="item-1">Item 1</button>
            <div class="ds-accordion__content" id="item-1" hidden></div>
          </div>
          <div class="ds-accordion__item">
            <button class="ds-accordion__trigger" aria-expanded="false" aria-controls="item-2">Item 2</button>
            <div class="ds-accordion__content" id="item-2" hidden></div>
          </div>
        </div>
      `;

      const accordion = container.querySelector('[data-toggle="ds-accordion"]');
      const instance = new window.DSAccordion(accordion);
      const triggers = accordion.querySelectorAll('.ds-accordion__trigger');

      triggers[0].focus();

      const event = new KeyboardEvent('keydown', { key: 'End', bubbles: true });
      triggers[0].dispatchEvent(event);

      expect(document.activeElement).toBe(triggers[1]);
    });
  });

  describe('Public API', () => {
    it('should provide open() method', () => {
      container.innerHTML = `
        <div class="ds-accordion" data-toggle="ds-accordion">
          <div class="ds-accordion__item">
            <button class="ds-accordion__trigger" aria-expanded="false" aria-controls="item-1">Item 1</button>
            <div class="ds-accordion__content" id="item-1" hidden></div>
          </div>
        </div>
      `;

      const accordion = container.querySelector('[data-toggle="ds-accordion"]');
      const instance = new window.DSAccordion(accordion);
      const trigger = accordion.querySelector('.ds-accordion__trigger');

      instance.open(0, false);

      expect(trigger.getAttribute('aria-expanded')).toBe('true');
    });

    it('should provide close() method', () => {
      container.innerHTML = `
        <div class="ds-accordion" data-toggle="ds-accordion">
          <div class="ds-accordion__item ds-accordion__item--active">
            <button class="ds-accordion__trigger" aria-expanded="true" aria-controls="item-1">Item 1</button>
            <div class="ds-accordion__content" id="item-1"></div>
          </div>
        </div>
      `;

      const accordion = container.querySelector('[data-toggle="ds-accordion"]');
      const instance = new window.DSAccordion(accordion);
      const trigger = accordion.querySelector('.ds-accordion__trigger');

      instance.close(0, false);

      expect(trigger.getAttribute('aria-expanded')).toBe('false');
    });

    it('should provide closeAll() method', () => {
      container.innerHTML = `
        <div class="ds-accordion" data-toggle="ds-accordion" data-allow-multiple="true">
          <div class="ds-accordion__item">
            <button class="ds-accordion__trigger" aria-expanded="false" aria-controls="item-1">Item 1</button>
            <div class="ds-accordion__content" id="item-1" hidden></div>
          </div>
          <div class="ds-accordion__item">
            <button class="ds-accordion__trigger" aria-expanded="false" aria-controls="item-2">Item 2</button>
            <div class="ds-accordion__content" id="item-2" hidden></div>
          </div>
        </div>
      `;

      const accordion = container.querySelector('[data-toggle="ds-accordion"]');
      const instance = new window.DSAccordion(accordion);
      const triggers = accordion.querySelectorAll('.ds-accordion__trigger');

      instance.open(0, false);
      instance.open(1, false);
      instance.closeAll();

      expect(triggers[0].getAttribute('aria-expanded')).toBe('false');
      expect(triggers[1].getAttribute('aria-expanded')).toBe('false');
    });

    it('should provide openAll() method when allowMultiple is true', () => {
      container.innerHTML = `
        <div class="ds-accordion" data-toggle="ds-accordion" data-allow-multiple="true">
          <div class="ds-accordion__item">
            <button class="ds-accordion__trigger" aria-expanded="false" aria-controls="item-1">Item 1</button>
            <div class="ds-accordion__content" id="item-1" hidden></div>
          </div>
          <div class="ds-accordion__item">
            <button class="ds-accordion__trigger" aria-expanded="false" aria-controls="item-2">Item 2</button>
            <div class="ds-accordion__content" id="item-2" hidden></div>
          </div>
        </div>
      `;

      const accordion = container.querySelector('[data-toggle="ds-accordion"]');
      const instance = new window.DSAccordion(accordion);
      const triggers = accordion.querySelectorAll('.ds-accordion__trigger');

      instance.openAll();

      expect(triggers[0].getAttribute('aria-expanded')).toBe('true');
      expect(triggers[1].getAttribute('aria-expanded')).toBe('true');
    });

    it('should destroy instance properly', () => {
      container.innerHTML = `
        <div class="ds-accordion" data-toggle="ds-accordion">
          <div class="ds-accordion__item">
            <button class="ds-accordion__trigger" aria-expanded="false" aria-controls="item-1">Item 1</button>
            <div class="ds-accordion__content" id="item-1" hidden></div>
          </div>
        </div>
      `;

      const accordion = container.querySelector('[data-toggle="ds-accordion"]');
      const instance = new window.DSAccordion(accordion);

      expect(accordion._accordionInstance).toBeDefined();

      instance.destroy();

      expect(accordion._accordionInstance).toBeUndefined();
    });
  });

  describe('Custom Events', () => {
    it('should dispatch opened event', (done) => {
      container.innerHTML = `
        <div class="ds-accordion" data-toggle="ds-accordion">
          <div class="ds-accordion__item">
            <button class="ds-accordion__trigger" aria-expanded="false" aria-controls="item-1">Item 1</button>
            <div class="ds-accordion__content" id="item-1" hidden></div>
          </div>
        </div>
      `;

      const accordion = container.querySelector('[data-toggle="ds-accordion"]');
      const instance = new window.DSAccordion(accordion);

      accordion.addEventListener('ds-accordion:opened', (event) => {
        expect(event.detail.index).toBe(0);
        done();
      });

      instance.open(0, false);
    });

    it('should dispatch closed event', (done) => {
      container.innerHTML = `
        <div class="ds-accordion" data-toggle="ds-accordion">
          <div class="ds-accordion__item ds-accordion__item--active">
            <button class="ds-accordion__trigger" aria-expanded="true" aria-controls="item-1">Item 1</button>
            <div class="ds-accordion__content" id="item-1"></div>
          </div>
        </div>
      `;

      const accordion = container.querySelector('[data-toggle="ds-accordion"]');
      const instance = new window.DSAccordion(accordion);

      accordion.addEventListener('ds-accordion:closed', (event) => {
        expect(event.detail.index).toBe(0);
        done();
      });

      instance.close(0, false);
    });
  });
});
