/**
 * Accordion Component - Organism
 * Auto-initialisation avec gestion ARIA et navigation clavier
 */

(function() {
  'use strict';

  /**
   * Classe Accordion
   */
  class Accordion {
    constructor(element, options = {}) {
      if (!element) {
        throw new Error('Accordion element is required');
      }

      this.element = element;
      this.options = {
        allowMultiple: element.dataset.allowMultiple === 'true' || options.allowMultiple || false,
        ...options
      };

      this.items = [];
      this.element._accordionInstance = this;

      this.init();
    }

    /**
     * Initialisation
     */
    init() {
      // Récupérer tous les items
      this.items = Array.from(this.element.querySelectorAll('.ds-accordion__item'));

      // Configurer chaque item
      this.items.forEach((item, index) => {
        const trigger = item.querySelector('.ds-accordion__trigger');
        const content = item.querySelector('.ds-accordion__content');

        if (!trigger || !content) return;

        // Configurer les IDs si nécessaires
        if (!content.id) {
          content.id = `ds-accordion-content-${this.generateId()}`;
        }

        trigger.setAttribute('aria-controls', content.id);

        // État initial
        const isActive = item.classList.contains('ds-accordion__item--active') ||
                        trigger.getAttribute('aria-expanded') === 'true';

        if (isActive) {
          this.open(index, false);
        } else {
          this.close(index, false);
        }

        // Event listeners
        trigger.addEventListener('click', (e) => this.handleClick(e, index));
      });

      // Navigation clavier
      this.element.addEventListener('keydown', (e) => this.handleKeydown(e));

      // Dispatcher l'événement d'initialisation
      this.dispatchEvent('initialized');
    }

    /**
     * Gestion du clic
     */
    handleClick(event, index) {
      event.preventDefault();

      const item = this.items[index];
      const trigger = item.querySelector('.ds-accordion__trigger');
      const isExpanded = trigger.getAttribute('aria-expanded') === 'true';

      if (isExpanded) {
        this.close(index);
      } else {
        this.open(index);
      }
    }

    /**
     * Gestion du clavier
     */
    handleKeydown(event) {
      const { key } = event;
      const target = event.target;

      if (!target.classList.contains('ds-accordion__trigger')) return;

      const triggers = this.items.map(item => item.querySelector('.ds-accordion__trigger'));
      const currentIndex = triggers.indexOf(target);

      let nextIndex;

      switch (key) {
        case 'ArrowDown':
          event.preventDefault();
          nextIndex = (currentIndex + 1) % triggers.length;
          triggers[nextIndex].focus();
          break;

        case 'ArrowUp':
          event.preventDefault();
          nextIndex = currentIndex === 0 ? triggers.length - 1 : currentIndex - 1;
          triggers[nextIndex].focus();
          break;

        case 'Home':
          event.preventDefault();
          triggers[0].focus();
          break;

        case 'End':
          event.preventDefault();
          triggers[triggers.length - 1].focus();
          break;
      }
    }

    /**
     * Ouvrir un item
     */
    open(index, animate = true) {
      const item = this.items[index];
      if (!item) return;

      const trigger = item.querySelector('.ds-accordion__trigger');
      const content = item.querySelector('.ds-accordion__content');

      // Fermer les autres items si allowMultiple est false
      if (!this.options.allowMultiple) {
        this.items.forEach((otherItem, otherIndex) => {
          if (otherIndex !== index) {
            this.close(otherIndex, animate);
          }
        });
      }

      // Ouvrir l'item
      item.classList.add('ds-accordion__item--active');
      trigger.setAttribute('aria-expanded', 'true');
      content.removeAttribute('hidden');

      if (animate) {
        // Animation smooth
        const height = content.scrollHeight;
        content.style.height = '0px';
        content.style.opacity = '0';

        requestAnimationFrame(() => {
          content.style.height = `${height}px`;
          content.style.opacity = '1';

          const transitionEnd = () => {
            content.style.height = 'auto';
            content.removeEventListener('transitionend', transitionEnd);
          };

          content.addEventListener('transitionend', transitionEnd);
        });
      } else {
        content.style.height = 'auto';
        content.style.opacity = '1';
      }

      // Dispatcher l'événement
      this.dispatchEvent('opened', { index, item });
    }

    /**
     * Fermer un item
     */
    close(index, animate = true) {
      const item = this.items[index];
      if (!item) return;

      const trigger = item.querySelector('.ds-accordion__trigger');
      const content = item.querySelector('.ds-accordion__content');

      item.classList.remove('ds-accordion__item--active');
      trigger.setAttribute('aria-expanded', 'false');

      if (animate) {
        // Animation smooth
        const height = content.scrollHeight;
        content.style.height = `${height}px`;

        requestAnimationFrame(() => {
          content.style.height = '0px';
          content.style.opacity = '0';

          const transitionEnd = () => {
            content.setAttribute('hidden', '');
            content.style.height = '';
            content.style.opacity = '';
            content.removeEventListener('transitionend', transitionEnd);
          };

          content.addEventListener('transitionend', transitionEnd);
        });
      } else {
        content.setAttribute('hidden', '');
        content.style.height = '';
        content.style.opacity = '';
      }

      // Dispatcher l'événement
      this.dispatchEvent('closed', { index, item });
    }

    /**
     * Toggle un item
     */
    toggle(index) {
      const item = this.items[index];
      if (!item) return;

      const trigger = item.querySelector('.ds-accordion__trigger');
      const isExpanded = trigger.getAttribute('aria-expanded') === 'true';

      if (isExpanded) {
        this.close(index);
      } else {
        this.open(index);
      }
    }

    /**
     * Fermer tous les items
     */
    closeAll() {
      this.items.forEach((item, index) => {
        this.close(index);
      });
    }

    /**
     * Ouvrir tous les items
     */
    openAll() {
      if (this.options.allowMultiple) {
        this.items.forEach((item, index) => {
          this.open(index);
        });
      }
    }

    /**
     * Générer un ID unique
     */
    generateId() {
      return `${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
    }

    /**
     * Dispatcher un événement custom
     */
    dispatchEvent(eventName, detail = {}) {
      const event = new CustomEvent(`ds-accordion:${eventName}`, {
        bubbles: true,
        detail: { accordion: this, ...detail }
      });
      this.element.dispatchEvent(event);
    }

    /**
     * Détruire l'instance
     */
    destroy() {
      this.items.forEach(item => {
        const trigger = item.querySelector('.ds-accordion__trigger');
        if (trigger) {
          trigger.removeEventListener('click', this.handleClick);
        }
      });

      this.element.removeEventListener('keydown', this.handleKeydown);
      delete this.element._accordionInstance;
    }
  }

  /**
   * Auto-initialisation
   */
  function initAccordions() {
    document.querySelectorAll('[data-toggle="ds-accordion"]').forEach(element => {
      if (!element._accordionInstance) {
        new Accordion(element);
      }
    });
  }

  // Initialisation au chargement du DOM
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initAccordions);
  } else {
    initAccordions();
  }

  // MutationObserver pour contenu dynamique
  if (typeof MutationObserver !== 'undefined') {
    const observer = new MutationObserver(mutations => {
      mutations.forEach(mutation => {
        mutation.addedNodes.forEach(node => {
          if (node.nodeType === 1) {
            if (node.matches && node.matches('[data-toggle="ds-accordion"]')) {
              if (!node._accordionInstance) {
                new Accordion(node);
              }
            }

            if (node.querySelectorAll) {
              node.querySelectorAll('[data-toggle="ds-accordion"]').forEach(element => {
                if (!element._accordionInstance) {
                  new Accordion(element);
                }
              });
            }
          }
        });
      });
    });

    if (document.readyState === 'loading') {
      document.addEventListener('DOMContentLoaded', () => {
        observer.observe(document.body, {
          childList: true,
          subtree: true
        });
      });
    } else {
      observer.observe(document.body, {
        childList: true,
        subtree: true
      });
    }
  }

  // Export global et module
  window.DSAccordion = Accordion;

  if (typeof module !== 'undefined' && module.exports) {
    module.exports = Accordion;
  }
})();
