/**
 * Design System - Main JavaScript Entry Point
 * 
 * Ce fichier importe tous les composants pour les rendre disponibles
 * dans l'application. Chaque composant s'auto-initialise via data-toggle.
 */

// Import des styles globaux
import './assets/styles/main.scss';

// Import des composants
// Atoms
import './components/atoms/button/button.scss';
import './components/atoms/button/button.js';

// Organisms
import './components/organisms/accordion/accordion.scss';
import './components/organisms/accordion/accordion.js';

import './components/organisms/tooltip/tooltip.scss';
import './components/organisms/tooltip/tooltip.js';

// Log pour confirmer le chargement
console.log('Design System initialized');

// Export des classes pour usage programmatique
export { default as DSButtonRipple } from './components/atoms/button/button.js';
export { default as DSAccordion } from './components/organisms/accordion/accordion.js';
export { default as DSTooltip } from './components/organisms/tooltip/tooltip.js';
