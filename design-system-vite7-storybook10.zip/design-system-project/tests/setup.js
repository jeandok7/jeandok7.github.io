/**
 * Vitest Setup File
 * Configuration globale pour les tests
 */

import { beforeAll, afterEach } from 'vitest';

// Setup global avant tous les tests
beforeAll(() => {
  // Configuration globale si nécessaire
});

// Nettoyage après chaque test
afterEach(() => {
  // Nettoyer le DOM
  document.body.innerHTML = '';
  
  // Nettoyer les event listeners globaux
  const oldBody = document.body;
  const newBody = oldBody.cloneNode(false);
  while (oldBody.firstChild) {
    newBody.appendChild(oldBody.firstChild);
  }
  oldBody.parentNode.replaceChild(newBody, oldBody);
});

// Mock window.matchMedia si nécessaire
Object.defineProperty(window, 'matchMedia', {
  writable: true,
  value: (query) => ({
    matches: false,
    media: query,
    onchange: null,
    addListener: () => {},
    removeListener: () => {},
    addEventListener: () => {},
    removeEventListener: () => {},
    dispatchEvent: () => {}
  })
});

// Mock IntersectionObserver
global.IntersectionObserver = class IntersectionObserver {
  constructor() {}
  disconnect() {}
  observe() {}
  takeRecords() {
    return [];
  }
  unobserve() {}
};

// Mock ResizeObserver
global.ResizeObserver = class ResizeObserver {
  constructor() {}
  disconnect() {}
  observe() {}
  unobserve() {}
};
