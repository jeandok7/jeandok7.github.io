# Guide de Création de Composants

Ce guide explique comment créer de nouveaux composants dans le Design System en suivant les conventions et bonnes pratiques établies.

## Table des matières

1. [Architecture Atomic Design](#architecture-atomic-design)
2. [Structure d'un composant](#structure-dun-composant)
3. [Étapes de création](#étapes-de-création)
4. [Bonnes pratiques](#bonnes-pratiques)
5. [Documentation Storybook](#documentation-storybook)
6. [Tests unitaires](#tests-unitaires)
7. [Checklist](#checklist)

---

## Architecture Atomic Design

Le Design System utilise l'architecture **Atomic Design** de Brad Frost pour organiser les composants en 5 niveaux de complexité croissante.

### Niveaux d'Atomic Design

#### 1. **Atoms** (Atomes)
Composants de base, indivisibles, purement UI.

**Exemples** : Button, Input, Label, Icon, Badge

**Caractéristiques** :
- Pas de logique métier complexe
- Composants réutilisables partout
- Styles simples et modulaires
- Pas de dépendances vers d'autres composants

```
src/components/atoms/
├── button/
├── input/
├── label/
└── badge/
```

#### 2. **Molecules** (Molécules)
Groupes d'atomes qui forment une unité fonctionnelle.

**Exemples** : Form Field (Label + Input + Error), Search Bar (Input + Button)

**Caractéristiques** :
- Composition de plusieurs atoms
- Logique simple de coordination
- Interface cohérente

```
src/components/molecules/
├── form-field/
├── search-bar/
└── card-header/
```

#### 3. **Organisms** (Organismes)
Composants complexes et relativement autonomes.

**Exemples** : Accordion, Tooltip, Modal, Navigation, Card

**Caractéristiques** :
- Logique interactive avancée
- États multiples
- API publique riche
- Gestion événements

```
src/components/organisms/
├── accordion/
├── tooltip/
├── modal/
└── navigation/
```

#### 4. **Templates**
Structure de page sans contenu réel.

**Exemples** : Page Layout, Dashboard Template, Blog Template

**Caractéristiques** :
- Organisation spatiale
- Grilles et layouts
- Zones de contenu

```
src/components/templates/
├── page-layout/
├── dashboard-template/
└── blog-template/
```

#### 5. **Pages**
Instances de templates avec du contenu réel.

**Exemples** : Home Page, About Page, Contact Page

**Caractéristiques** :
- Contenu spécifique
- Données réelles
- Routes spécifiques

```
src/components/pages/
├── home/
├── about/
└── contact/
```

---

## Structure d'un composant

Chaque composant suit une structure de fichiers standardisée :

```
src/components/{level}/{component-name}/
├── {component-name}.html          # Exemples HTML
├── {component-name}.scss          # Styles du composant
├── {component-name}.js            # Logique JavaScript
├── {component-name}.stories.js    # Documentation Storybook
└── {component-name}.test.js       # Tests unitaires
```

### Exemple : Composant "Card"

```
src/components/molecules/card/
├── card.html
├── card.scss
├── card.js
├── card.stories.js
└── card.test.js
```

---

## Étapes de création

### Étape 1 : Créer la structure

```bash
# Créer le dossier du composant
mkdir -p src/components/{level}/{component-name}

# Créer les fichiers
cd src/components/{level}/{component-name}
touch {component-name}.html
touch {component-name}.scss
touch {component-name}.js
touch {component-name}.stories.js
touch {component-name}.test.js
```

### Étape 2 : Écrire le HTML

Le fichier `.html` contient des exemples d'utilisation.

```html
<!-- card.html -->

<!-- Card de base -->
<div class="ds-card">
  <div class="ds-card__header">
    <h3 class="ds-card__title">Titre de la carte</h3>
  </div>
  <div class="ds-card__body">
    <p>Contenu de la carte...</p>
  </div>
  <div class="ds-card__footer">
    <button class="ds-button ds-button--primary">Action</button>
  </div>
</div>

<!-- Card avec image -->
<div class="ds-card ds-card--with-image">
  <img class="ds-card__image" src="image.jpg" alt="Description">
  <div class="ds-card__body">
    <h3 class="ds-card__title">Titre</h3>
    <p>Contenu...</p>
  </div>
</div>
```

### Étape 3 : Écrire les styles (SCSS)

Utilisez la convention **BEM** et les **design tokens**.

```scss
// card.scss

/**
 * Card Component - Molecule
 */

.ds-card {
  display: flex;
  flex-direction: column;
  background-color: $color-white;
  border: 1px solid $color-border;
  border-radius: $border-radius-md;
  box-shadow: $shadow-sm;
  overflow: hidden;
  transition: box-shadow $transition-base ease-in-out;

  &:hover {
    box-shadow: $shadow-md;
  }

  /* Header */
  &__header {
    padding: $spacing-lg;
    border-bottom: 1px solid $color-border;
  }

  /* Title */
  &__title {
    margin: 0;
    font-size: $font-size-lg;
    font-weight: $font-weight-semibold;
    color: $color-text;
  }

  /* Body */
  &__body {
    flex: 1;
    padding: $spacing-lg;
  }

  /* Footer */
  &__footer {
    padding: $spacing-lg;
    border-top: 1px solid $color-border;
    background-color: $color-background-light;
  }

  /* Image */
  &__image {
    width: 100%;
    height: auto;
    object-fit: cover;
  }

  /* Modifier : with image */
  &--with-image {
    .ds-card__body {
      padding-top: $spacing-md;
    }
  }

  /* State : clickable */
  &--clickable {
    cursor: pointer;

    &:hover {
      box-shadow: $shadow-lg;
      transform: translateY(-2px);
    }

    &:active {
      transform: translateY(0);
    }
  }
}
```

### Étape 4 : Écrire la logique JavaScript

Utilisez le pattern d'auto-initialisation.

```javascript
// card.js

/**
 * Card Component - Molecule
 * Composant carte interactif avec auto-initialisation
 */

(function() {
  'use strict';

  /**
   * Classe Card
   */
  class Card {
    constructor(element, options = {}) {
      if (!element) {
        throw new Error('Card element is required');
      }

      this.element = element;
      this.options = {
        clickable: element.dataset.clickable === 'true' || options.clickable || false,
        ...options
      };

      this.element._cardInstance = this;
      this.init();
    }

    /**
     * Initialisation
     */
    init() {
      if (this.options.clickable) {
        this.element.classList.add('ds-card--clickable');
        this.element.addEventListener('click', this.handleClick.bind(this));
        this.element.setAttribute('role', 'button');
        this.element.setAttribute('tabindex', '0');
      }

      this.dispatchEvent('initialized');
    }

    /**
     * Gestion du clic
     */
    handleClick(event) {
      this.dispatchEvent('clicked', { originalEvent: event });
    }

    /**
     * Dispatcher un événement custom
     */
    dispatchEvent(eventName, detail = {}) {
      const event = new CustomEvent(`ds-card:${eventName}`, {
        bubbles: true,
        detail: { card: this, ...detail }
      });
      this.element.dispatchEvent(event);
    }

    /**
     * Détruire l'instance
     */
    destroy() {
      if (this.options.clickable) {
        this.element.removeEventListener('click', this.handleClick);
        this.element.removeAttribute('role');
        this.element.removeAttribute('tabindex');
      }
      delete this.element._cardInstance;
    }
  }

  /**
   * Auto-initialisation
   */
  function initCards() {
    document.querySelectorAll('[data-toggle="ds-card"]').forEach(element => {
      if (!element._cardInstance) {
        new Card(element);
      }
    });
  }

  // Initialisation au chargement du DOM
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initCards);
  } else {
    initCards();
  }

  // MutationObserver pour contenu dynamique
  if (typeof MutationObserver !== 'undefined') {
    const observer = new MutationObserver(mutations => {
      mutations.forEach(mutation => {
        mutation.addedNodes.forEach(node => {
          if (node.nodeType === 1) {
            if (node.matches && node.matches('[data-toggle="ds-card"]')) {
              if (!node._cardInstance) new Card(node);
            }
            if (node.querySelectorAll) {
              node.querySelectorAll('[data-toggle="ds-card"]').forEach(element => {
                if (!element._cardInstance) new Card(element);
              });
            }
          }
        });
      });
    });

    if (document.readyState === 'loading') {
      document.addEventListener('DOMContentLoaded', () => {
        observer.observe(document.body, { childList: true, subtree: true });
      });
    } else {
      observer.observe(document.body, { childList: true, subtree: true });
    }
  }

  // Export global et module
  window.DSCard = Card;
  if (typeof module !== 'undefined' && module.exports) {
    module.exports = Card;
  }
})();
```

### Étape 5 : Créer les Stories Storybook

```javascript
// card.stories.js

import { html } from 'lit-html';
import './card.scss';
import './card.js';

export default {
  title: 'Molecules/Card',
  tags: ['autodocs'],
  argTypes: {
    title: {
      control: 'text',
      description: 'Card title'
    },
    content: {
      control: 'text',
      description: 'Card content'
    },
    clickable: {
      control: 'boolean',
      description: 'Make card clickable'
    }
  }
};

const Template = ({ title = 'Card Title', content = 'Card content...', clickable = false }) => {
  const dataAttrs = clickable ? 'data-toggle="ds-card" data-clickable="true"' : '';
  
  return html`
    <div class="ds-card" ${dataAttrs}>
      <div class="ds-card__header">
        <h3 class="ds-card__title">${title}</h3>
      </div>
      <div class="ds-card__body">
        <p>${content}</p>
      </div>
      <div class="ds-card__footer">
        <button class="ds-button ds-button--primary">Action</button>
      </div>
    </div>
  `;
};

export const Default = Template.bind({});
Default.args = {
  title: 'Default Card',
  content: 'This is a card component with default styling.'
};

export const Clickable = Template.bind({});
Clickable.args = {
  title: 'Clickable Card',
  content: 'This card is clickable and has hover effects.',
  clickable: true
};

export const WithImage = () => html`
  <div class="ds-card ds-card--with-image">
    <img class="ds-card__image" src="https://via.placeholder.com/400x200" alt="Placeholder">
    <div class="ds-card__body">
      <h3 class="ds-card__title">Card with Image</h3>
      <p>This card includes an image at the top.</p>
    </div>
  </div>
`;
```

### Étape 6 : Écrire les tests

```javascript
// card.test.js

import { describe, it, expect, beforeEach, afterEach } from 'vitest';
import './card.js';

describe('Card Component', () => {
  let container;

  beforeEach(() => {
    container = document.createElement('div');
    document.body.appendChild(container);
  });

  afterEach(() => {
    document.body.innerHTML = '';
  });

  it('should auto-initialize card with data-toggle', () => {
    container.innerHTML = `
      <div class="ds-card" data-toggle="ds-card">
        <div class="ds-card__body">Content</div>
      </div>
    `;

    const card = container.querySelector('[data-toggle="ds-card"]');
    document.dispatchEvent(new Event('DOMContentLoaded'));

    expect(card._cardInstance).toBeDefined();
  });

  it('should make card clickable when option is set', () => {
    container.innerHTML = `
      <div class="ds-card" data-toggle="ds-card" data-clickable="true">
        <div class="ds-card__body">Content</div>
      </div>
    `;

    const card = container.querySelector('[data-toggle="ds-card"]');
    const instance = new window.DSCard(card);

    expect(card.classList.contains('ds-card--clickable')).toBe(true);
    expect(card.getAttribute('role')).toBe('button');
  });

  it('should dispatch clicked event when clickable card is clicked', (done) => {
    container.innerHTML = `
      <div class="ds-card" data-toggle="ds-card" data-clickable="true">
        <div class="ds-card__body">Content</div>
      </div>
    `;

    const card = container.querySelector('[data-toggle="ds-card"]');
    const instance = new window.DSCard(card);

    card.addEventListener('ds-card:clicked', (event) => {
      expect(event.detail.card).toBeInstanceOf(window.DSCard);
      done();
    });

    card.click();
  });

  it('should destroy instance properly', () => {
    container.innerHTML = `
      <div class="ds-card" data-toggle="ds-card" data-clickable="true">
        <div class="ds-card__body">Content</div>
      </div>
    `;

    const card = container.querySelector('[data-toggle="ds-card"]');
    const instance = new window.DSCard(card);

    expect(card._cardInstance).toBeDefined();

    instance.destroy();

    expect(card._cardInstance).toBeUndefined();
    expect(card.getAttribute('role')).toBeNull();
  });
});
```

---

## Bonnes pratiques

### 1. Naming Convention (BEM)

Utilisez la méthodologie **BEM** (Block Element Modifier) :

```scss
// Block
.ds-{component} {}

// Element
.ds-{component}__{element} {}

// Modifier
.ds-{component}--{modifier} {}

// State
.ds-{component}.is-{state} {}
```

**Exemples** :
```scss
.ds-button {}                 // Block
.ds-button__icon {}           // Element
.ds-button--primary {}        // Modifier
.ds-button.is-loading {}      // State
```

### 2. Design Tokens

**Toujours utiliser les design tokens** au lieu de valeurs en dur :

✅ **Bon** :
```scss
.ds-card {
  padding: $spacing-lg;
  border-radius: $border-radius-md;
  box-shadow: $shadow-sm;
  color: $color-text;
}
```

❌ **Mauvais** :
```scss
.ds-card {
  padding: 1.5rem;
  border-radius: 0.375rem;
  box-shadow: 0 1px 2px rgba(0, 0, 0, 0.05);
  color: #212529;
}
```

### 3. Auto-initialisation

Tous les composants **interactifs** doivent s'auto-initialiser via `data-toggle` :

```html
<div class="ds-component" data-toggle="ds-component">
  <!-- content -->
</div>
```

```javascript
// Pattern d'auto-initialisation
function initComponents() {
  document.querySelectorAll('[data-toggle="ds-component"]').forEach(el => {
    if (!el._componentInstance) {
      new Component(el);
    }
  });
}

if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', initComponents);
} else {
  initComponents();
}
```

### 4. Accessibilité (ARIA)

Assurez-vous que vos composants sont **accessibles** :

- **Rôles ARIA** : `role="button"`, `role="dialog"`, etc.
- **États ARIA** : `aria-expanded`, `aria-hidden`, `aria-disabled`
- **Labels ARIA** : `aria-label`, `aria-labelledby`, `aria-describedby`
- **Navigation clavier** : Support des touches ↑↓←→ Enter Space Escape
- **Focus visible** : Indicateurs de focus clairs

```html
<button class="ds-accordion__trigger"
        type="button"
        aria-expanded="false"
        aria-controls="accordion-content-1">
  Titre
</button>

<div id="accordion-content-1" 
     role="region" 
     aria-labelledby="trigger-1"
     hidden>
  Contenu
</div>
```

### 5. Custom Events

Émettez des **événements personnalisés** pour les actions importantes :

```javascript
dispatchEvent(eventName, detail = {}) {
  const event = new CustomEvent(`ds-{component}:${eventName}`, {
    bubbles: true,
    detail: { component: this, ...detail }
  });
  this.element.dispatchEvent(event);
}

// Utilisation
this.dispatchEvent('opened');
this.dispatchEvent('closed');
this.dispatchEvent('changed', { value: newValue });
```

### 6. MutationObserver

Utilisez **MutationObserver** pour gérer le contenu ajouté dynamiquement :

```javascript
if (typeof MutationObserver !== 'undefined') {
  const observer = new MutationObserver(mutations => {
    mutations.forEach(mutation => {
      mutation.addedNodes.forEach(node => {
        if (node.nodeType === 1) {
          if (node.matches && node.matches('[data-toggle="ds-component"]')) {
            if (!node._componentInstance) new Component(node);
          }
          if (node.querySelectorAll) {
            node.querySelectorAll('[data-toggle="ds-component"]').forEach(el => {
              if (!el._componentInstance) new Component(el);
            });
          }
        }
      });
    });
  });

  observer.observe(document.body, { childList: true, subtree: true });
}
```

### 7. API Publique

Fournissez une **API publique** claire et cohérente :

```javascript
class Component {
  // Méthodes publiques essentielles
  show() {}
  hide() {}
  toggle() {}
  open() {}
  close() {}
  destroy() {}
  
  // Getters/Setters si nécessaire
  get isVisible() {
    return this.visible;
  }
  
  set content(value) {
    this._content = value;
    this.render();
  }
}
```

### 8. Reduced Motion

Respectez les préférences utilisateur pour **reduced motion** :

```scss
@media (prefers-reduced-motion: reduce) {
  .ds-component {
    animation: none;
    transition: none;
  }
}
```

---

## Documentation Storybook

### Structure d'une Story

```javascript
export default {
  title: '{Level}/{ComponentName}',      // ex: 'Molecules/Card'
  tags: ['autodocs'],                     // Génère la doc auto
  argTypes: {
    // Définir les contrôles
    title: {
      control: 'text',
      description: 'Le titre du composant'
    },
    variant: {
      control: 'select',
      options: ['primary', 'secondary'],
      description: 'Variante visuelle'
    }
  }
};
```

### Types de Stories

```javascript
// 1. Story avec Template
const Template = (args) => html`<div>${args.content}</div>`;

export const Default = Template.bind({});
Default.args = { content: 'Hello' };

// 2. Story statique
export const WithImage = () => html`
  <div class="ds-card ds-card--with-image">
    <img src="..." alt="">
    <p>Content</p>
  </div>
`;

// 3. Story interactive
export const Interactive = () => {
  setTimeout(() => {
    // Logique après rendu
  }, 100);
  
  return html`<div>Interactive content</div>`;
};
```

---

## Tests unitaires

### Structure d'un fichier de test

```javascript
import { describe, it, expect, beforeEach, afterEach } from 'vitest';
import './component.js';

describe('Component Name', () => {
  let container;

  beforeEach(() => {
    container = document.createElement('div');
    document.body.appendChild(container);
  });

  afterEach(() => {
    document.body.innerHTML = '';
  });

  describe('Initialization', () => {
    it('should auto-initialize', () => {
      // Test d'initialisation
    });
  });

  describe('Interactions', () => {
    it('should respond to click', () => {
      // Test d'interaction
    });
  });

  describe('Public API', () => {
    it('should provide public methods', () => {
      // Test de l'API
    });
  });

  describe('Accessibility', () => {
    it('should have correct ARIA attributes', () => {
      // Test d'accessibilité
    });
  });
});
```

### Catégories de tests à couvrir

1. **Initialisation**
   - Auto-initialisation
   - Configuration des options
   - ARIA attributes

2. **Interactions**
   - Clic, hover, focus
   - Navigation clavier
   - Toggle, open, close

3. **API Publique**
   - Méthodes (show, hide, toggle, etc.)
   - Getters/Setters
   - Destroy

4. **Custom Events**
   - Événements émis
   - Détails des événements

5. **Contenu dynamique**
   - MutationObserver
   - Ajout/suppression d'éléments

6. **Accessibilité**
   - ARIA
   - Focus management
   - Keyboard navigation

---

## Checklist

Avant de considérer un composant comme terminé, vérifiez que :

### Structure ✅
- [ ] Dossier créé dans le bon niveau Atomic Design
- [ ] 5 fichiers présents (html, scss, js, stories, test)
- [ ] Naming cohérent (kebab-case)

### HTML ✅
- [ ] Exemples d'utilisation complets
- [ ] Plusieurs variantes démontrées
- [ ] États différents (normal, hover, disabled)

### SCSS ✅
- [ ] Convention BEM respectée
- [ ] Design tokens utilisés (pas de valeurs en dur)
- [ ] Commentaires clairs
- [ ] Support reduced-motion
- [ ] Responsive si nécessaire

### JavaScript ✅
- [ ] Auto-initialisation via `data-toggle`
- [ ] MutationObserver implémenté
- [ ] API publique documentée
- [ ] Custom events émis
- [ ] Méthode `destroy()` présente
- [ ] Export global et module

### Accessibilité ✅
- [ ] Rôles ARIA corrects
- [ ] États ARIA (`aria-expanded`, etc.)
- [ ] Labels ARIA (`aria-label`, `aria-labelledby`)
- [ ] Navigation clavier fonctionnelle
- [ ] Focus visible

### Storybook ✅
- [ ] Title correct (`{Level}/{Component}`)
- [ ] Tag `autodocs` présent
- [ ] ArgTypes définis
- [ ] Au moins 3 stories (Default, Variantes, États)
- [ ] Stories interactives si applicable

### Tests ✅
- [ ] Test d'initialisation
- [ ] Tests d'interactions
- [ ] Tests de l'API publique
- [ ] Tests des custom events
- [ ] Tests d'accessibilité
- [ ] Coverage > 80%

### Documentation ✅
- [ ] Commentaires JSDoc si nécessaire
- [ ] README dans le dossier si complexe
- [ ] Exemples d'utilisation dans QUICKSTART.md

---

## Ressources

- **BEM** : http://getbem.com/
- **Atomic Design** : https://atomicdesign.bradfrost.com/
- **ARIA** : https://www.w3.org/WAI/ARIA/apg/
- **Vitest** : https://vitest.dev/
- **Storybook** : https://storybook.js.org/

---

**Bonne création de composants ! 🎨**
