# Quick Start Guide

Guide de démarrage rapide pour utiliser le Design System dans votre projet.

## Installation

### Prérequis

Assurez-vous d'avoir installé :
- **Node.js** >= 20.0.0
- **npm** >= 10.0.0

Vérifiez vos versions :

```bash
node --version  # devrait afficher v20.0.0 ou supérieur
npm --version   # devrait afficher 10.0.0 ou supérieur
```

### Étapes d'installation

```bash
# 1. Naviguer dans le dossier du projet
cd design-system-vite7-storybook10

# 2. Installer les dépendances
npm install

# 3. Générer les design tokens
npm run build-tokens

# 4. Démarrer le serveur de développement
npm run dev
```

Le serveur démarre sur **http://localhost:3000**

## Utilisation des composants

### 1. Button (Atom)

Le composant Button est un élément de base avec plusieurs variantes.

#### HTML de base

```html
<!-- Import du CSS et JS -->
<link rel="stylesheet" href="/assets/css/main.css">
<script type="module" src="/components/atoms/button/button.js"></script>

<!-- Button Primary -->
<button class="ds-button ds-button--primary" type="button">
  Primary Button
</button>

<!-- Button Secondary -->
<button class="ds-button ds-button--secondary" type="button">
  Secondary Button
</button>

<!-- Button Outline -->
<button class="ds-button ds-button--outline" type="button">
  Outline Button
</button>

<!-- Button Ghost -->
<button class="ds-button ds-button--ghost" type="button">
  Ghost Button
</button>
```

#### Tailles

```html
<!-- Small -->
<button class="ds-button ds-button--primary ds-button--sm">
  Small Button
</button>

<!-- Default (pas de classe de taille) -->
<button class="ds-button ds-button--primary">
  Default Button
</button>

<!-- Large -->
<button class="ds-button ds-button--primary ds-button--lg">
  Large Button
</button>
```

#### États

```html
<!-- Disabled -->
<button class="ds-button ds-button--primary" disabled>
  Disabled Button
</button>

<!-- Loading -->
<button class="ds-button ds-button--primary ds-button--loading">
  <span class="ds-button__spinner"></span>
  Loading...
</button>

<!-- With Ripple Effect -->
<button class="ds-button ds-button--primary ds-button--ripple" 
        data-toggle="ds-button-ripple">
  Ripple Effect
</button>
```

#### Avec icône

```html
<button class="ds-button ds-button--primary">
  <svg class="ds-button__icon" width="16" height="16" viewBox="0 0 16 16" fill="currentColor">
    <path d="..."/>
  </svg>
  Button with Icon
</button>
```

---

### 2. Accordion (Organism)

Le composant Accordion permet d'afficher/masquer du contenu de manière interactive.

#### HTML de base

```html
<!-- Import -->
<link rel="stylesheet" href="/assets/css/main.css">
<script type="module" src="/components/organisms/accordion/accordion.js"></script>

<!-- Accordion avec auto-initialisation -->
<div class="ds-accordion" data-toggle="ds-accordion">
  
  <!-- Item 1 -->
  <div class="ds-accordion__item">
    <button class="ds-accordion__trigger" 
            type="button"
            aria-expanded="false"
            aria-controls="accordion-item-1">
      <span class="ds-accordion__title">Titre de l'item #1</span>
      <span class="ds-accordion__icon" aria-hidden="true"></span>
    </button>
    <div class="ds-accordion__content" 
         id="accordion-item-1"
         role="region"
         hidden>
      <div class="ds-accordion__body">
        Contenu de l'item #1
      </div>
    </div>
  </div>

  <!-- Item 2 -->
  <div class="ds-accordion__item">
    <button class="ds-accordion__trigger" 
            type="button"
            aria-expanded="false"
            aria-controls="accordion-item-2">
      <span class="ds-accordion__title">Titre de l'item #2</span>
      <span class="ds-accordion__icon" aria-hidden="true"></span>
    </button>
    <div class="ds-accordion__content" 
         id="accordion-item-2"
         role="region"
         hidden>
      <div class="ds-accordion__body">
        Contenu de l'item #2
      </div>
    </div>
  </div>

</div>
```

#### Options

```html
<!-- Autoriser plusieurs items ouverts en même temps -->
<div class="ds-accordion" 
     data-toggle="ds-accordion" 
     data-allow-multiple="true">
  <!-- items... -->
</div>

<!-- Item ouvert par défaut -->
<div class="ds-accordion" data-toggle="ds-accordion">
  <div class="ds-accordion__item ds-accordion__item--active">
    <button class="ds-accordion__trigger" 
            aria-expanded="true"
            aria-controls="item-1">
      <span class="ds-accordion__title">Ouvert par défaut</span>
      <span class="ds-accordion__icon" aria-hidden="true"></span>
    </button>
    <div class="ds-accordion__content" id="item-1" role="region">
      <div class="ds-accordion__body">
        Ce contenu est visible au chargement de la page.
      </div>
    </div>
  </div>
</div>
```

#### Utilisation JavaScript

```javascript
// Récupérer l'instance
const accordionElement = document.querySelector('[data-toggle="ds-accordion"]');
const accordion = accordionElement._accordionInstance;

// API publique
accordion.open(0);        // Ouvrir le premier item
accordion.close(1);       // Fermer le deuxième item
accordion.toggle(2);      // Toggle le troisième item
accordion.closeAll();     // Fermer tous les items
accordion.openAll();      // Ouvrir tous les items (si allowMultiple)

// Écouter les événements
accordionElement.addEventListener('ds-accordion:opened', (e) => {
  console.log('Item ouvert:', e.detail.index);
});

accordionElement.addEventListener('ds-accordion:closed', (e) => {
  console.log('Item fermé:', e.detail.index);
});
```

#### Navigation clavier

- **↓ (Flèche bas)** : Focus sur le trigger suivant
- **↑ (Flèche haut)** : Focus sur le trigger précédent
- **Home** : Focus sur le premier trigger
- **End** : Focus sur le dernier trigger
- **Enter / Space** : Toggle l'item

---

### 3. Tooltip (Organism)

Le composant Tooltip affiche une info-bulle contextuelle avec positionnement intelligent.

#### HTML de base

```html
<!-- Import -->
<link rel="stylesheet" href="/assets/css/main.css">
<script type="module" src="/components/organisms/tooltip/tooltip.js"></script>

<!-- Tooltip simple (hover par défaut) -->
<button data-toggle="ds-tooltip" 
        data-tooltip-content="Ceci est un tooltip">
  Survolez-moi
</button>
```

#### Placements

```html
<!-- Top (défaut) -->
<button data-toggle="ds-tooltip" 
        data-tooltip-content="Tooltip en haut"
        data-tooltip-placement="top">
  Top
</button>

<!-- Right -->
<button data-toggle="ds-tooltip" 
        data-tooltip-content="Tooltip à droite"
        data-tooltip-placement="right">
  Right
</button>

<!-- Bottom -->
<button data-toggle="ds-tooltip" 
        data-tooltip-content="Tooltip en bas"
        data-tooltip-placement="bottom">
  Bottom
</button>

<!-- Left -->
<button data-toggle="ds-tooltip" 
        data-tooltip-content="Tooltip à gauche"
        data-tooltip-placement="left">
  Left
</button>
```

#### Triggers

```html
<!-- Hover (défaut) -->
<button data-toggle="ds-tooltip" 
        data-tooltip-content="Apparaît au survol"
        data-tooltip-trigger="hover">
  Hover
</button>

<!-- Click -->
<button data-toggle="ds-tooltip" 
        data-tooltip-content="Apparaît au clic"
        data-tooltip-trigger="click">
  Click
</button>

<!-- Focus -->
<button data-toggle="ds-tooltip" 
        data-tooltip-content="Apparaît au focus"
        data-tooltip-trigger="focus">
  Focus
</button>
```

#### Contenu HTML

```html
<!-- Template HTML -->
<button data-toggle="ds-tooltip" 
        data-tooltip-html="#custom-tooltip">
  Tooltip HTML
</button>

<template id="custom-tooltip">
  <div>
    <strong>Titre en gras</strong><br>
    <em>Texte en italique</em><br>
    <code>Code inline</code>
  </div>
</template>
```

#### Élément désactivé

Pour afficher un tooltip sur un élément désactivé, enveloppez-le dans un span :

```html
<span data-toggle="ds-tooltip" 
      data-tooltip-content="Ce bouton est désactivé">
  <button class="ds-button ds-button--primary" disabled>
    Disabled Button
  </button>
</span>
```

#### Utilisation JavaScript

```javascript
// Créer manuellement
import { DSTooltip } from './index.js';

const tooltip = new DSTooltip(element, {
  content: 'Mon tooltip',
  placement: 'top',
  trigger: 'hover',
  offset: 8
});

// API publique
tooltip.show();      // Afficher
tooltip.hide();      // Masquer
tooltip.toggle();    // Toggle
tooltip.destroy();   // Détruire l'instance

// Écouter les événements
element.addEventListener('ds-tooltip:shown', (e) => {
  console.log('Tooltip affiché');
});

element.addEventListener('ds-tooltip:hidden', (e) => {
  console.log('Tooltip masqué');
});
```

---

## Commandes disponibles

### Développement

```bash
# Serveur de développement avec HMR
npm run dev

# Storybook (documentation interactive)
npm run storybook
```

### Build

```bash
# Build de production
npm run build

# Prévisualiser le build
npm run preview

# Build Storybook
npm run build-storybook
```

### Tests

```bash
# Lancer les tests
npm test

# Tests en mode watch
npm test -- --watch

# Tests avec UI
npm run test:ui

# Coverage
npm run test:coverage
```

### Code Quality

```bash
# Linter
npm run lint

# Formatter (Prettier)
npm run format
```

### Design Tokens

```bash
# Générer les tokens depuis tokens/design-tokens.json
npm run build-tokens
```

---

## Prochaines étapes

1. **Explorez Storybook** : `npm run storybook` pour voir tous les composants documentés
2. **Lisez COMPONENT-CREATION.md** : Pour apprendre à créer vos propres composants
3. **Testez les composants** : Ouvrez `http://localhost:3000` pour la page de démo
4. **Personnalisez les tokens** : Éditez `tokens/design-tokens.json` puis lancez `npm run build-tokens`

---

## Besoin d'aide ?

- Consultez le [README.md](./README.md) pour plus d'informations
- Ouvrez une issue sur GitHub
- Consultez la documentation Storybook

**Bon développement ! 🚀**
