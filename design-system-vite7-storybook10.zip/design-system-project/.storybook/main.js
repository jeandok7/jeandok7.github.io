/** @type { import('@storybook/web-components-vite').StorybookConfig } */
const config = {
  stories: ['../src/**/*.stories.@(js|jsx|ts|tsx)'],
  
  addons: [
    '@storybook/addon-essentials',
    '@storybook/addon-interactions',
    '@storybook/addon-a11y'
  ],
  
  framework: {
    name: '@storybook/web-components-vite',
    options: {}
  },
  
  core: {
    builder: '@storybook/builder-vite'
  },
  
  async viteFinal(config) {
    // Personnalisation de la config Vite pour Storybook
    config.css = config.css || {};
    config.css.preprocessorOptions = config.css.preprocessorOptions || {};
    config.css.preprocessorOptions.scss = {
      api: 'modern-compiler',
      additionalData: `@use "../src/assets/styles/tokens/_variables.scss" as *;\n`,
      silenceDeprecations: ['legacy-js-api']
    };
    
    return config;
  },
  
  docs: {
    autodocs: true
  }
};

export default config;
